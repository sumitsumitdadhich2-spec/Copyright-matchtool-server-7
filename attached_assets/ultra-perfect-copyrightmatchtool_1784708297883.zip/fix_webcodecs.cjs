const fs = require('fs');
let content = fs.readFileSync('src/webcodecs_utils.ts', 'utf8');

// The error is processingQueue is not defined, because it's defined inside onReady
// but used in readChunk. We just need to move its definition up.

const toMove = `
    let processingQueue: {frame: VideoFrame, t: number, frameIdx: number}[] = [];
    let isProcessing = false;
    let flushResolve: (() => void) | null = null;
    let isFlushing = false;
`;

// Insert it right before "let isReadying = false;"
content = content.replace("let isReadying = false;", toMove.trim() + "\n    let isReadying = false;");

// Remove it from inside onReady
content = content.replace(/let processingQueue[^;]+;/, '');
content = content.replace(/let isProcessing = false;/, '');
content = content.replace(/let flushResolve:[^;]+;/, '');
content = content.replace(/let isFlushing = false;/, '');

fs.writeFileSync('src/webcodecs_utils.ts', content, 'utf8');
