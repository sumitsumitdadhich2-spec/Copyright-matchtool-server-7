// @ts-ignore
import * as MP4Box from 'mp4box';

export async function extractFramesLinearWebCodecs(
  file: File | ArrayBuffer,
  targetFps: number,
  onFrame: (frame: ImageBitmap, t: number, frameIdx: number) => void,
  onProgress: (progress: number) => void
): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!window.VideoDecoder) {
      reject(new Error("WebCodecs VideoDecoder not supported."));
      return;
    }

    const mp4boxfile = MP4Box.createFile();
    let videoTrack: any = null;
    let decoder: VideoDecoder | null = null;
    let nextTargetFrameIdx = 0;
    
    let processingQueue: {frame: VideoFrame, t: number, frameIdx: number}[] = [];
    let isProcessing = false;
    let flushResolve: (() => void) | null = null;
    let isFlushing = false;
    
    let isReadying = false;
    let isReady = false;
    
    const isBuffer = file instanceof ArrayBuffer;
    const totalSize = isBuffer ? (file as ArrayBuffer).byteLength : (file as File).size;
    
    mp4boxfile.onError = (e: any) => {
      console.error("[WebCodecs] MP4Box error:", e);
      reject(new Error("MP4Box demuxing error: " + (e?.message || e)));
    };
    
    mp4boxfile.onReady = (info: any) => {
      isReadying = true;
      console.log("[WebCodecs] MP4Box onReady. Info:", info);
      videoTrack = info.videoTracks[0];
      if (!videoTrack) {
        console.error("[WebCodecs] No video track found in the parsed MP4.");
        reject(new Error("No video track found"));
        return;
      }
      
      console.log("[WebCodecs] Found video track. Codec:", videoTrack.codec, "Width:", videoTrack.video.width, "Height:", videoTrack.video.height);
      const config: VideoDecoderConfig = {
        codec: videoTrack.codec,
      };
      
      if (videoTrack.codec.startsWith('avc1') || videoTrack.codec.startsWith('mp4a')) {
        const trak = mp4boxfile.getTrackById(videoTrack.id);
        const stsd = trak.mdia.minf.stbl.stsd;
        for (const entry of stsd.entries) {
          const anyEntry = entry as any;
          if (anyEntry.avcC) {
             const stream = new (MP4Box.DataStream as any)(undefined, 0, (MP4Box.DataStream as any).BIG_ENDIAN);
             anyEntry.avcC.write(stream);
             config.description = new Uint8Array(stream.buffer, 8);
             break;
          }
        }
      }

      // We do not await isConfigSupported here to keep onReady completely synchronous!
      // If we await here, mp4boxfile.appendBuffer will finish synchronously and we will lose
      // any samples present in the initial chunk (mdat) because extraction options aren't set yet.
      VideoDecoder.isConfigSupported(config).then(support => {
        console.log(`[WebCodecs] VideoDecoder config support result for ${videoTrack.codec}:`, support);
        if (!support.supported) {
           console.error("[WebCodecs] Codec not supported by browser:", videoTrack.codec);
        }
      }).catch(err => {
        console.error("[WebCodecs] Error checking config support:", err);
      });

      let frameCountDecoded = 0;

      async function processQueue() {
        if (isProcessing) return;
        isProcessing = true;
        
        let framesProcessedThisLoop = 0;
        
        while (processingQueue.length > 0) {
          const item = processingQueue.shift();
          if (item) {
            const fStart = performance.now();
            
            if (item.frameIdx >= nextTargetFrameIdx) {
              try {
                const imgBitmap = await createImageBitmap(item.frame);
                onFrame(imgBitmap, item.t, item.frameIdx);
              } catch (err) {
                console.error("[WebCodecs] Error in onFrame callback:", err);
              }
              nextTargetFrameIdx = item.frameIdx + 1;
            }
            
            item.frame.close();
            
            const elapsed = performance.now() - fStart;
            if (elapsed > 20) {
              // Log only if it took more than 20ms to prevent spam
              console.log(`[WebCodecs] Frame ${item.frameIdx} processed in ${elapsed.toFixed(1)}ms`);
            }
          }
          
          framesProcessedThisLoop++;
          // Yield to event loop to allow decoder output callbacks to fire
          if (framesProcessedThisLoop % 5 === 0) {
             await new Promise(r => setTimeout(r, 0));
          }
        }
        
        isProcessing = false;
        if (isFlushing && processingQueue.length === 0 && flushResolve) {
          flushResolve();
        }
      }

      decoder = new VideoDecoder({
        output: (frame) => {
          frameCountDecoded++;
          const t = frame.timestamp / 1e6;
          const frameIdx = Math.round(t * targetFps);
          
          if (frameCountDecoded <= 5) {
             console.log(`[WebCodecs] Frame decoded: frameIdx=${frameIdx}, t=${t.toFixed(3)}s`);
          }
          
          processingQueue.push({frame, t, frameIdx});
          processQueue();
        },
        error: (e) => {
           console.error("[WebCodecs] VideoDecoder error:", e);
           reject(new Error("VideoDecoder runtime error: " + e.message));
        }
      });
      
      try {
        console.log("[WebCodecs] Configuring VideoDecoder with:", config);
        decoder.configure(config);
      } catch (err: any) {
        console.error("[WebCodecs] Error during decoder.configure():", err);
        reject(new Error("VideoDecoder configure error: " + err.message));
        return;
      }
      
      console.log("[WebCodecs] Setting extraction options for track id:", videoTrack.id);
      mp4boxfile.setExtractionOptions(videoTrack.id, null, { nbSamples: Infinity });
      console.log("[WebCodecs] mp4boxfile.start() called");
      mp4boxfile.start();
      
      isReady = true;
      isReadying = false;
    };

    let totalSamples = 0;
    let samplesProcessed = 0;

    mp4boxfile.onSamples = (id: number, user: any, samples: any[]) => {
      console.log("[WebCodecs] onSamples fired! id:", id, "sample count:", samples.length);
      totalSamples += samples.length;
      for (const sample of samples) {
        const type = sample.is_sync ? 'key' : 'delta';
        const chunk = new EncodedVideoChunk({
          type,
          timestamp: (sample.cts / sample.timescale) * 1e6,
          duration: (sample.duration / sample.timescale) * 1e6,
          data: sample.data
        });
        if (decoder) {
           decoder.decode(chunk);
        }
        samplesProcessed++;
        
        if (samplesProcessed % 60 === 0 && videoTrack) {
           onProgress((samplesProcessed / videoTrack.nb_samples) * 100);
        }
      }
    };

    let offset = 0;
    const chunkSize = 10 * 1024 * 1024;
    
    async function readChunk() {
      try {
        while (offset < totalSize) {
          // Wait if onReady is currently doing async setup
          while (isReadying) {
            await new Promise(r => setTimeout(r, 50));
          }
          
          if (decoder && (decoder.decodeQueueSize > 200 || processingQueue.length > 50)) {
            console.log(`[WebCodecs] Queue backpressure, decoder size: ${decoder.decodeQueueSize}, processing size: ${processingQueue.length}`);
            await new Promise(r => setTimeout(r, 50));
            continue;
          }
          
          let buffer: ArrayBuffer;
          if (isBuffer) {
            buffer = (file as ArrayBuffer).slice(offset, Math.min(offset + chunkSize, totalSize));
          } else {
            const slice = (file as File).slice(offset, Math.min(offset + chunkSize, totalSize));
            buffer = await slice.arrayBuffer();
          }
          
          (buffer as any).fileStart = offset;
          console.log("[WebCodecs] Appended buffer, offset:", offset, "fileStart:", (buffer as any).fileStart);
          offset += buffer.byteLength;
          mp4boxfile.appendBuffer(buffer as any);
        }
        
        // Final wait just in case onReady was triggered on the very last chunk
        while (isReadying) {
          await new Promise(r => setTimeout(r, 50));
        }

        if (isReady && samplesProcessed === 0) {
           console.log("[WebCodecs] moov at end of file detected (0 samples processed). Restarting extraction from beginning...");
           const seekResult = mp4boxfile.seek(0, true);
           console.log("[WebCodecs] Seek result:", seekResult);
           offset = seekResult.offset;
           
           while (offset < totalSize) {
              if (decoder && (decoder.decodeQueueSize > 200 || processingQueue.length > 50)) {
                await new Promise(r => setTimeout(r, 50));
                continue;
              }
              
              let buffer: ArrayBuffer;
              if (isBuffer) {
                buffer = (file as ArrayBuffer).slice(offset, Math.min(offset + chunkSize, totalSize));
              } else {
                const slice = (file as File).slice(offset, Math.min(offset + chunkSize, totalSize));
                buffer = await slice.arrayBuffer();
              }
              
              (buffer as any).fileStart = offset;
              offset += buffer.byteLength;
              mp4boxfile.appendBuffer(buffer as any);
           }
        }

        mp4boxfile.flush();
        
        if (decoder) {
          await decoder.flush();
          if (processingQueue.length > 0 || isProcessing) {
             isFlushing = true;
             await new Promise<void>(r => { flushResolve = r; });
          }
        }
        
        if (samplesProcessed === 0) {
           throw new Error("No samples were decoded by WebCodecs");
        }
        resolve();
      } catch (err) {
        reject(err);
      }
    }
    
    readChunk();
  });
}
