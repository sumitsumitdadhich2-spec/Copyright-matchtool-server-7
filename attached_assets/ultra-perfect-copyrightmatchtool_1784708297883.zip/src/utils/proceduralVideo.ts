/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ColorGrade = 'Standard' | 'Snyder' | 'RetroSepia' | 'Cyberpunk';

/**
 * Draws a deterministic scene onto a canvas context based on timestamp (seconds) and color grading.
 */
export function drawProceduralFrame(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  time: number,
  sceneId: 'neon' | 'nebula' | 'matrix',
  colorGrade: ColorGrade
) {
  // Clear background
  ctx.fillStyle = '#0a0b10';
  ctx.fillRect(0, 0, width, height);

  // Set up scene-specific drawing
  if (sceneId === 'neon') {
    drawNeonGrid(ctx, width, height, time);
  } else if (sceneId === 'nebula') {
    drawNebulaCosmos(ctx, width, height, time);
  } else if (sceneId === 'matrix') {
    drawMatrixRain(ctx, width, height, time);
  }

  // Draw HUD overlays (adds unique patterns for matching)
  drawHUDOverlay(ctx, width, height, time, sceneId);

  // Apply color grading filter at pixel/blend level
  applyColorGrade(ctx, width, height, colorGrade);
}

/**
 * Draw Scene 1: Neon Grid Space
 */
function drawNeonGrid(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  const horizon = h * 0.45;
  
  // Twinkling stars
  for (let i = 0; i < 30; i++) {
    const starX = (Math.sin(i * 452.3) * 0.5 + 0.5) * w;
    const starY = (Math.cos(i * 123.5) * 0.5 + 0.5) * horizon;
    const twinkle = Math.sin(t * 5 + i) * 0.5 + 0.5;
    ctx.fillStyle = `rgba(255, 255, 255, ${0.2 + twinkle * 0.8})`;
    ctx.beginPath();
    ctx.arc(starX, starY, 1 + (i % 2), 0, Math.PI * 2);
    ctx.fill();
  }

  // Draw perspective grid lines
  ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)'; // Cyan
  ctx.lineWidth = 1.5;

  // Horizontal lines scrolling
  const speed = 40; // pixels per sec
  const spacing = 24;
  const offset = (t * speed) % spacing;
  
  for (let y = horizon; y < h; y += spacing) {
    const adjustedY = y + offset;
    if (adjustedY >= h) continue;
    
    // Fade based on distance to horizon
    const factor = (adjustedY - horizon) / (h - horizon);
    ctx.strokeStyle = `rgba(6, 182, 212, ${factor * 0.5})`;
    ctx.beginPath();
    ctx.moveTo(0, adjustedY);
    ctx.lineTo(w, adjustedY);
    ctx.stroke();
  }

  // Perspective vertical lines
  const center = w / 2;
  const count = 12;
  for (let i = -count; i <= count; i++) {
    const xStart = center + i * 4;
    const xEnd = center + i * (w / count) * 1.5;
    ctx.strokeStyle = `rgba(6, 182, 212, 0.3)`;
    ctx.beginPath();
    ctx.moveTo(xStart, horizon);
    ctx.lineTo(xEnd, h);
    ctx.stroke();
  }

  // Glowing horizon
  const grad = ctx.createLinearGradient(0, horizon - 10, 0, horizon + 5);
  grad.addColorStop(0, 'rgba(6, 182, 212, 0)');
  grad.addColorStop(0.5, 'rgba(139, 92, 246, 0.4)'); // Purple horizon glow
  grad.addColorStop(1, 'rgba(6, 182, 212, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, horizon - 10, w, 15);

  // Rotating central planet
  const pSize = Math.min(w, h) * 0.18;
  const pX = w / 2;
  const pY = horizon - 10;

  // Planet outline glow
  ctx.shadowColor = '#d946ef'; // Fuchsia
  ctx.shadowBlur = 15;
  ctx.beginPath();
  ctx.arc(pX, pY, pSize, 0, Math.PI * 2);
  ctx.fillStyle = '#1e1b4b';
  ctx.fill();
  ctx.shadowBlur = 0; // reset

  // Planet grid rings
  ctx.strokeStyle = 'rgba(217, 70, 239, 0.8)';
  ctx.lineWidth = 2;
  const ringCount = 5;
  for (let i = 0; i < ringCount; i++) {
    const rx = pSize;
    const ry = pSize * Math.sin(t * 1.5 + (i * Math.PI) / ringCount);
    ctx.beginPath();
    ctx.ellipse(pX, pY, rx, Math.abs(ry), 0, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Rotating outer orbit ring
  ctx.strokeStyle = 'rgba(6, 182, 212, 0.7)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.ellipse(pX, pY, pSize * 1.8, pSize * 0.3, Math.PI / 12, t, t + Math.PI * 2);
  ctx.stroke();

  // Satellite orbiting
  const satAngle = t * 2.2;
  const satX = pX + Math.cos(satAngle) * (pSize * 1.8);
  const satY = pY + Math.sin(satAngle) * (pSize * 0.3);
  ctx.fillStyle = '#06b6d4';
  ctx.beginPath();
  ctx.arc(satX, satY, 4, 0, Math.PI * 2);
  ctx.fill();
}

/**
 * Draw Scene 2: Deep Space Nebula
 */
function drawNebulaCosmos(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  const cx = w / 2;
  const cy = h / 2;

  // Draw colorful radial nebula gas
  const rGrad = ctx.createRadialGradient(cx, cy, 10, cx + Math.sin(t) * 15, cy + Math.cos(t) * 10, w * 0.45);
  rGrad.addColorStop(0, 'rgba(147, 51, 234, 0.45)');  // Purple
  rGrad.addColorStop(0.4, 'rgba(236, 72, 153, 0.25)'); // Pink
  rGrad.addColorStop(0.7, 'rgba(59, 130, 246, 0.15)'); // Blue
  rGrad.addColorStop(1, 'rgba(10, 11, 16, 0)');
  ctx.fillStyle = rGrad;
  ctx.fillRect(0, 0, w, h);

  // Spiral dust galaxy rotation
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(t * 0.25);
  
  ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
  const starCount = 65;
  for (let i = 0; i < starCount; i++) {
    // Archimedean spiral formula: r = a + b * theta
    const theta = (i * 0.32) + 0.1;
    const r = (5 + theta * 3.5) * (Math.sin(i * 12) * 0.15 + 1);
    
    // Double arm
    for (const arm of [0, Math.PI]) {
      const sx = Math.cos(theta + arm) * r;
      const sy = Math.sin(theta + arm) * r;
      const brightness = Math.sin(t * 3 + i) * 0.4 + 0.6;
      ctx.fillStyle = `rgba(255, 255, 255, ${brightness * 0.9})`;
      ctx.beginPath();
      ctx.arc(sx, sy, 1 + (i % 2.5), 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();

  // Expanding beacon lines or telescope crosshairs
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, cy); ctx.lineTo(w, cy);
  ctx.moveTo(cx, 0); ctx.lineTo(cx, h);
  ctx.stroke();

  // Draw concentric targeting circles
  ctx.beginPath();
  ctx.arc(cx, cy, w * 0.25, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(236, 72, 153, 0.12)';
  ctx.stroke();
  
  ctx.beginPath();
  ctx.arc(cx, cy, w * 0.12, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(59, 130, 246, 0.2)';
  ctx.stroke();

  // Zooming solar flares
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
  const flareCount = 6;
  for (let i = 0; i < flareCount; i++) {
    const angle = (i * Math.PI * 2) / flareCount + (t * 0.08);
    const length = w * 0.18 + Math.sin(t * 4 + i) * 12;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(cx + Math.cos(angle) * length, cy + Math.sin(angle) * length);
    ctx.stroke();
  }
}

/**
 * Draw Scene 3: Binary Matrix Cascade
 */
function drawMatrixRain(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  // Clear slightly translucent to allow streaks
  ctx.fillStyle = 'rgba(10, 11, 16, 0.95)';
  ctx.fillRect(0, 0, w, h);

  const columns = 20;
  const colWidth = w / columns;

  // Draw vertical waterfall digital code lines
  for (let c = 0; c < columns; c++) {
    // Generate a pseudo-random seed per column
    const seed = c * 43.12;
    const speed = 150 + (Math.sin(seed) * 0.5 + 0.5) * 180; // pixels per sec
    const yStart = (t * speed) % (h + 120) - 80;
    
    // Draw trail of letters
    const charCount = 8;
    for (let i = 0; i < charCount; i++) {
      const charY = yStart - i * 14;
      if (charY < 0 || charY > h) continue;

      const alpha = (charCount - i) / charCount;
      const isLead = i === 0;

      // Draw character
      ctx.fillStyle = isLead ? '#e0f2fe' : `rgba(34, 197, 94, ${alpha * 0.8})`; // Mint white lead, emerald green trail
      ctx.font = '500 11px monospace';
      
      // Deterministic letters based on seed, time, and trail index
      const letterCode = 48 + Math.floor((seed + Math.floor(t * 8) + i) % 10); // numerical matrix code (0-9)
      const letter = String.fromCharCode(letterCode);
      
      ctx.fillText(letter, c * colWidth + colWidth / 3, charY);
    }
  }

  // Draw central glowing vector HUD
  const cx = w / 2;
  const cy = h / 2;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-t * 0.5);

  // Outer segmented bracket ring
  ctx.strokeStyle = 'rgba(34, 197, 94, 0.4)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(0, 0, h * 0.28, 0, Math.PI * 0.6);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, h * 0.28, Math.PI * 0.8, Math.PI * 1.4);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, h * 0.28, Math.PI * 1.6, Math.PI * 2.2);
  ctx.stroke();

  // Inner rotating square
  ctx.strokeStyle = 'rgba(34, 197, 94, 0.3)';
  ctx.lineWidth = 1;
  ctx.rotate(t * 0.8);
  ctx.beginPath();
  ctx.rect(-h * 0.15, -h * 0.15, h * 0.3, h * 0.3);
  ctx.stroke();

  // Center core glowing dot
  ctx.fillStyle = 'rgba(16, 185, 129, 0.8)';
  ctx.beginPath();
  ctx.arc(0, 0, 4 + Math.sin(t * 8) * 2, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

/**
 * Overlay dynamic telemetry/metadata labels to serve as precise visual anchors
 */
function drawHUDOverlay(ctx: CanvasRenderingContext2D, w: number, h: number, t: number, sceneId: string) {
  ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
  ctx.font = '600 8px monospace';
  
  // Left top metadata anchor
  ctx.fillText(`FPS: 24.0 // GROUND_INDEX`, 8, 12);
  ctx.fillText(`SEQ_TIME: ${t.toFixed(3)}s`, 8, 20);

  // Right top scene identity watermark
  ctx.textAlign = 'right';
  const label = sceneId === 'neon' 
    ? 'ORBITAL_GRID_NODE_A' 
    : sceneId === 'nebula' 
    ? 'NEBULA_DEEP_COSMOS_V3' 
    : 'MATRIX_CASCADE_FLOW';
  ctx.fillText(label, w - 8, 12);

  // Bottom central diagnostic ticker
  ctx.textAlign = 'center';
  const tickCode = Math.floor((t * 24) % 1000).toString().padStart(4, '0');
  ctx.fillStyle = sceneId === 'neon' ? '#06b6d4' : sceneId === 'nebula' ? '#ec4899' : '#22c55e';
  ctx.fillText(`[ DIAG_HASH: ${tickCode}_F${Math.floor(t * 24)} ]`, w / 2, h - 8);

  // Restore alignment defaults
  ctx.textAlign = 'left';
}

/**
 * Apply real-time color grading shaders at pixel level
 */
function applyColorGrade(ctx: CanvasRenderingContext2D, w: number, h: number, grade: ColorGrade) {
  if (grade === 'Standard') return;

  const imgData = ctx.getImageData(0, 0, w, h);
  const data = imgData.data;

  if (grade === 'Snyder') {
    // Highly desaturated, dark, cool blue-green tint, high contrast
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i+1];
      const b = data[i+2];

      // Desaturate (luminance)
      const luma = 0.299 * r + 0.587 * g + 0.114 * b;
      
      // Contrast boost
      let finalLuma = luma;
      if (luma < 128) {
        finalLuma = (luma * luma) / 128;
      } else {
        finalLuma = 255 - ((255 - luma) * (255 - luma)) / 128;
      }

      // Cool tinting
      data[i] = Math.max(0, Math.min(255, finalLuma * 0.72));     // Red heavily reduced
      data[i+1] = Math.max(0, Math.min(255, finalLuma * 0.85));   // Green moderate
      data[i+2] = Math.max(0, Math.min(255, finalLuma * 0.98));   // Blue dominant
    }
  } else if (grade === 'RetroSepia') {
    // Warm orange-yellow tint, vintage organic vignette
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i+1];
      const b = data[i+2];

      // Standard Sepia formula
      const tr = 0.393 * r + 0.769 * g + 0.189 * b;
      const tg = 0.349 * r + 0.686 * g + 0.168 * b;
      const tb = 0.272 * r + 0.534 * g + 0.131 * b;

      data[i] = Math.min(255, tr * 1.1);
      data[i+1] = Math.min(255, tg * 1.0);
      data[i+2] = Math.min(255, tb * 0.8);
    }
  } else if (grade === 'Cyberpunk') {
    // Super-saturated purple/pink & orange cyberpunk swap
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i+1];
      const b = data[i+2];

      // If predominantly green/cyan (Matrix stream or Neon lines) -> map to intense pink-purple
      // If predominantly blue/gray -> map to hot orange
      const maxChannel = Math.max(r, g, b);
      if (maxChannel < 25) continue; // skip dark background

      if (g > r && g > b * 0.8) {
        // Green/cyan -> Hot Magenta/Purple
        data[i] = Math.min(255, g * 1.3);
        data[i+1] = Math.max(0, g * 0.15);
        data[i+2] = Math.min(255, g * 1.4);
      } else {
        // Orange/Cyan mix
        const luma = 0.299 * r + 0.587 * g + 0.114 * b;
        data[i] = Math.min(255, luma * 1.5);
        data[i+1] = Math.min(255, luma * 0.6);
        data[i+2] = Math.max(0, luma * 0.1);
      }
    }
  }

  ctx.putImageData(imgData, 0, 0);
}

/**
 * Gets the movie scene id ('neon' | 'nebula' | 'matrix') corresponding to a given timestamp
 * Full movie is 45 seconds total.
 */
export function getMovieSceneAtTime(time: number): 'neon' | 'nebula' | 'matrix' {
  const t = time % 45;
  if (t < 15) return 'neon';
  if (t < 30) return 'nebula';
  return 'matrix';
}

/**
 * Gets the corresponding movie timestamp and scene id for a short video timestamp.
 * Short video is 10 seconds total.
 * It is structured as a remix of movie sections:
 * - 0.0s to 3.5s -> movie matrix scene (32.0s to 35.5s)
 * - 3.5s to 6.5s -> movie neon scene (6.0s to 9.0s)
 * - 6.5s to 10.0s -> movie nebula scene (18.0s to 21.5s)
 */
export function getShortVideoSceneAtTime(time: number): {
  sceneId: 'neon' | 'nebula' | 'matrix';
  movieTime: number;
} {
  const t = time % 10;
  if (t < 3.5) {
    return {
      sceneId: 'matrix',
      movieTime: 32.0 + (t - 0.0)
    };
  } else if (t < 6.5) {
    return {
      sceneId: 'neon',
      movieTime: 6.0 + (t - 3.5)
    };
  } else {
    return {
      sceneId: 'nebula',
      movieTime: 18.0 + (t - 6.5)
    };
  }
}
