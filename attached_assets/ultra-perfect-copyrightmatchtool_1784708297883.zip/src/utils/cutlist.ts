/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * CUT LIST PARSER - Fast Targeted Matching Mode
 * ---------------------------------------------
 * The user provides a pre-computed cut list of the short video.
 * Each cut entry contains:
 *   - start_frame_time : The timestamp of the cut's FIRST frame in the short video (ALWAYS USED)
 *   - last_frame_time  : The timestamp of the cut's LAST frame (IGNORED - informational only)
 *   - frames           : Number of frames in this cut (used to calculate the end time)
 *
 * Instead of scanning every frame of the short video, we only:
 *   1. Extract the start frame of each cut from the short video
 *   2. Search the full movie for that single frame
 *   3. Double-check using a second verification frame (start + offset)
 *   4. Map the given frame count forward to compute the final movie end time
 */

export interface CutEntry {
  cut: number;              // Cut number (1, 2, 3...)
  startTimeSeconds: number; // Parsed start_frame_time in seconds (ALWAYS USED)
  lastTimeSeconds?: number; // Parsed last_frame_time in seconds (IGNORED for matching)
  frames: number;           // Number of frames to map forward from the start frame
}

export interface ParsedCutList {
  fps: number;
  cuts: CutEntry[];
  errors: string[];
}

/**
 * Parses a flexible timestamp into seconds.
 * Supported formats:
 *  - Plain number (seconds):              12.5
 *  - "SS" or "SS.ms":                     "12" / "12.5"
 *  - "MM:SS.mmm" (milliseconds):          "01:21.458"   <- HIGHEST ACCURACY
 *  - "HH:MM:SS.mmm" (milliseconds):       "00:01:21.458"
 *  - "MM:SS":                             "01:12"
 *  - "MM:SS:FF" (frames):                 "01:12:08"
 *  - "HH:MM:SS:FF" (frames):              "00:01:12:08"
 */
export function parseTimecode(value: string | number, fps: number): number {
  if (typeof value === 'number') {
    return value;
  }

  // Normalize: trim + allow comma as decimal separator ("01:21,458" -> "01:21.458")
  const str = String(value).trim().replace(',', '.');

  // Plain seconds like "12.5"
  if (/^\d+(\.\d+)?$/.test(str)) {
    return parseFloat(str);
  }

  const rawParts = str.split(':');
  const parts = rawParts.map(p => parseFloat(p));
  if (parts.some(p => isNaN(p))) {
    throw new Error(`Invalid timecode: "${str}"`);
  }

  // If the LAST segment contains a decimal point, it is seconds.milliseconds
  // (e.g. "01:21.458" or "00:01:21.458") - NOT a frame number.
  const lastHasMs = rawParts[rawParts.length - 1].includes('.');

  if (parts.length === 2) {
    // MM:SS or MM:SS.mmm  ("01:21.458" -> 81.458s)
    return parts[0] * 60 + parts[1];
  }
  if (parts.length === 3) {
    if (lastHasMs) {
      // HH:MM:SS.mmm  ("00:01:21.458" -> 81.458s)
      return parts[0] * 3600 + parts[1] * 60 + parts[2];
    }
    // MM:SS:FF (matches the tool's own output format mm:ss:ff)
    return parts[0] * 60 + parts[1] + parts[2] / fps;
  }
  if (parts.length === 4) {
    // HH:MM:SS:FF
    return parts[0] * 3600 + parts[1] * 60 + parts[2] + parts[3] / fps;
  }

  throw new Error(`Unsupported timecode format: "${str}"`);
}

/**
 * Parses the user-supplied Cut List JSON.
 * Accepts either:
 *  { "fps": 24, "cuts": [ { "cut": 1, "start_frame_time": "00:00:00:00", "last_frame_time": "...", "frames": 60 }, ... ] }
 * or a bare array of cut objects (fps falls back to the provided default).
 */
export function parseCutList(jsonText: string, defaultFps: number): ParsedCutList {
  const errors: string[] = [];
  let raw: any;

  try {
    raw = JSON.parse(jsonText);
  } catch (e: any) {
    return { fps: defaultFps, cuts: [], errors: [`JSON parse error: ${e.message}`] };
  }

  const fps: number = typeof raw?.fps === 'number' && raw.fps > 0 ? raw.fps : defaultFps;
  const rawCuts: any[] = Array.isArray(raw) ? raw : Array.isArray(raw?.cuts) ? raw.cuts : [];

  if (rawCuts.length === 0) {
    errors.push('No cuts found. Expected { "fps": 24, "cuts": [...] } or a JSON array of cut objects.');
    return { fps, cuts: [], errors };
  }

  const cuts: CutEntry[] = [];

  rawCuts.forEach((c, i) => {
    try {
      const startRaw = c.start_frame_time ?? c.startFrameTime ?? c.start ?? c.start_time;
      if (startRaw === undefined || startRaw === null) {
        throw new Error('missing "start_frame_time"');
      }

      const framesRaw = c.frames ?? c.frame_count ?? c.frameCount;
      if (framesRaw === undefined || framesRaw === null || isNaN(Number(framesRaw)) || Number(framesRaw) <= 0) {
        throw new Error('missing or invalid "frames" (must be a positive number)');
      }

      const startTimeSeconds = parseTimecode(startRaw, fps);

      // last_frame_time is parsed but intentionally IGNORED for matching (per spec)
      let lastTimeSeconds: number | undefined;
      const lastRaw = c.last_frame_time ?? c.lastFrameTime ?? c.end ?? c.end_time;
      if (lastRaw !== undefined && lastRaw !== null) {
        try {
          lastTimeSeconds = parseTimecode(lastRaw, fps);
        } catch {
          lastTimeSeconds = undefined; // ignored anyway
        }
      }

      cuts.push({
        cut: typeof c.cut === 'number' ? c.cut : i + 1,
        startTimeSeconds,
        lastTimeSeconds,
        frames: Math.floor(Number(framesRaw))
      });
    } catch (e: any) {
      errors.push(`Cut #${i + 1}: ${e.message}`);
    }
  });

  // Sort by start time to keep processing sequential
  cuts.sort((a, b) => a.startTimeSeconds - b.startTimeSeconds);

  return { fps, cuts, errors };
}

/** Example cut list shown to the user as a template (MM:SS.mmm millisecond format) */
export const EXAMPLE_CUT_LIST = `{
  "fps": 24,
  "cuts": [
    {
      "cut": 1,
      "start_frame_time": "00:00.000",
      "last_frame_time": "00:02.458",
      "frames": 60
    },
    {
      "cut": 2,
      "start_frame_time": "00:02.500",
      "last_frame_time": "00:04.833",
      "frames": 57
    },
    {
      "cut": 3,
      "start_frame_time": "00:04.875",
      "last_frame_time": "00:08.208",
      "frames": 81
    }
  ]
}`;
