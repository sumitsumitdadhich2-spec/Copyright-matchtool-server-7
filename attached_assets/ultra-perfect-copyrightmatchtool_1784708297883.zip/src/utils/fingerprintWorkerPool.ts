import { FrameFingerprint } from './fingerprint';

interface WorkerInstance {
  worker: Worker;
  busy: boolean;
}

interface Task {
  imageBitmap: ImageBitmap;
  frameIndex: number;
  timestamp: number;
  resolve: (fp: FrameFingerprint) => void;
  reject: (err: Error) => void;
  dispatched?: boolean;
}

export class FingerprintWorkerPool {
  private workers: WorkerInstance[] = [];
  private taskQueue: Task[] = [];
  private numCores: number = 4;

  constructor() {
    if (typeof window !== 'undefined' && typeof navigator !== 'undefined') {
      const cores = navigator.hardwareConcurrency || 4;
      this.numCores = Math.min(cores, 8);
      console.log(`[WorkerPool] Initializing fingerprint pool with ${this.numCores} workers (detected concurrency: ${cores})`);
      
      for (let i = 0; i < this.numCores; i++) {
        // Instantiate the worker using Vite-compatible module worker syntax
        const worker = new Worker(
          new URL('./fingerprint.worker.ts', import.meta.url),
          { type: 'module' }
        );

        const instance: WorkerInstance = {
          worker,
          busy: false
        };

        // Attach listener for worker replies
        worker.onmessage = (e: MessageEvent) => {
          const { status, frameIndex, fingerprint, error } = e.data;
          
          // Find the active task matching this frame index
          const taskIdx = this.taskQueue.findIndex(t => t.frameIndex === frameIndex);
          if (taskIdx !== -1) {
            const task = this.taskQueue[taskIdx];
            this.taskQueue.splice(taskIdx, 1);
            instance.busy = false;

            if (status === 'success') {
              task.resolve(fingerprint);
            } else {
              task.reject(new Error(error || `Worker failed processing frame ${frameIndex}`));
            }
          } else {
            instance.busy = false;
          }

          // Process next task in the queue
          this.processQueue();
        };

        this.workers.push(instance);
      }
    }
  }

  /**
   * Returns the count of workers being utilized in this pool.
   */
  public getWorkerCount(): number {
    return this.numCores;
  }

  /**
   * Adds a new frame fingerprinting task to the pool and returns a Promise.
   */
  public computeFingerprint(
    imageBitmap: ImageBitmap,
    frameIndex: number,
    timestamp: number
  ): Promise<FrameFingerprint> {
    return new Promise((resolve, reject) => {
      const task: Task = {
        imageBitmap,
        frameIndex,
        timestamp,
        resolve,
        reject,
        dispatched: false
      };

      this.taskQueue.push(task);
      this.processQueue();
    });
  }

  /**
   * Schedules pending tasks to any free workers.
   */
  private processQueue() {
    // Find free workers
    const freeInstances = this.workers.filter(w => !w.busy);
    if (freeInstances.length === 0) return;

    for (const instance of freeInstances) {
      // Find the first task in the taskQueue that is NOT already active/dispatched
      const taskToDispatch = this.taskQueue.find(t => !t.dispatched);
      if (!taskToDispatch) {
        break; // No more pending tasks to dispatch
      }

      taskToDispatch.dispatched = true;
      instance.busy = true;

      // Send imageBitmap to worker and transfer ownership for zero-copy performance!
      instance.worker.postMessage({
        imageBitmap: taskToDispatch.imageBitmap,
        frameIndex: taskToDispatch.frameIndex,
        timestamp: taskToDispatch.timestamp
      }, [taskToDispatch.imageBitmap]);
    }
  }

  /**
   * Waits for all currently queued tasks to resolve completely.
   */
  public async flush(): Promise<void> {
    while (this.taskQueue.length > 0) {
      await new Promise(r => setTimeout(r, 50));
    }
  }

  /**
   * Terminates all background worker threads and cleans up resources.
   */
  public terminate() {
    console.log("[WorkerPool] Terminating worker pool...");
    for (const instance of this.workers) {
      instance.worker.terminate();
    }
    this.workers = [];
    this.taskQueue = [];
  }
}
