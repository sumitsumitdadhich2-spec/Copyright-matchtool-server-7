/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ColorAndFeatureSignature {
  colorGrid: number[];      // 16 * 3 = 48 values (RGB averages scaled to 0-1)
  skinScoreGrid: number[];  // 16 values (ratio of skin pixels in each block)
  detailGrid: number[];     // 16 values (stddev/texture detail density of grayscale values)
}

export interface CropFingerprint {
  hash: string;
  signature: ColorAndFeatureSignature;
}

export interface FrameFingerprint {
  frameIndex: number;
  timestamp: number; // in seconds
  hash: string;      // 256-character binary string (16x16)
  hashCenter916?: string; // center 9:16 vertical crop
  hashLeft916?: string;   // left 9:16 vertical crop
  hashRight916?: string;  // right 9:16 vertical crop
  hashCenterLeft916?: string;
  hashCenterRight916?: string;
  hashZoom125Center?: string;
  hashZoom125Left?: string;
  hashZoom125Right?: string;
  hashZoom15?: string;    // 1.5x zoom crop
  hashZoom15Left?: string;
  hashZoom15Right?: string;
  hashZoom20?: string;    // 2.0x zoom crop
  hashes?: string[];      // Array of all sample hashes for fast matching
  signatures?: Record<string, ColorAndFeatureSignature>; // Color/Skin/Detail profiles per crop region
}

export interface MatchedSegment {
  id: string;
  shortStart: number;  // in seconds
  shortEnd: number;    // in seconds
  movieStart: number;  // in seconds
  movieEnd: number;    // in seconds
  confidence: number;  // average similarity percentage
  frameCount: number;
  matchSequence: { shortTime: number; movieTime: number; similarity: number }[];
  isApproximate?: boolean;
}

/**
 * Detects subtitle-like pixels (high-contrast text) and replaces them with 
 * local neighborhood averages to completely remove on-screen subtitles and captions.
 */
export function cleanSubtitles(pixels: Uint8ClampedArray, width: number, height: number): void {
  const size = width * height;
  const mask = new Uint8Array(size);

  // 1. Detect candidate subtitle/caption text pixels
  for (let i = 0; i < size; i++) {
    const idx = i * 4;
    const r = pixels[idx];
    const g = pixels[idx + 1];
    const b = pixels[idx + 2];

    // White/Light-gray high-contrast text
    const isWhiteText = r > 200 && g > 200 && b > 200 &&
                        Math.abs(r - g) < 15 && Math.abs(r - b) < 15 && Math.abs(g - b) < 15;

    // Yellow/Amber subtitle text
    const isYellowText = r > 185 && g > 165 && b < 125 &&
                         r > b + 50 && g > b + 40;

    if (isWhiteText || isYellowText) {
      mask[i] = 1;
    }
  }

  // 2. Dilate the mask by a 2-pixel radius to cover black outlines, drop-shadows, or anti-aliasing edges
  const dilatedMask = new Uint8Array(size);
  const radius = 2;
  for (let y = 0; y < height; y++) {
    const yWidth = y * width;
    for (let x = 0; x < width; x++) {
      if (mask[yWidth + x] === 1) {
        const minY = Math.max(0, y - radius);
        const maxY = Math.min(height - 1, y + radius);
        const minX = Math.max(0, x - radius);
        const maxX = Math.min(width - 1, x + radius);

        for (let ny = minY; ny <= maxY; ny++) {
          const nyWidth = ny * width;
          for (let nx = minX; nx <= maxX; nx++) {
            dilatedMask[nyWidth + nx] = 1;
          }
        }
      }
    }
  }

  // 3. Inpaint the masked regions using original non-masked neighborhood pixel averages
  const originalPixels = new Uint8ClampedArray(pixels);
  const searchRadius = 5;

  for (let y = 0; y < height; y++) {
    const yWidth = y * width;
    for (let x = 0; x < width; x++) {
      if (dilatedMask[yWidth + x] === 1) {
        let sumR = 0;
        let sumG = 0;
        let sumB = 0;
        let count = 0;

        const minY = Math.max(0, y - searchRadius);
        const maxY = Math.min(height - 1, y + searchRadius);
        const minX = Math.max(0, x - searchRadius);
        const maxX = Math.min(width - 1, x + searchRadius);

        for (let ny = minY; ny <= maxY; ny++) {
          const nyWidth = ny * width;
          for (let nx = minX; nx <= maxX; nx++) {
            if (dilatedMask[nyWidth + nx] === 0) {
              const nIdx = (nyWidth + nx) * 4;
              sumR += originalPixels[nIdx];
              sumG += originalPixels[nIdx + 1];
              sumB += originalPixels[nIdx + 2];
              count++;
            }
          }
        }

        const idx = (yWidth + x) * 4;
        if (count > 0) {
          pixels[idx] = Math.round(sumR / count);
          pixels[idx + 1] = Math.round(sumG / count);
          pixels[idx + 2] = Math.round(sumB / count);
        } else {
          // Fallback to row-level clean pixels if the entire local window is masked
          let fallbackR = 0;
          let fallbackG = 0;
          let fallbackB = 0;
          let fallbackCount = 0;

          const rowMinY = Math.max(0, y - 10);
          const rowMaxY = Math.min(height - 1, y + 10);

          for (let ry = rowMinY; ry <= rowMaxY; ry++) {
            const ryWidth = ry * width;
            for (let rx = 0; rx < width; rx++) {
              if (dilatedMask[ryWidth + rx] === 0) {
                const fIdx = (ryWidth + rx) * 4;
                fallbackR += originalPixels[fIdx];
                fallbackG += originalPixels[fIdx + 1];
                fallbackB += originalPixels[fIdx + 2];
                fallbackCount++;
              }
            }
          }

          if (fallbackCount > 0) {
            pixels[idx] = Math.round(fallbackR / fallbackCount);
            pixels[idx + 1] = Math.round(fallbackG / fallbackCount);
            pixels[idx + 2] = Math.round(fallbackB / fallbackCount);
          } else {
            // Ultimate fallback (neutral midtone grey)
            pixels[idx] = 120;
            pixels[idx + 1] = 120;
            pixels[idx + 2] = 120;
          }
        }
      }
    }
  }
}

// Shared offscreen canvases and 2D contexts to avoid garbage collection overhead and speed up processing
let sharedCleanCanvas: any = null;
let sharedCleanCtx: any = null;

let sharedTempCanvas: any = null;
let sharedTempCtx: any = null;

function getSharedCleanCanvas(w: number, h: number): { canvas: any; ctx: any } | null {
  if (typeof document === 'undefined' && typeof OffscreenCanvas === 'undefined') return null;
  if (!sharedCleanCanvas) {
    if (typeof document !== 'undefined') {
      sharedCleanCanvas = document.createElement('canvas');
    } else {
      sharedCleanCanvas = new OffscreenCanvas(w, h);
    }
  }
  if (sharedCleanCanvas.width !== w || sharedCleanCanvas.height !== h) {
    sharedCleanCanvas.width = w;
    sharedCleanCanvas.height = h;
  }
  if (!sharedCleanCtx) {
    sharedCleanCtx = sharedCleanCanvas.getContext('2d', { willReadFrequently: true });
  }
  return sharedCleanCtx ? { canvas: sharedCleanCanvas, ctx: sharedCleanCtx } : null;
}

function getSharedTempCanvas(size: number): { canvas: any; ctx: any } | null {
  if (typeof document === 'undefined' && typeof OffscreenCanvas === 'undefined') return null;
  if (!sharedTempCanvas) {
    if (typeof document !== 'undefined') {
      sharedTempCanvas = document.createElement('canvas');
    } else {
      sharedTempCanvas = new OffscreenCanvas(size, size);
    }
  }
  if (sharedTempCanvas.width !== size || sharedTempCanvas.height !== size) {
    sharedTempCanvas.width = size;
    sharedTempCanvas.height = size;
  }
  if (!sharedTempCtx) {
    sharedTempCtx = sharedTempCanvas.getContext('2d', { willReadFrequently: true });
  }
  return sharedTempCtx ? { canvas: sharedTempCanvas, ctx: sharedTempCtx } : null;
}

/**
 * Computes a robust perceptual average hash (aHash) of an image frame.
 * Converts to grayscale, resizes to a 16x16 grid, and thresholds pixels against the average intensity.
 */
export function computePerceptualHash(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  sw: number,
  sh: number,
  size: number = 16
): string {
  // Use intermediate resolution for subtitle removal
  const cleanW = Math.min(sw, 160);
  const cleanH = Math.min(sh, 90);

  const cleanData = getSharedCleanCanvas(cleanW, cleanH);
  if (!cleanData) {
    return '0'.repeat(size * size);
  }
  const { canvas: cleanCanvas, ctx: cleanCtx } = cleanData;

  // Draw region to clean canvas
  cleanCtx.drawImage(ctx.canvas, sx, sy, sw, sh, 0, 0, cleanW, cleanH);

  // Clean subtitles at high-resolution
  const imgData = cleanCtx.getImageData(0, 0, cleanW, cleanH);
  cleanSubtitles(imgData.data, cleanW, cleanH);
  cleanCtx.putImageData(imgData, 0, 0);

  // Draw cleaned canvas to the 16x16 target canvas
  const tempData = getSharedTempCanvas(size);
  if (!tempData) {
    return '0'.repeat(size * size);
  }
  const { canvas: tempCanvas, ctx: tempCtx } = tempData;

  tempCtx.drawImage(cleanCanvas, 0, 0, cleanW, cleanH, 0, 0, size, size);

  // Extract pixel data
  const targetImgData = tempCtx.getImageData(0, 0, size, size);
  const pixels = targetImgData.data;

  // Calculate grayscale values and total intensity
  const grayscale: number[] = [];
  let totalIntensity = 0;

  for (let i = 0; i < pixels.length; i += 4) {
    const r = pixels[i];
    const g = pixels[i + 1];
    const b = pixels[i + 2];
    
    // Standard perceptual luminance coefficients
    const gray = 0.299 * r + 0.587 * g + 0.114 * b;
    grayscale.push(gray);
    totalIntensity += gray;
  }

  // Calculate average intensity across the frame grid
  const averageIntensity = totalIntensity / grayscale.length;

  // Build binary hash: '1' if above or equal to average, '0' if below
  let hash = '';
  for (let i = 0; i < grayscale.length; i++) {
    hash += grayscale[i] >= averageIntensity ? '1' : '0';
  }

  return hash;
}

/**
 * Computes BOTH a robust perceptual average hash (aHash) and a 4x4 spatial feature
 * signature tracking color grid, skin-tone presence, and high-frequency edge details.
 */
export function computePerceptualAndFeatureHash(
  ctx: CanvasRenderingContext2D,
  sx: number,
  sy: number,
  sw: number,
  sh: number,
  size: number = 16
): CropFingerprint {
  // Use intermediate resolution for subtitle removal
  const cleanW = Math.min(sw, 160);
  const cleanH = Math.min(sh, 90);

  const cleanData = getSharedCleanCanvas(cleanW, cleanH);
  if (!cleanData) {
    return {
      hash: '0'.repeat(size * size),
      signature: { colorGrid: [], skinScoreGrid: [], detailGrid: [] }
    };
  }
  const { canvas: cleanCanvas, ctx: cleanCtx } = cleanData;

  // Draw region to clean canvas
  cleanCtx.drawImage(ctx.canvas, sx, sy, sw, sh, 0, 0, cleanW, cleanH);

  // Clean subtitles at high-resolution
  const imgData = cleanCtx.getImageData(0, 0, cleanW, cleanH);
  cleanSubtitles(imgData.data, cleanW, cleanH);
  cleanCtx.putImageData(imgData, 0, 0);

  // Draw cleaned canvas to the 16x16 target canvas
  const tempData = getSharedTempCanvas(size);
  if (!tempData) {
    return {
      hash: '0'.repeat(size * size),
      signature: { colorGrid: [], skinScoreGrid: [], detailGrid: [] }
    };
  }
  const { canvas: tempCanvas, ctx: tempCtx } = tempData;

  tempCtx.drawImage(cleanCanvas, 0, 0, cleanW, cleanH, 0, 0, size, size);

  // Extract pixel data
  const targetImgData = tempCtx.getImageData(0, 0, size, size);
  const pixels = targetImgData.data;

  // Calculate grayscale values and total intensity
  const grayscale: number[] = [];
  let totalIntensity = 0;

  for (let i = 0; i < pixels.length; i += 4) {
    const r = pixels[i];
    const g = pixels[i + 1];
    const b = pixels[i + 2];
    
    // Standard perceptual luminance coefficients
    const gray = 0.299 * r + 0.587 * g + 0.114 * b;
    grayscale.push(gray);
    totalIntensity += gray;
  }

  // Calculate average intensity across the frame grid
  const averageIntensity = totalIntensity / grayscale.length;

  // Build binary hash: '1' if above or equal to average, '0' if below
  let hash = '';
  for (let i = 0; i < grayscale.length; i++) {
    hash += grayscale[i] >= averageIntensity ? '1' : '0';
  }

  // Build 4x4 spatial color and feature grids
  const colorGrid: number[] = [];
  const skinScoreGrid: number[] = [];
  const detailGrid: number[] = [];

  const gridSize = 4; // 4x4 blocks
  const blockSize = size / gridSize; // 16 / 4 = 4 pixels per block dimension

  for (let by = 0; by < gridSize; by++) {
    for (let bx = 0; bx < gridSize; bx++) {
      let sumR = 0;
      let sumG = 0;
      let sumB = 0;
      let skinPixels = 0;
      const blockGrays: number[] = [];

      for (let py = 0; py < blockSize; py++) {
        for (let px = 0; px < blockSize; px++) {
          const pixelX = bx * blockSize + px;
          const pixelY = by * blockSize + py;
          const idx = (pixelY * size + pixelX) * 4;

          const r = pixels[idx];
          const g = pixels[idx + 1];
          const b = pixels[idx + 2];

          sumR += r;
          sumG += g;
          sumB += b;

          // Kovac's RGB Skin Color Classification Rule
          // Robust to complex lightings, background colors, skin tones, and character postures
          const isSkin = r > 95 && g > 40 && b > 20 &&
                         (Math.max(r, g, b) - Math.min(r, g, b)) > 15 &&
                         Math.abs(r - g) > 15 &&
                         r > g && r > b;
          if (isSkin) {
            skinPixels++;
          }

          // Grayscale value for local detail analysis
          const gray = grayscale[pixelY * size + pixelX];
          blockGrays.push(gray);
        }
      }

      const totalPixels = blockSize * blockSize; // 16

      // Averages normalized to 0-1 range
      colorGrid.push((sumR / totalPixels) / 255);
      colorGrid.push((sumG / totalPixels) / 255);
      colorGrid.push((sumB / totalPixels) / 255);

      // Skin tone score ratio in this sector
      skinScoreGrid.push(skinPixels / totalPixels);

      // Local standard deviation representing contrast, lines, eyes, clothing details
      const meanGray = blockGrays.reduce((sum, val) => sum + val, 0) / totalPixels;
      const variance = blockGrays.reduce((sum, val) => sum + Math.pow(val - meanGray, 2), 0) / totalPixels;
      const stddev = Math.sqrt(variance);
      
      // Standard deviation ranges 0 to 127.5 (max theoretical). Normalize to 0-1
      detailGrid.push(Math.min(stddev / 127.5, 1.0));
    }
  }

  return {
    hash,
    signature: {
      colorGrid,
      skinScoreGrid,
      detailGrid
    }
  };
}

/**
 * Computes a full suite of crop-and-zoom robust hashes for a single video frame.
 */
export function computeFrameFingerprint(
  ctx: CanvasRenderingContext2D,
  frameIndex: number,
  timestamp: number
): FrameFingerprint {
  const W = ctx.canvas.width;
  const H = ctx.canvas.height;
  const subHashes: string[] = [];
  const signatures: Record<string, ColorAndFeatureSignature> = {};

  // Helper to process a crop region, store its hash and signature
  const processCrop = (label: string, sx: number, sy: number, sw: number, sh: number) => {
    const res = computePerceptualAndFeatureHash(ctx, sx, sy, sw, sh, 16);
    signatures[label] = res.signature;
    return res.hash;
  };

  // 1. Full Frame Hash
  const hash = processCrop('Full Frame', 0, 0, W, H);
  subHashes.push(hash);

  // 2. 9:16 Crops (if aspect ratio is wider than 9:16)
  const aspect = W / H;
  const cropW = H * 0.5625;
  let hashCenter916 = hash;
  let hashLeft916 = hash;
  let hashRight916 = hash;
  let hashCenterLeft916 = hash;
  let hashCenterRight916 = hash;

  if (aspect > 0.5625) {
    const span = W - cropW;
    
    // Left
    hashLeft916 = processCrop('Left 9:16 Crop', 0, 0, cropW, H);
    subHashes.push(hashLeft916);

    // Center-Left
    hashCenterLeft916 = processCrop('Center-Left 9:16 Crop', span * 0.25, 0, cropW, H);
    subHashes.push(hashCenterLeft916);

    // Center
    hashCenter916 = processCrop('Center 9:16 Crop', span * 0.5, 0, cropW, H);
    subHashes.push(hashCenter916);

    // Center-Right
    hashCenterRight916 = processCrop('Center-Right 9:16 Crop', span * 0.75, 0, cropW, H);
    subHashes.push(hashCenterRight916);

    // Right
    hashRight916 = processCrop('Right 9:16 Crop', span, 0, cropW, H);
    subHashes.push(hashRight916);
  } else {
    // If it's already a tall portrait format (Shorts video itself), sample top/center/bottom vertical segments
    const cropH = W / 0.5625;
    if (H > cropH) {
      const spanY = H - cropH;
      const hashTop = processCrop('Top Crop', 0, 0, W, cropH);
      const hashMid = processCrop('Center Crop', 0, spanY * 0.5, W, cropH);
      const hashBot = processCrop('Bottom Crop', 0, spanY, W, cropH);
      subHashes.push(hashTop, hashMid, hashBot);
    }
  }

  // 3. Zoom 1.25x Crops
  const w125 = W / 1.25;
  const h125 = H / 1.25;
  const sy125 = (H - h125) / 2;
  const sx125_center = (W - w125) / 2;
  
  const hashZoom125Center = processCrop('Zoom 1.25x Center', sx125_center, sy125, w125, h125);
  subHashes.push(hashZoom125Center);
  
  const hashZoom125Left = processCrop('Zoom 1.25x Left', 0, sy125, w125, h125);
  subHashes.push(hashZoom125Left);
  
  const hashZoom125Right = processCrop('Zoom 1.25x Right', W - w125, sy125, w125, h125);
  subHashes.push(hashZoom125Right);

  // 4. Zoom 1.5x Crops
  const w15 = W / 1.5;
  const h15 = H / 1.5;
  const sy15 = (H - h15) / 2;
  const sx15_center = (W - w15) / 2;

  const hashZoom15Center = processCrop('Zoom 1.5x Center', sx15_center, sy15, w15, h15);
  subHashes.push(hashZoom15Center);
  
  const hashZoom15Left = processCrop('Zoom 1.5x Left', 0, sy15, w15, h15);
  subHashes.push(hashZoom15Left);
  
  const hashZoom15Right = processCrop('Zoom 1.5x Right', W - w15, sy15, w15, h15);
  subHashes.push(hashZoom15Right);

  // 5. Zoom 2.0x Crop
  const w20 = W / 2.0;
  const h20 = H / 2.0;
  const sy20 = (H - h20) / 2;
  const sx20_center = (W - w20) / 2;
  
  const hashZoom20Center = processCrop('Zoom 2.0x Center', sx20_center, sy20, w20, h20);
  subHashes.push(hashZoom20Center);

  // Filter out any potential identical hashes to keep sequence comparison fast
  const uniqueHashes = Array.from(new Set(subHashes));

  return {
    frameIndex,
    timestamp: Number(timestamp.toFixed(4)),
    hash,
    hashLeft916,
    hashCenterLeft916,
    hashCenter916,
    hashCenterRight916,
    hashRight916,
    hashZoom125Center,
    hashZoom125Left,
    hashZoom125Right,
    hashZoom15: hashZoom15Center,
    hashZoom15Left,
    hashZoom15Right,
    hashZoom20: hashZoom20Center,
    hashes: uniqueHashes,
    signatures
  };
}

/**
 * Calculates the crop-and-zoom resistant similarity between a short frame and a movie frame,
 * identifying the specific spatial region on the movie frame that matches best.
 */
export function getFrameSimilarityWithRegion(sf: FrameFingerprint, mf: FrameFingerprint) {
  const mfCandidates = [
    { label: 'Full Frame', hash: mf.hash },
    { label: 'Left 9:16 Crop', hash: mf.hashLeft916 },
    { label: 'Center-Left 9:16 Crop', hash: mf.hashCenterLeft916 },
    { label: 'Center 9:16 Crop', hash: mf.hashCenter916 },
    { label: 'Center-Right 9:16 Crop', hash: mf.hashCenterRight916 },
    { label: 'Right 9:16 Crop', hash: mf.hashRight916 },
    { label: 'Zoom 1.25x Center', hash: mf.hashZoom125Center },
    { label: 'Zoom 1.25x Left', hash: mf.hashZoom125Left },
    { label: 'Zoom 1.25x Right', hash: mf.hashZoom125Right },
    { label: 'Zoom 1.5x Center', hash: mf.hashZoom15 },
    { label: 'Zoom 1.5x Left', hash: mf.hashZoom15Left },
    { label: 'Zoom 1.5x Right', hash: mf.hashZoom15Right },
    { label: 'Zoom 2.0x Center', hash: mf.hashZoom20 }
  ].filter(c => !!c.hash);

  const sfCandidates = [
    { label: 'Full Frame', hash: sf.hash },
    { label: 'Center 9:16 Crop', hash: sf.hashCenter916 },
    { label: 'Zoom 1.25x Center', hash: sf.hashZoom125Center },
    { label: 'Zoom 1.5x Center', hash: sf.hashZoom15 },
    { label: 'Zoom 2.0x Center', hash: sf.hashZoom20 }
  ].filter(c => !!c.hash);

  let maxSim = 0;
  let bestRegion = 'Full Frame';
  let bestStructSim = 0;
  let bestColorSim = 100;
  let bestSkinSim = 100;
  let bestDetailSim = 100;

  for (const sfc of sfCandidates) {
    for (const mfc of mfCandidates) {
      // 1. Structural binary average hash similarity
      const structSim = getHashSimilarity(sfc.hash!, mfc.hash!);

      // 2. Color, Character, and Background Feature Double Check
      let signatureSim = 100;
      let colorSim = 100;
      let skinSim = 100;
      let detailSim = 100;

      if (sf.signatures && mf.signatures && sf.signatures[sfc.label] && mf.signatures[mfc.label]) {
        const sig1 = sf.signatures[sfc.label];
        const sig2 = mf.signatures[mfc.label];

        // R, G, B color layout match across the 4x4 spatial blocks
        let colorDiff = 0;
        for (let i = 0; i < sig1.colorGrid.length; i++) {
          colorDiff += Math.abs(sig1.colorGrid[i] - sig2.colorGrid[i]);
        }
        colorSim = (1 - (colorDiff / sig1.colorGrid.length)) * 100;

        // Skin layout match (human faces, heads, neck, arms, skin exposures)
        let skinDiff = 0;
        for (let i = 0; i < sig1.skinScoreGrid.length; i++) {
          skinDiff += Math.abs(sig1.skinScoreGrid[i] - sig2.skinScoreGrid[i]);
        }
        skinSim = (1 - (skinDiff / sig1.skinScoreGrid.length)) * 100;

        // Texture/contrast density (background lines, eyes, clothing creases, outlines)
        let detailDiff = 0;
        for (let i = 0; i < sig1.detailGrid.length; i++) {
          detailDiff += Math.abs(sig1.detailGrid[i] - sig2.detailGrid[i]);
        }
        detailSim = (1 - (detailDiff / sig1.detailGrid.length)) * 100;

        // Multi-dimensional layout verification: 50% colors/ambient, 25% skin/character, 25% micro-details/eyes/lines
        signatureSim = (colorSim * 0.5) + (skinSim * 0.25) + (detailSim * 0.25);
      }

      // Weighting: 84% fingerprint structure, 16% multi-dimensional color/background/eyes/hands double check
      // This enforces robust structural matching while using color/posture layout signature for secondary verification.
      const finalSim = (structSim * 0.84) + (signatureSim * 0.16);

      if (finalSim > maxSim) {
        maxSim = finalSim;
        bestRegion = mfc.label;
        bestStructSim = structSim;
        bestColorSim = colorSim;
        bestSkinSim = skinSim;
        bestDetailSim = detailSim;
      }
    }
  }

  return {
    similarity: maxSim,
    region: bestRegion,
    structSimilarity: bestStructSim,
    colorSimilarity: bestColorSim,
    skinSimilarity: bestSkinSim,
    detailSimilarity: bestDetailSim
  };
}

/**
 * Calculates the crop-and-zoom resistant similarity between a short frame and a movie frame.
 * It compares the primary hashes as well as sub-region/zoom crops to find the best spatial match.
 */
export function getFrameSimilarity(sf: FrameFingerprint, mf: FrameFingerprint): number {
  return getFrameSimilarityWithRegion(sf, mf).similarity;
}

/**
 * Calculates the Hamming distance between two binary hashes.
 */
export function calculateHammingDistance(hash1: string, hash2: string): number {
  let distance = 0;
  const len = Math.min(hash1.length, hash2.length);
  for (let i = 0; i < len; i++) {
    if (hash1[i] !== hash2[i]) {
      distance++;
    }
  }
  return distance;
}

/**
 * Calculates similarity percentage between two hashes.
 */
export function getHashSimilarity(hash1: string, hash2: string): number {
  const distance = calculateHammingDistance(hash1, hash2);
  const maxLen = hash1.length;
  return ((maxLen - distance) / maxLen) * 100;
}

/**
 * Groups raw frame-by-frame matches into coherent continuous temporal segments.
 * Eliminates single-frame outliers and enforces sequence continuity.
 * 
 * @param shortFingerprints List of fingerprints from the short video
 * @param movieFingerprints Database of fingerprints from the full movie
 * @param minSimilarity Threshold similarity (e.g., 85%) to consider a frame matched
 * @param minDuration Minimum duration in seconds to form a valid matched segment
 * @param frameTolerance Maximum frame deviation to allow in sequence continuity (usually 2-3 frames)
 */
export function groundMatchedSegments(
  shortFingerprints: FrameFingerprint[],
  movieFingerprints: FrameFingerprint[],
  minSimilarity: number = 82,
  minDuration: number = 0.5,
  frameTolerance: number = 3
): MatchedSegment[] {
  if (shortFingerprints.length === 0 || movieFingerprints.length === 0) {
    return [];
  }

  console.time("[TIMING] Matching/alignment Data Prep");
  
  function popcount32(x) {
    x = x - ((x >>> 1) & 0x55555555);
    x = (x & 0x33333333) + ((x >>> 2) & 0x33333333);
    x = (x + (x >>> 4)) & 0x0f0f0f0f;
    x = x + (x >>> 8);
    x = x + (x >>> 16);
    return x & 0x3f;
  }

  function stringToUint32Array(str) {
    if (!str || str.length !== 256) return null;
    const arr = new Uint32Array(8);
    for (let i = 0; i < 8; i++) {
      let val = 0;
      for (let j = 0; j < 32; j++) {
        val = (val << 1) | (str[i * 32 + j] === '1' ? 1 : 0);
      }
      arr[i] = val >>> 0;
    }
    return arr;
  }

  function parseFingerprint(f) {
    return {
      fp: f,
      hashes: [
        stringToUint32Array(f.hash),
        stringToUint32Array(f.hashCenter916),
        stringToUint32Array(f.hashLeft916),
        stringToUint32Array(f.hashCenterLeft916),
        stringToUint32Array(f.hashCenterRight916),
        stringToUint32Array(f.hashRight916),
        stringToUint32Array(f.hashZoom125Center),
        stringToUint32Array(f.hashZoom125Left),
        stringToUint32Array(f.hashZoom125Right),
        stringToUint32Array(f.hashZoom15),
        stringToUint32Array(f.hashZoom15Left),
        stringToUint32Array(f.hashZoom15Right),
        stringToUint32Array(f.hashZoom20)
      ]
    };
  }

  const sfFast = shortFingerprints.map(parseFingerprint);
  const mfFast = movieFingerprints.map(parseFingerprint);

  function getFastSim(f1, f2) {
    let maxSim = 0;
    for (let k = 0; k < 13; k++) {
      const arr1 = f1.hashes[k];
      const arr2 = f2.hashes[k];
      if (!arr1 || !arr2) continue;
      
      let diff = 0;
      diff += popcount32(arr1[0] ^ arr2[0]);
      diff += popcount32(arr1[1] ^ arr2[1]);
      diff += popcount32(arr1[2] ^ arr2[2]);
      diff += popcount32(arr1[3] ^ arr2[3]);
      diff += popcount32(arr1[4] ^ arr2[4]);
      diff += popcount32(arr1[5] ^ arr2[5]);
      diff += popcount32(arr1[6] ^ arr2[6]);
      diff += popcount32(arr1[7] ^ arr2[7]);
      
      const sim = ((256 - diff) / 256) * 100;
      if (sim > maxSim) maxSim = sim;
    }
    return maxSim;
  }

  console.timeEnd("[TIMING] Matching/alignment Data Prep");

  const segments: MatchedSegment[] = [];

  // --- PASS 1: HIGH CONFIDENCE MATCHES (similarity >= minSimilarity) ---
  console.time("[TIMING] Matching/alignment Pass 1");
  let i = 0;
  while (i < sfFast.length) {
    const sf = sfFast[i];
    
    let bestMovieIdx = -1;
    let highestSim = 0;

    // Full brute-force scan, but extremely fast
    for (let j = 0; j < mfFast.length; j++) {
      const sim = getFastSim(sf, mfFast[j]);
      if (sim >= minSimilarity && sim > highestSim) {
        highestSim = sim;
        bestMovieIdx = j;
      }
    }

    if (bestMovieIdx !== -1) {
      const candidateShort = [sf];
      const candidateMovie = [mfFast[bestMovieIdx]];
      const candidateSims = [highestSim];

      let nextShortIdx = i + 1;
      let nextMovieIdx = bestMovieIdx + 1;

      while (nextShortIdx < sfFast.length && nextMovieIdx < mfFast.length) {
        const nextSf = sfFast[nextShortIdx];
        const nextMf = mfFast[nextMovieIdx];

        const directSim = getFastSim(nextSf, nextMf);
        if (directSim >= minSimilarity) {
          candidateShort.push(nextSf);
          candidateMovie.push(nextMf);
          candidateSims.push(directSim);
          nextShortIdx++;
          nextMovieIdx++;
        } else {
          let foundLookAhead = false;
          let bestLookAheadShortIdx = -1;
          let bestLookAheadMovieIdx = -1;
          let bestLookAheadSim = 0;

          for (let d = 1; d <= 20; d++) {
            if (foundLookAhead) break;
            for (let offsetShort = 0; offsetShort <= Math.min(10, d); offsetShort++) {
              const offsetMovie = d - offsetShort;
              if (offsetMovie > 10 || offsetMovie < 0) continue;

              const sIdx = nextShortIdx + offsetShort;
              const mIdx = nextMovieIdx + offsetMovie;

              if (sIdx < sfFast.length && mIdx < mfFast.length) {
                const sim = getFastSim(sfFast[sIdx], mfFast[mIdx]);
                if (sim >= minSimilarity) {
                  if (sim > bestLookAheadSim) {
                    bestLookAheadSim = sim;
                    bestLookAheadShortIdx = sIdx;
                    bestLookAheadMovieIdx = mIdx;
                    foundLookAhead = true;
                  }
                }
              }
            }
          }

          if (foundLookAhead && bestLookAheadShortIdx !== -1 && bestLookAheadMovieIdx !== -1) {
            candidateShort.push(sfFast[bestLookAheadShortIdx]);
            candidateMovie.push(mfFast[bestLookAheadMovieIdx]);
            candidateSims.push(bestLookAheadSim);
            nextShortIdx = bestLookAheadShortIdx + 1;
            nextMovieIdx = bestLookAheadMovieIdx + 1;
          } else {
            break;
          }
        }
      }

      if (candidateShort.length >= 9) {
        const startShort = candidateShort[0].fp;
        const endShort = candidateShort[candidateShort.length - 1].fp;
        const startMovie = candidateMovie[0].fp;
        const endMovie = candidateMovie[candidateMovie.length - 1].fp;

        const avgConfidence = candidateSims.reduce((a, b) => a + b, 0) / candidateSims.length;

        const matchSequence = candidateShort.map((f, idx) => ({
          shortTime: f.fp.timestamp,
          movieTime: candidateMovie[idx].fp.timestamp,
          similarity: candidateSims[idx]
        }));

        segments.push({
          id: `match_${Math.random().toString(36).substring(2, 9)}`,
          shortStart: Number(startShort.timestamp.toFixed(3)),
          shortEnd: Number(endShort.timestamp.toFixed(3)),
          movieStart: Number(startMovie.timestamp.toFixed(3)),
          movieEnd: Number(endMovie.timestamp.toFixed(3)),
          confidence: Number(avgConfidence.toFixed(1)),
          frameCount: candidateShort.length,
          matchSequence
        });

        i = nextShortIdx;
      } else {
        i++;
      }
    } else {
      i++;
    }
  }

  console.timeEnd("[TIMING] Matching/alignment Pass 1");

  // --- PASS 2: APPROXIMATE / LOW CONFIDENCE MATCHES (similarity >= 40.0%) ---
  console.time("[TIMING] Matching/alignment Pass 2");
  
  const fallbackSegments: MatchedSegment[] = [];
  i = 0;
  while (i < sfFast.length) {
    const sf = sfFast[i];

    const isCovered = segments.some(seg => sf.fp.timestamp >= seg.shortStart && sf.fp.timestamp <= seg.shortEnd);
    if (isCovered) {
      i++;
      continue;
    }

    let bestMovieIdx = -1;
    let highestSim = 0;

    for (let j = 0; j < mfFast.length; j++) {
      const mf = mfFast[j];
      const isMovieFrameCovered = segments.some(seg => mf.fp.timestamp >= seg.movieStart && mf.fp.timestamp <= seg.movieEnd);
      
      if (!isMovieFrameCovered) {
        const sim = getFastSim(sf, mf);
        if (sim >= 40.0 && sim < minSimilarity && sim > highestSim) {
          highestSim = sim;
          bestMovieIdx = j;
        }
      }
    }

    if (bestMovieIdx !== -1) {
      const candidateShort = [sf];
      const candidateMovie = [mfFast[bestMovieIdx]];
      const candidateSims = [highestSim];

      let nextShortIdx = i + 1;
      let nextMovieIdx = bestMovieIdx + 1;

      while (nextShortIdx < sfFast.length && nextMovieIdx < mfFast.length) {
        const nextSf = sfFast[nextShortIdx];
        
        const isNextSfCovered = segments.some(seg => nextSf.fp.timestamp >= seg.shortStart && nextSf.fp.timestamp <= seg.shortEnd);
        if (isNextSfCovered) {
          break;
        }

        const nextMf = mfFast[nextMovieIdx];
        const directSim = getFastSim(nextSf, nextMf);

        if (directSim >= 40.0) {
          candidateShort.push(nextSf);
          candidateMovie.push(nextMf);
          candidateSims.push(directSim);
          nextShortIdx++;
          nextMovieIdx++;
        } else {
          let foundLookAhead = false;
          let bestLookAheadShortIdx = -1;
          let bestLookAheadMovieIdx = -1;
          let bestLookAheadSim = 0;

          for (let d = 1; d <= 20; d++) {
            if (foundLookAhead) break;
            for (let offsetShort = 0; offsetShort <= Math.min(10, d); offsetShort++) {
              const offsetMovie = d - offsetShort;
              if (offsetMovie > 10 || offsetMovie < 0) continue;

              const sIdx = nextShortIdx + offsetShort;
              const mIdx = nextMovieIdx + offsetMovie;

              if (sIdx < sfFast.length && mIdx < mfFast.length) {
                const testMf = mfFast[mIdx];
                const isMovieCovered = segments.some(seg => testMf.fp.timestamp >= seg.movieStart && testMf.fp.timestamp <= seg.movieEnd);
                
                if (!isMovieCovered) {
                  const sim = getFastSim(sfFast[sIdx], testMf);
                  if (sim >= 40.0) {
                    if (sim > bestLookAheadSim) {
                      bestLookAheadSim = sim;
                      bestLookAheadShortIdx = sIdx;
                      bestLookAheadMovieIdx = mIdx;
                      foundLookAhead = true;
                    }
                  }
                }
              }
            }
          }

          if (foundLookAhead && bestLookAheadShortIdx !== -1 && bestLookAheadMovieIdx !== -1) {
            candidateShort.push(sfFast[bestLookAheadShortIdx]);
            candidateMovie.push(mfFast[bestLookAheadMovieIdx]);
            candidateSims.push(bestLookAheadSim);
            nextShortIdx = bestLookAheadShortIdx + 1;
            nextMovieIdx = bestLookAheadMovieIdx + 1;
          } else {
            break;
          }
        }
      }

      if (candidateShort.length >= 9) {
        const startShort = candidateShort[0].fp;
        const endShort = candidateShort[candidateShort.length - 1].fp;
        const startMovie = candidateMovie[0].fp;
        const endMovie = candidateMovie[candidateMovie.length - 1].fp;

        const avgConfidence = candidateSims.reduce((a, b) => a + b, 0) / candidateSims.length;

        const matchSequence = candidateShort.map((f, idx) => ({
          shortTime: f.fp.timestamp,
          movieTime: candidateMovie[idx].fp.timestamp,
          similarity: candidateSims[idx]
        }));

        const durationOffset = startShort.timestamp === endShort.timestamp ? 0.041 : 0;

        fallbackSegments.push({
          id: `approx_${Math.random().toString(36).substring(2, 9)}`,
          shortStart: Number(startShort.timestamp.toFixed(3)),
          shortEnd: Number((endShort.timestamp + durationOffset).toFixed(3)),
          movieStart: Number(startMovie.timestamp.toFixed(3)),
          movieEnd: Number((endMovie.timestamp + durationOffset).toFixed(3)),
          confidence: Number(avgConfidence.toFixed(1)),
          frameCount: candidateShort.length,
          matchSequence,
          isApproximate: true
        });

        i = nextShortIdx;
      } else {
        i++;
      }
    } else {
      i++;
    }
  }

  console.timeEnd("[TIMING] Matching/alignment Pass 2");

  // Combine both high-confidence and approximate segmentsts
  const allSegments = [...segments, ...fallbackSegments];

  // Robust priority-based greedy deduplication pass to prevent overlapping duplicate segment mappings:
  // 1. High-confidence (non-approximate) first
  // 2. Higher confidence percentage
  // 3. More matched frames
  const sortedByPriority = [...allSegments].sort((a, b) => {
    const aApprox = a.isApproximate ? 1 : 0;
    const bApprox = b.isApproximate ? 1 : 0;
    if (aApprox !== bApprox) {
      return aApprox - bApprox; // non-approximate first
    }
    if (b.confidence !== a.confidence) {
      return b.confidence - a.confidence; // higher confidence first
    }
    return b.frameCount - a.frameCount; // more frames first
  });

  const finalAccepted: MatchedSegment[] = [];

  for (const candidate of sortedByPriority) {
    let hasConflict = false;
    for (const accepted of finalAccepted) {
      // Check overlap on the short clip timeline
      const overlapStart = Math.max(candidate.shortStart, accepted.shortStart);
      const overlapEnd = Math.min(candidate.shortEnd, accepted.shortEnd);
      
      if (overlapStart < overlapEnd) {
        const overlapDuration = overlapEnd - overlapStart;
        // If they overlap by more than 0.15 seconds (about 3-4 frames), we consider it a conflict
        if (overlapDuration > 0.15) {
          hasConflict = true;
          break;
        }
      }

      // Check overlap on the movie timeline to prevent "same scene mapped multiple times"
      const overlapMovieStart = Math.max(candidate.movieStart, accepted.movieStart);
      const overlapMovieEnd = Math.min(candidate.movieEnd, accepted.movieEnd);
      
      if (overlapMovieStart < overlapMovieEnd) {
        const overlapMovieDuration = overlapMovieEnd - overlapMovieStart;
        if (overlapMovieDuration > 0.15) {
          hasConflict = true;
          break;
        }
      }
    }

    if (!hasConflict) {
      finalAccepted.push(candidate);
    }
  }

  // Sort final accepted segments chronologically according to their appearance in the short video timeline
  finalAccepted.sort((a, b) => a.shortStart - b.shortStart);

  return finalAccepted;
}

function finalizeSegment(
  rawSeg: { shortFrames: FrameFingerprint[]; movieFrames: FrameFingerprint[]; similarities: number[] },
  output: MatchedSegment[],
  minDuration: number
) {
  const startShort = rawSeg.shortFrames[0];
  const endShort = rawSeg.shortFrames[rawSeg.shortFrames.length - 1];
  const startMovie = rawSeg.movieFrames[0];
  const endMovie = rawSeg.movieFrames[rawSeg.movieFrames.length - 1];

  const durationShort = endShort.timestamp - startShort.timestamp;

  if (durationShort >= minDuration && rawSeg.shortFrames.length >= 3) {
    const avgConfidence = rawSeg.similarities.reduce((a, b) => a + b, 0) / rawSeg.similarities.length;
    
    // Create detailed frame mapping sequence
    const matchSequence = rawSeg.shortFrames.map((sf, index) => ({
      shortTime: sf.timestamp,
      movieTime: rawSeg.movieFrames[index].timestamp,
      similarity: rawSeg.similarities[index]
    }));

    output.push({
      id: `match_${Math.random().toString(36).substring(2, 9)}`,
      shortStart: Number(startShort.timestamp.toFixed(3)),
      shortEnd: Number(endShort.timestamp.toFixed(3)),
      movieStart: Number(startMovie.timestamp.toFixed(3)),
      movieEnd: Number(endMovie.timestamp.toFixed(3)),
      confidence: Number(avgConfidence.toFixed(1)),
      frameCount: rawSeg.shortFrames.length,
      matchSequence
    });
  }
}
