import { computeFrameFingerprint } from './fingerprint';

self.onmessage = async (e: MessageEvent) => {
  const { imageBitmap, frameIndex, timestamp } = e.data;
  if (!imageBitmap) {
    self.postMessage({
      status: 'error',
      frameIndex,
      error: 'No imageBitmap provided'
    });
    return;
  }

  try {
    // Create an OffscreenCanvas of exactly 160x90 to match the single-threaded calibration canvas
    const canvas = new OffscreenCanvas(160, 90);
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error("Could not get OffscreenCanvas 2D context");
    }
    
    // Draw and downscale the image bitmap onto the 160x90 offscreen canvas
    ctx.drawImage(imageBitmap, 0, 0, 160, 90);
    
    // Compute the high-precision robust frame fingerprint
    const fingerprint = computeFrameFingerprint(ctx as any, frameIndex, timestamp);
    
    // Close the imageBitmap to free GPU / memory resources immediately
    imageBitmap.close();
    
    // Post the successful result back to the main thread
    self.postMessage({
      status: 'success',
      frameIndex,
      fingerprint
    });
  } catch (err: any) {
    if (imageBitmap) {
      try { imageBitmap.close(); } catch (_) {}
    }
    self.postMessage({
      status: 'error',
      frameIndex,
      error: err?.message || String(err)
    });
  }
};
