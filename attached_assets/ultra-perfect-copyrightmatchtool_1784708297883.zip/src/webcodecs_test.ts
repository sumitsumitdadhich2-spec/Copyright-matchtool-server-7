// @ts-ignore
import MP4Box from 'mp4box';

export async function extractFramesLinearWebCodecs(
  file: File,
  targetFps: number,
  onFrame: (frame: VideoFrame, t: number, frameIdx: number) => void,
  onProgress: (progress: number) => void
): Promise<void> {
  return new Promise((resolve, reject) => {
    if (!window.VideoDecoder) {
      reject(new Error("WebCodecs VideoDecoder not supported."));
      return;
    }

    const mp4boxfile = MP4Box.createFile();
    let videoTrack: any = null;
    let decoder: VideoDecoder | null = null;
    let nextTargetFrameIdx = 0;
    
    mp4boxfile.onError = (e: any) => reject(e);
    
    mp4boxfile.onReady = (info: any) => {
      videoTrack = info.videoTracks[0];
      if (!videoTrack) {
        reject(new Error("No video track found"));
        return;
      }
      
      const config: VideoDecoderConfig = {
        codec: videoTrack.codec,
      };
      
      if (videoTrack.codec.startsWith('avc1')) {
        const trak = mp4boxfile.getTrackById(videoTrack.id);
        const stsd = trak.mdia.minf.stbl.stsd;
        for (const entry of stsd.entries) {
          if (entry.avcC) {
             const stream = new MP4Box.DataStream(undefined, 0, MP4Box.DataStream.BIG_ENDIAN);
             entry.avcC.write(stream);
             config.description = new Uint8Array(stream.buffer, 8);
             break;
          }
        }
      }

      decoder = new VideoDecoder({
        output: (frame) => {
          const t = frame.timestamp / 1e6;
          const frameIdx = Math.round(t * targetFps);
          
          if (frameIdx >= nextTargetFrameIdx) {
            onFrame(frame, t, frameIdx);
            nextTargetFrameIdx = frameIdx + 1;
          }
          frame.close();
        },
        error: (e) => reject(e)
      });
      
      decoder.configure(config);
      mp4boxfile.setExtractionOptions(videoTrack.id, null, { nbSamples: Infinity });
      mp4boxfile.start();
    };

    let totalSamples = 0;
    let samplesProcessed = 0;

    mp4boxfile.onSamples = (id: number, user: any, samples: any[]) => {
      totalSamples += samples.length;
      for (const sample of samples) {
        const type = sample.is_sync ? 'key' : 'delta';
        const chunk = new EncodedVideoChunk({
          type,
          timestamp: (sample.cts / sample.timescale) * 1e6,
          duration: (sample.duration / sample.timescale) * 1e6,
          data: sample.data
        });
        decoder?.decode(chunk);
        samplesProcessed++;
        
        if (samplesProcessed % 60 === 0 && videoTrack) {
           onProgress((samplesProcessed / videoTrack.nb_samples) * 100);
        }
      }
    };

    let offset = 0;
    const chunkSize = 10 * 1024 * 1024;
    
    async function readChunk() {
      try {
        while (offset < file.size) {
          if (decoder && decoder.decodeQueueSize > 200) {
            await new Promise(r => setTimeout(r, 50));
            continue;
          }
          const slice = file.slice(offset, offset + chunkSize);
          const buffer = await slice.arrayBuffer();
          (buffer as any).fileStart = offset;
          offset += buffer.byteLength;
          mp4boxfile.appendBuffer(buffer);
        }
        mp4boxfile.flush();
        if (decoder) {
          await decoder.flush();
        }
        resolve();
      } catch (err) {
        reject(err);
      }
    }
    
    readChunk();
  });
}
