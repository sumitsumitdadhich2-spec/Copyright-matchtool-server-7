// @ts-ignore
import MP4Box, { MP4File } from 'mp4box';

export class WebCodecsExtractor {
  // Implementation will go here
}
