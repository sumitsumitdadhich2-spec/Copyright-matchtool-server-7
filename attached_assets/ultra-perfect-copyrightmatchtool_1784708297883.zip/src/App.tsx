/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Video,
  Zap,
  Play,
  Pause,
  RefreshCw,
  Sliders,
  Download,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Activity,
  FileJson,
  Layers,
  UploadCloud,
  FileVideo,
  ExternalLink,
  RotateCcw,
  Cpu,
  CheckSquare
} from 'lucide-react';

import {
  FrameFingerprint,
  MatchedSegment,
  computePerceptualHash,
  getHashSimilarity,
  groundMatchedSegments,
  computeFrameFingerprint,
  getFrameSimilarity,
  getFrameSimilarityWithRegion
} from './utils/fingerprint';

import { FingerprintWorkerPool } from './utils/fingerprintWorkerPool';

import {
  ColorGrade,
  drawProceduralFrame,
  getMovieSceneAtTime,
  getShortVideoSceneAtTime
} from './utils/proceduralVideo';

import {
  CutEntry,
  parseCutList,
  EXAMPLE_CUT_LIST
} from './utils/cutlist';

import { extractFramesLinearWebCodecs } from './webcodecs_utils';

export default function App() {
  // ---------------------------------------------------------------------------
  // STATE MANAGEMENT
  // ---------------------------------------------------------------------------
  const [sourceType, setSourceType] = useState<'demo' | 'upload'>('demo');
  
  // Custom video files
  const [movieFile, setMovieFile] = useState<File | null>(null);
  const [shortFile, setShortFile] = useState<File | null>(null);
  const [movieUrl, setMovieUrl] = useState<string>('');
  const [shortUrl, setShortUrl] = useState<string>('');

  // Color grading configurations (For robustness testing in Demo mode)
  const [movieGrade, setMovieGrade] = useState<ColorGrade>('Snyder'); // Snyder as default to prove color grading immunity!
  const [shortGrade, setShortGrade] = useState<ColorGrade>('RetroSepia');

  // Video matching parameters
  const [fps, setFps] = useState<number>(24);
  const [similarityThreshold, setSimilarityThreshold] = useState<number>(83);
  const [minSegmentDuration, setMinSegmentDuration] = useState<number>(0.8);
  const [frameTolerance, setFrameTolerance] = useState<number>(3);

  // Indexing and Scanning States
  const [isIndexing, setIsIndexing] = useState<boolean>(false);
  const [indexProgress, setIndexProgress] = useState<number>(0);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanProgress, setScanProgress] = useState<number>(0);

  // Cut List Fast Match Mode (targeted frame lookup instead of full scan)
  const [cutListInput, setCutListInput] = useState<string>('');

  // Unified Pipeline States
  const [isPipelineRunning, setIsPipelineRunning] = useState<boolean>(false);
  const [pipelineProgress, setPipelineProgress] = useState<number>(0);
  const [pipelineStage, setPipelineStage] = useState<'idle' | 'preparing' | 'indexing' | 'scanning' | 'aligning' | 'complete'>('idle');
  const [isGeneratingSamples, setIsGeneratingSamples] = useState<boolean>(false);
  const [useParallelization, setUseParallelization] = useState<boolean>(true);

  // Databases & Matches
  const [movieDb, setMovieDb] = useState<FrameFingerprint[]>([]);
  const [shortFingerprints, setShortFingerprints] = useState<FrameFingerprint[]>([]);
  const [matches, setMatches] = useState<MatchedSegment[]>([]);
  const [activeMatchIndex, setActiveMatchIndex] = useState<number>(-1);

  // Playback Control States
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0); // active short video timestamp (0 to 10s for demo)
  const [duration, setDuration] = useState<number>(10); // short video duration (default 10s)
  const [syncMovieTime, setSyncMovieTime] = useState<number>(0); // synchronized movie timestamp

  // Hashing display details
  const [activeShortHash, setActiveShortHash] = useState<string>('0'.repeat(256));
  const [activeMovieHash, setActiveMovieHash] = useState<string>('0'.repeat(256));
  const [liveSimilarity, setLiveSimilarity] = useState<number>(0);
  const [activeRegion, setActiveRegion] = useState<string>('Full Frame');
  const [liveStructSimilarity, setLiveStructSimilarity] = useState<number>(0);
  const [liveColorSimilarity, setLiveColorSimilarity] = useState<number>(0);
  const [liveSkinSimilarity, setLiveSkinSimilarity] = useState<number>(0);
  const [liveDetailSimilarity, setLiveDetailSimilarity] = useState<number>(0);

  // JSON view & copy feedback
  const [copied, setCopied] = useState<boolean>(false);
  const [jsonView, setJsonView] = useState<string>('[]');

  // Diagnostic Logs
  const [logs, setLogs] = useState<string[]>([]);

  // Advanced side-by-side sync comparison states
  const [loopSegment, setLoopSegment] = useState<boolean>(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);

  // ---------------------------------------------------------------------------
  // REFS & CONSTANTS
  // ---------------------------------------------------------------------------
  const movieCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const shortCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const hashCanvasShortRef = useRef<HTMLCanvasElement | null>(null);
  const hashCanvasMovieRef = useRef<HTMLCanvasElement | null>(null);

  // Hidden video elements for custom uploads
  const movieVideoRef = useRef<HTMLVideoElement | null>(null);
  const shortVideoRef = useRef<HTMLVideoElement | null>(null);

  const playbackTimerRef = useRef<any>(null);
  
  // Global memory cache for extracted fingerprints to avoid re-extraction
  const movieCacheRef = useRef<Map<number, FrameFingerprint>>(new Map());
  const shortCacheRef = useRef<Map<number, FrameFingerprint>>(new Map());
  const movieFileRef = useRef<File | null>(null);
  const shortFileRef = useRef<File | null>(null);

  useEffect(() => {
    movieFileRef.current = movieFile;
  }, [movieFile]);

  useEffect(() => {
    shortFileRef.current = shortFile;
  }, [shortFile]);

  const checkFileAccess = async (file: File | null, label: string): Promise<boolean> => {
    if (!file) return false;
    try {
      await file.slice(0, 1).arrayBuffer();
      return true;
    } catch (err: any) {
      console.warn(`[SanityCheck] ${label} file access check failed:`, err);
      // Fallback to true: prevent blocking the pipeline in sandboxed iframe or virtual environments
      // if the file reference is still valid for other APIs like createObjectURL or video loading.
      return true;
    }
  };

  const DEMO_MOVIE_DURATION = 45; // seconds
  const DEMO_SHORT_DURATION = 10;  // seconds

  // Initialize and write logs
  const addLog = (msg: string) => {
    const timeStr = new Date().toLocaleTimeString();
    setLogs((prev) => [`[${timeStr}] ${msg}`, ...prev.slice(0, 30)]);
  };

  // ---------------------------------------------------------------------------
  // WEB WORKER HARMONIC ACCURACY & CALIBRATION SUITE (SANITY TESTER)
  // ---------------------------------------------------------------------------
  const [diagnosticResults, setDiagnosticResults] = useState<{
    status: 'idle' | 'running' | 'success' | 'failed';
    mismatches: { frameIdx: number; workerHash: string; singleHash: string; matches: boolean }[];
    cores: number;
    error?: string;
  } | null>(null);

  const runWorkerDiagnostic = async () => {
    setDiagnosticResults({
      status: 'running',
      mismatches: [],
      cores: navigator.hardwareConcurrency || 4
    });
    addLog("[DIAGNOSTIC] Initiating Web Worker Side-by-Side Accuracy Calibration...");

    try {
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = 160;
      tempCanvas.height = 90;
      const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
      if (!tempCtx) {
        throw new Error("Could not create canvas 2D context");
      }

      const pool = new FingerprintWorkerPool();
      const results: { frameIdx: number; workerHash: string; singleHash: string; matches: boolean }[] = [];

      // Generate and compare 10 frames of varying scenes to ensure 100% hash consistency
      for (let f = 0; f < 10; f++) {
        const t = f / 24.0;
        // Generate a diverse procedural pattern to make hashes realistic and varied
        const sceneId = getMovieSceneAtTime(t);
        drawProceduralFrame(tempCtx, tempCanvas.width, tempCanvas.height, t, sceneId, movieGrade);
        
        // Compute A: Single threaded
        const singleFp = computeFrameFingerprint(tempCtx, f, t);
        
        // Compute B: Web Worker
        const imgBitmap = await createImageBitmap(tempCanvas);
        const workerFp = await pool.computeFingerprint(imgBitmap, f, t);
        
        const isMatch = singleFp.hash === workerFp.hash;
        results.push({
          frameIdx: f,
          singleHash: singleFp.hash,
          workerHash: workerFp.hash,
          matches: isMatch
        });
      }

      pool.terminate();

      const hasMismatch = results.some(r => !r.matches);
      setDiagnosticResults({
        status: hasMismatch ? 'failed' : 'success',
        mismatches: results,
        cores: navigator.hardwareConcurrency || 4
      });
      
      if (hasMismatch) {
        addLog("[DIAGNOSTIC] ERROR: Worker hashes and main-thread hashes DO NOT match! Accuracy compromised.");
      } else {
        addLog("[DIAGNOSTIC] SUCCESS: Worker hashes and main-thread hashes are 100% identical! Accuracy verified.");
      }
    } catch (err: any) {
      setDiagnosticResults({
        status: 'failed',
        mismatches: [],
        cores: navigator.hardwareConcurrency || 4,
        error: err?.message || String(err)
      });
      addLog(`[DIAGNOSTIC] Error running test: ${err?.message}`);
    }
  };

  // Reset all states
  const handleReset = () => {
    movieCacheRef.current.clear();
    shortCacheRef.current.clear();
    setIsPlaying(false);
    setCurrentTime(0);
    setSyncMovieTime(0);
    setMovieDb([]);
    setShortFingerprints([]);
    setMatches([]);
    setActiveMatchIndex(-1);
    setLiveSimilarity(0);
    setLiveStructSimilarity(0);
    setLiveColorSimilarity(0);
    setLiveSkinSimilarity(0);
    setLiveDetailSimilarity(0);
    setJsonView('[]');
    setLogs([]);
    setIsPipelineRunning(false);
    setPipelineProgress(0);
    setPipelineStage('idle');
    addLog("System initialized. Click 'Start Analysis Pipeline' to begin automatic alignment scan.");
  };

  useEffect(() => {
    handleReset();
  }, [sourceType]);

  // Handle setting duration for custom uploaded videos
  useEffect(() => {
    if (sourceType === 'demo') {
      setDuration(DEMO_SHORT_DURATION);
    } else if (shortVideoRef.current && shortFile) {
      // Set duration dynamically when metadata loads
      const handleMetadata = () => {
        setDuration(shortVideoRef.current?.duration || 10);
        addLog(`Custom short video loaded. Duration: ${(shortVideoRef.current?.duration || 0).toFixed(2)}s`);
      };
      shortVideoRef.current.addEventListener('loadedmetadata', handleMetadata);
      return () => {
        shortVideoRef.current?.removeEventListener('loadedmetadata', handleMetadata);
      };
    }
  }, [shortFile, sourceType]);

  // ---------------------------------------------------------------------------
  // RENDER ANIMATION LOOPS (DEMO MODE & LIVE COMPRESSED VERIFICATION)
  // ---------------------------------------------------------------------------
  const renderFrames = (shortTime: number) => {
    if (sourceType === 'demo') {
      const movieCanvas = movieCanvasRef.current;
      const shortCanvas = shortCanvasRef.current;
      if (!movieCanvas || !shortCanvas) return;

      const movieCtx = movieCanvas.getContext('2d');
      const shortCtx = shortCanvas.getContext('2d');
      if (!movieCtx || !shortCtx) return;

      // 1. Draw short video frame
      const shortSceneInfo = getShortVideoSceneAtTime(shortTime);
      drawProceduralFrame(
        shortCtx,
        shortCanvas.width,
        shortCanvas.height,
        shortTime,
        shortSceneInfo.sceneId,
        shortGrade
      );

      // Compute hash for short video
      const shortHash = computePerceptualHash(shortCtx, 0, 0, shortCanvas.width, shortCanvas.height, 16);
      setActiveShortHash(shortHash);
      drawHashGrid(hashCanvasShortRef.current, shortHash, '#10b981'); // Emerald

      // 2. Determine and draw corresponding movie frame
      let mTime = shortTime;
      // If we are currently reviewing a matched segment, synchronize the movie playback head
      if (activeMatchIndex >= 0 && activeMatchIndex < matches.length) {
        const seg = matches[activeMatchIndex];
        if (shortTime >= seg.shortStart && shortTime <= seg.shortEnd) {
          const ratio = (shortTime - seg.shortStart) / (seg.shortEnd - seg.shortStart);
          mTime = seg.movieStart + ratio * (seg.movieEnd - seg.movieStart);
        } else {
          // If scrubber goes out of active match, default to matching scene logic
          mTime = shortSceneInfo.movieTime;
        }
      } else {
        mTime = shortSceneInfo.movieTime;
      }

      setSyncMovieTime(mTime);

      const movieSceneId = getMovieSceneAtTime(mTime);
      drawProceduralFrame(
        movieCtx,
        movieCanvas.width,
        movieCanvas.height,
        mTime,
        movieSceneId,
        movieGrade
      );

      // Compute hash for movie frame
      const movieHash = computePerceptualHash(movieCtx, 0, 0, movieCanvas.width, movieCanvas.height, 16);
      setActiveMovieHash(movieHash);
      drawHashGrid(hashCanvasMovieRef.current, movieHash, '#06b6d4'); // Cyan

      // Compute dynamic crop overlays
      const sf = computeFrameFingerprint(shortCtx, 0, shortTime);
      const mf = computeFrameFingerprint(movieCtx, 0, mTime);
      const res = getFrameSimilarityWithRegion(sf, mf);

      setLiveSimilarity(Number(res.similarity.toFixed(1)));
      setActiveRegion(res.region);
      setLiveStructSimilarity(Number(res.structSimilarity.toFixed(1)));
      setLiveColorSimilarity(Number(res.colorSimilarity.toFixed(1)));
      setLiveSkinSimilarity(Number(res.skinSimilarity.toFixed(1)));
      setLiveDetailSimilarity(Number(res.detailSimilarity.toFixed(1)));
      drawCropOverlay(movieCtx, res.region, '#06b6d4');
    } else {
      // Custom Video Source seek triggers
      const movieVid = movieVideoRef.current;
      const shortVid = shortVideoRef.current;
      if (!shortVid || !movieVid) return;

      shortVid.currentTime = shortTime;

      let mTime = shortTime;
      if (activeMatchIndex >= 0 && activeMatchIndex < matches.length) {
        const seg = matches[activeMatchIndex];
        if (shortTime >= seg.shortStart && shortTime <= seg.shortEnd) {
          const ratio = (shortTime - seg.shortStart) / (seg.shortEnd - seg.shortStart);
          mTime = seg.movieStart + ratio * (seg.movieEnd - seg.movieStart);
        }
      } else if (matches.length > 0) {
        const activeSeg = matches.find(s => shortTime >= s.shortStart && shortTime <= s.shortEnd);
        if (activeSeg) {
          const ratio = (shortTime - activeSeg.shortStart) / (activeSeg.shortEnd - activeSeg.shortStart);
          mTime = activeSeg.movieStart + ratio * (activeSeg.movieEnd - activeSeg.movieStart);
        }
      }

      setSyncMovieTime(mTime);
      movieVid.currentTime = mTime;
      
      // Draw immediate update frame onto offscreen canvases
      drawUploadCanvases(shortTime);
    }
  };

  // High performance Canvas drawing for Custom Uploaded Videos
  const drawUploadCanvases = (shortTime: number) => {
    const movieVid = movieVideoRef.current;
    const shortVid = shortVideoRef.current;
    const mCanvas = movieCanvasRef.current;
    const sCanvas = shortCanvasRef.current;
    if (!mCanvas || !sCanvas || !shortVid || !movieVid) return;

    const mCtx = mCanvas.getContext('2d');
    const sCtx = sCanvas.getContext('2d');
    if (!mCtx || !sCtx) return;

    try {
      const sAspect = shortVid.videoWidth / shortVid.videoHeight || 1.777;
      sCanvas.width = 320;
      sCanvas.height = Math.round(320 / sAspect);

      const mAspect = movieVid.videoWidth / movieVid.videoHeight || 1.777;
      mCanvas.width = 320;
      mCanvas.height = Math.round(320 / mAspect);

      // Draw short
      sCtx.drawImage(shortVid, 0, 0, sCanvas.width, sCanvas.height);
      const shortFingerprint = computeFrameFingerprint(sCtx, 0, shortTime);
      setActiveShortHash(shortFingerprint.hash);
      drawHashGrid(hashCanvasShortRef.current, shortFingerprint.hash, '#10b981');

      // Compute correct synced time
      let mTime = shortTime;
      if (activeMatchIndex >= 0 && activeMatchIndex < matches.length) {
        const seg = matches[activeMatchIndex];
        if (shortTime >= seg.shortStart && shortTime <= seg.shortEnd) {
          const ratio = (shortTime - seg.shortStart) / (seg.shortEnd - seg.shortStart);
          mTime = seg.movieStart + ratio * (seg.movieEnd - seg.movieStart);
        }
      } else if (matches.length > 0) {
        const activeSeg = matches.find(s => shortTime >= s.shortStart && shortTime <= s.shortEnd);
        if (activeSeg) {
          const ratio = (shortTime - activeSeg.shortStart) / (activeSeg.shortEnd - activeSeg.shortStart);
          mTime = activeSeg.movieStart + ratio * (activeSeg.movieEnd - activeSeg.movieStart);
        }
      }

      // Draw movie
      mCtx.drawImage(movieVid, 0, 0, mCanvas.width, mCanvas.height);
      const movieFingerprint = computeFrameFingerprint(mCtx, 0, mTime);
      setActiveMovieHash(movieFingerprint.hash);
      drawHashGrid(hashCanvasMovieRef.current, movieFingerprint.hash, '#06b6d4');

      const res = getFrameSimilarityWithRegion(shortFingerprint, movieFingerprint);
      setLiveSimilarity(Number(res.similarity.toFixed(1)));
      setActiveRegion(res.region);
      setLiveStructSimilarity(Number(res.structSimilarity.toFixed(1)));
      setLiveColorSimilarity(Number(res.colorSimilarity.toFixed(1)));
      setLiveSkinSimilarity(Number(res.skinSimilarity.toFixed(1)));
      setLiveDetailSimilarity(Number(res.detailSimilarity.toFixed(1)));

      // Highlight the precise spatial region matched
      drawCropOverlay(mCtx, res.region, '#06b6d4');
    } catch (e) {
      // Cross-origin safe
    }
  };

  // Render a visual matrix/fingerprint grid (16x16) onto a helper canvas
  const drawHashGrid = (canvas: HTMLCanvasElement | null, hash: string, activeColor: string) => {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const cellSize = canvas.width / 16;

    for (let row = 0; row < 16; row++) {
      for (let col = 0; col < 16; col++) {
        const bit = hash[row * 16 + col] === '1';
        ctx.fillStyle = bit ? activeColor : '#1e293b'; // Slate 800 for negative space
        ctx.fillRect(col * cellSize + 0.5, row * cellSize + 0.5, cellSize - 1, cellSize - 1);
      }
    }
  };

  // Draw a bounding box around the matched region on the reference movie canvas
  const drawCropOverlay = (ctx: CanvasRenderingContext2D, regionLabel: string, color: string = '#06b6d4') => {
    const W = ctx.canvas.width;
    const H = ctx.canvas.height;
    
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = color;
    ctx.shadowBlur = 6;
    
    const cropW = H * 0.5625;
    const span = W - cropW;

    if (regionLabel === 'Left 9:16 Crop') {
      ctx.strokeRect(1, 1, cropW - 2, H - 2);
    } else if (regionLabel === 'Center-Left 9:16 Crop') {
      ctx.strokeRect(span * 0.25, 1, cropW, H - 2);
    } else if (regionLabel === 'Center 9:16 Crop') {
      ctx.strokeRect(span * 0.5, 1, cropW, H - 2);
    } else if (regionLabel === 'Center-Right 9:16 Crop') {
      ctx.strokeRect(span * 0.75, 1, cropW, H - 2);
    } else if (regionLabel === 'Right 9:16 Crop') {
      ctx.strokeRect(span - 1, 1, cropW - 2, H - 2);
    } else if (regionLabel.includes('Zoom 1.25x')) {
      const w = W / 1.25;
      const h = H / 1.25;
      const y = (H - h) / 2;
      if (regionLabel.includes('Left')) {
        ctx.strokeRect(1, y, w, h);
      } else if (regionLabel.includes('Right')) {
        ctx.strokeRect(W - w - 1, y, w, h);
      } else {
        ctx.strokeRect((W - w) / 2, y, w, h);
      }
    } else if (regionLabel.includes('Zoom 1.5x')) {
      const w = W / 1.5;
      const h = H / 1.5;
      const y = (H - h) / 2;
      if (regionLabel.includes('Left')) {
        ctx.strokeRect(1, y, w, h);
      } else if (regionLabel.includes('Right')) {
        ctx.strokeRect(W - w - 1, y, w, h);
      } else {
        ctx.strokeRect((W - w) / 2, y, w, h);
      }
    } else if (regionLabel.includes('Zoom 2.0x')) {
      const w = W / 2.0;
      const h = H / 2.0;
      const y = (H - h) / 2;
      ctx.strokeRect((W - w) / 2, y, w, h);
    } else {
      // Full Frame
      ctx.strokeRect(1, 1, W - 2, H - 2);
    }
    
    // Add text label with opaque black background
    ctx.shadowBlur = 0; // Disable shadow for text
    const text = regionLabel || 'Full Frame';
    ctx.font = 'bold 9px monospace';
    const textWidth = ctx.measureText(text).width;
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
    ctx.fillRect(4, H - 18, textWidth + 8, 14);
    
    ctx.fillStyle = color;
    ctx.fillText(text, 8, H - 8);
    
    ctx.restore();
  };

  // Run initial render once component loads
  useEffect(() => {
    setTimeout(() => {
      renderFrames(0);
    }, 150);
  }, [movieGrade, shortGrade, activeMatchIndex, sourceType]);

  // ---------------------------------------------------------------------------
  // PLAYBACK TICK ENGINE & NATIVE VIDEO CONTROLLER
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (sourceType === 'demo') {
      if (isPlaying) {
        const intervalMs = (1000 / fps) / playbackSpeed;
        const step = 1 / fps;

        playbackTimerRef.current = setInterval(() => {
          setCurrentTime((prev) => {
            let nextTime = prev + step;
            if (activeMatchIndex >= 0 && activeMatchIndex < matches.length) {
              const seg = matches[activeMatchIndex];
              if (nextTime >= seg.shortEnd) {
                if (loopSegment) {
                  nextTime = seg.shortStart;
                } else {
                  setIsPlaying(false);
                  nextTime = seg.shortStart;
                  renderFrames(seg.shortStart);
                  return seg.shortStart;
                }
              }
            } else {
              if (nextTime >= duration) {
                nextTime = 0; // Loop playback
              }
            }
            renderFrames(nextTime);
            return nextTime;
          });
        }, intervalMs);
      } else {
        if (playbackTimerRef.current) {
          clearInterval(playbackTimerRef.current);
        }
      }
    } else {
      // Custom video play/pause handlers
      const movieVid = movieVideoRef.current;
      const shortVid = shortVideoRef.current;
      if (!movieVid || !shortVid) return;

      if (isPlaying) {
        // Sync starting playheads before starting
        const shortTime = shortVid.currentTime;
        let mTime = shortTime;
        let ratio = 1.0;

        if (activeMatchIndex >= 0 && activeMatchIndex < matches.length) {
          const seg = matches[activeMatchIndex];
          const shortDur = seg.shortEnd - seg.shortStart;
          if (shortDur > 0) {
            ratio = (seg.movieEnd - seg.movieStart) / shortDur;
          }
          if (shortTime >= seg.shortStart && shortTime <= seg.shortEnd) {
            const progressRatio = (shortTime - seg.shortStart) / shortDur;
            mTime = seg.movieStart + progressRatio * (seg.movieEnd - seg.movieStart);
          } else {
            shortVid.currentTime = seg.shortStart;
            mTime = seg.movieStart;
          }
        } else if (matches.length > 0) {
          const activeSeg = matches.find(s => shortTime >= s.shortStart && shortTime <= s.shortEnd);
          if (activeSeg) {
            const shortDur = activeSeg.shortEnd - activeSeg.shortStart;
            if (shortDur > 0) {
              ratio = (activeSeg.movieEnd - activeSeg.movieStart) / shortDur;
            }
            const progressRatio = (shortTime - activeSeg.shortStart) / shortDur;
            mTime = activeSeg.movieStart + progressRatio * (activeSeg.movieEnd - activeSeg.movieStart);
          }
        }
        
        movieVid.currentTime = mTime;
        shortVid.playbackRate = playbackSpeed;
        movieVid.playbackRate = playbackSpeed * ratio;
        
        // Start playing natively (highly optimized, hardware-accelerated, perfect fluidity)
        shortVid.play().catch(() => {});
        movieVid.play().catch(() => {});
      } else {
        shortVid.pause();
        movieVid.pause();
      }
    }

    return () => {
      if (playbackTimerRef.current) {
        clearInterval(playbackTimerRef.current);
      }
    };
  }, [isPlaying, fps, duration, matches, activeMatchIndex, sourceType, playbackSpeed, loopSegment]);

  // High performance sync-loop & timeline updater during play for Custom Video Source
  useEffect(() => {
    if (sourceType !== 'upload' || !isPlaying) return;

    let animId: number;
    const shortVid = shortVideoRef.current;
    const movieVid = movieVideoRef.current;
    if (!shortVid || !movieVid) return;

    const updateLoop = () => {
      if (!shortVid.paused) {
        const shortTime = shortVid.currentTime;
        setCurrentTime(shortTime);

        // Segment End Check
        if (activeMatchIndex >= 0 && activeMatchIndex < matches.length) {
          const seg = matches[activeMatchIndex];
          if (shortTime >= seg.shortEnd) {
            if (loopSegment) {
              shortVid.currentTime = seg.shortStart;
              movieVid.currentTime = seg.movieStart;
              shortVid.play().catch(() => {});
              movieVid.play().catch(() => {});
              setCurrentTime(seg.shortStart);
              setSyncMovieTime(seg.movieStart);
              drawUploadCanvases(seg.shortStart);
            } else {
              setIsPlaying(false);
              shortVid.pause();
              movieVid.pause();
              shortVid.currentTime = seg.shortStart;
              movieVid.currentTime = seg.movieStart;
              setCurrentTime(seg.shortStart);
              setSyncMovieTime(seg.movieStart);
              drawUploadCanvases(seg.shortStart);
              return; // Break update loop
            }
          }
        }

        // Sync calculation
        let mTime = shortTime;
        let ratio = 1.0;
        if (activeMatchIndex >= 0 && activeMatchIndex < matches.length) {
          const seg = matches[activeMatchIndex];
          const shortDur = seg.shortEnd - seg.shortStart;
          if (shortDur > 0) {
            ratio = (seg.movieEnd - seg.movieStart) / shortDur;
          }
          if (shortTime >= seg.shortStart && shortTime <= seg.shortEnd) {
            const progressRatio = (shortTime - seg.shortStart) / shortDur;
            mTime = seg.movieStart + progressRatio * (seg.movieEnd - seg.movieStart);
          }
        } else if (matches.length > 0) {
          const activeSeg = matches.find(s => shortTime >= s.shortStart && shortTime <= s.shortEnd);
          if (activeSeg) {
            const shortDur = activeSeg.shortEnd - activeSeg.shortStart;
            if (shortDur > 0) {
              ratio = (activeSeg.movieEnd - activeSeg.movieStart) / shortDur;
            }
            const progressRatio = (shortTime - activeSeg.shortStart) / shortDur;
            mTime = activeSeg.movieStart + progressRatio * (activeSeg.movieEnd - activeSeg.movieStart);
          }
        }

        setSyncMovieTime(mTime);

        // Dynamic playback rates to naturally sync streams and stop laggy jitter
        shortVid.playbackRate = playbackSpeed;
        movieVid.playbackRate = playbackSpeed * ratio;

        // Anti-Desync Soft Correction: if movie element drifts by more than 0.20s, soft-align playheads
        if (Math.abs(movieVid.currentTime - mTime) > 0.20) {
          movieVid.currentTime = mTime;
        }

        // Draw active video canvases and refresh bounding overlays
        drawUploadCanvases(shortTime);
      }
      animId = requestAnimationFrame(updateLoop);
    };

    animId = requestAnimationFrame(updateLoop);

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [isPlaying, sourceType, activeMatchIndex, matches, playbackSpeed, loopSegment]);

  // Listener to keep canvases loaded and updated on scrub or pause seeks
  useEffect(() => {
    if (sourceType === 'upload') {
      const movieVid = movieVideoRef.current;
      const shortVid = shortVideoRef.current;
      if (!movieVid || !shortVid) return;

      const handleSeekUpdate = () => {
        if (!isPlaying) {
          drawUploadCanvases(shortVid.currentTime);
        }
      };

      movieVid.addEventListener('seeked', handleSeekUpdate);
      shortVid.addEventListener('seeked', handleSeekUpdate);

      return () => {
        movieVid.removeEventListener('seeked', handleSeekUpdate);
        shortVid.removeEventListener('seeked', handleSeekUpdate);
      };
    }
  }, [sourceType, isPlaying, matches, activeMatchIndex]);

  // Scrubbing handler
  const handleTimelineScrub = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    setCurrentTime(newTime);
    renderFrames(newTime);
  };

  // ---------------------------------------------------------------------------
  // PIPELINE DECODER HELPERS
  // ---------------------------------------------------------------------------
  
  // Helper to ensure video elements have loaded metadata before querying duration or seeking
  const ensureVideoLoaded = (video: HTMLVideoElement): Promise<void> => {
    return new Promise((resolve) => {
      if (video.readyState >= 1 && !isNaN(video.duration) && video.duration > 0) {
        resolve();
        return;
      }
      const onLoaded = () => {
        video.removeEventListener('loadedmetadata', onLoaded);
        video.removeEventListener('canplay', onLoaded);
        resolve();
      };
      video.addEventListener('loadedmetadata', onLoaded);
      video.addEventListener('canplay', onLoaded);
      // Fallback in case it fails to trigger
      setTimeout(resolve, 3000);
    });
  };

  // Generate offline test sample videos programmatically inside the browser using Canvas and MediaRecorder
  const generateSampleVideo = (type: 'movie' | 'short'): Promise<File> => {
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      canvas.width = 160;
      canvas.height = 90;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error("Could not create canvas 2D context"));
        return;
      }

      // Check browser MediaRecorder support
      if (typeof MediaRecorder === 'undefined') {
        reject(new Error("MediaRecorder is not supported in this browser."));
        return;
      }

      let mimeType = 'video/webm';
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = ''; // Let browser choose default
      }

      const stream = canvas.captureStream(10); // Capture at 10 FPS
      let recorder: MediaRecorder;
      try {
        recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      } catch (err) {
        recorder = new MediaRecorder(stream);
      }
      
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: mimeType || 'video/webm' });
        const fileName = type === 'movie' ? "sample_reference_movie.webm" : "sample_remix_clip.webm";
        const file = new File([blob], fileName, { type: mimeType || 'video/webm' });
        resolve(file);
      };

      recorder.start();

      const durationSecs = type === 'movie' ? 10 : 4;
      const totalFrames = durationSecs * 10;
      let frame = 0;

      const drawInterval = setInterval(() => {
        if (frame >= totalFrames) {
          clearInterval(drawInterval);
          try {
            recorder.stop();
          } catch (e) {
            // ignore recorder close error
          }
          return;
        }

        const time = frame / 10;
        
        // Draw standard patterns representing different scenes
        ctx.fillStyle = '#0a0b10';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        if (type === 'movie') {
          // Scene A: Neon Grid (0.0s to 4.0s)
          if (time < 4.0) {
            ctx.strokeStyle = '#06b6d4';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(0, 45); ctx.lineTo(160, 45);
            ctx.stroke();
            
            // Rotating circle
            ctx.fillStyle = '#d946ef';
            ctx.beginPath();
            ctx.arc(80 + Math.sin(time * 2) * 40, 45, 12, 0, Math.PI * 2);
            ctx.fill();
          } 
          // Scene B: Deep Nebula (4.0s to 7.0s)
          else if (time < 7.0) {
            ctx.fillStyle = '#ec4899';
            ctx.beginPath();
            ctx.arc(80, 45, 15 + Math.cos(time * 3) * 8, 0, Math.PI * 2);
            ctx.fill();
          } 
          // Scene C: Matrix (7.0s to 10.0s)
          else {
            ctx.fillStyle = '#22c55e';
            ctx.font = 'bold 12px monospace';
            ctx.fillText(`CODE_${Math.floor(time * 10)}`, 45, 50);
          }
        } else {
          // Short Remix (composed of sections mimicking movie sections):
          // 0.0s to 1.5s -> maps to Scene C (Matrix) (e.g. time + 7.0)
          // 1.5s to 2.5s -> maps to Scene A (Neon) (e.g. time - 1.5 + 1.0)
          // 2.5s to 4.0s -> maps to Scene B (Nebula) (e.g. time - 2.5 + 4.0)
          if (time < 1.5) {
            ctx.fillStyle = '#22c55e';
            ctx.font = 'bold 12px monospace';
            ctx.fillText(`CODE_${Math.floor((time + 7.0) * 10)}`, 45, 50);
          } else if (time < 2.5) {
            ctx.strokeStyle = '#06b6d4';
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.moveTo(0, 45); ctx.lineTo(160, 45);
            ctx.stroke();
            
            ctx.fillStyle = '#d946ef';
            ctx.beginPath();
            ctx.arc(80 + Math.sin((time - 1.5 + 1.0) * 2) * 40, 45, 12, 0, Math.PI * 2);
            ctx.fill();
          } else {
            ctx.fillStyle = '#ec4899';
            ctx.beginPath();
            ctx.arc(80, 45, 15 + Math.cos((time - 2.5 + 4.0) * 3) * 8, 0, Math.PI * 2);
            ctx.fill();
          }
        }

        // HUD Text Overlay
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
        ctx.font = '7px monospace';
        ctx.fillText(`GENERATED_SAMPLE_DECK_V1`, 5, 15);
        ctx.fillText(`TIME: ${time.toFixed(1)}s`, 5, 80);

        frame++;
      }, 100);
    });
  };

  // Loader for browser-side programmatically generated videos
  const loadSampleVideos = async () => {
    if (isGeneratingSamples || isPipelineRunning) return;
    setIsGeneratingSamples(true);
    addLog("Initiating programmatical video sample generation in-browser...");

    try {
      const movieFileObj = await generateSampleVideo('movie');
      setMovieFile(movieFileObj);
      const mUrl = URL.createObjectURL(movieFileObj);
      setMovieUrl(mUrl);
      addLog(`Generated reference video: ${movieFileObj.name} (Offline WebM Clip)`);

      const shortFileObj = await generateSampleVideo('short');
      setShortFile(shortFileObj);
      const sUrl = URL.createObjectURL(shortFileObj);
      setShortUrl(sUrl);
      addLog(`Generated remix video: ${shortFileObj.name} (Offline WebM Clip)`);

      setMovieDb([]);
      setShortFingerprints([]);
      setMatches([]);
      addLog("Successfully generated sample videos. Ready for the single-click Analysis Pipeline!");
    } catch (err: any) {
      addLog(`Failed to programmatically generate test clips: ${err.message || err}`);
    } finally {
      setIsGeneratingSamples(false);
    }
  };

  // ---------------------------------------------------------------------------
  // PROMISE-BASED FRAME SCANNING ACTIONS (USED BY THE UNIFIED PIPELINE)
  // ---------------------------------------------------------------------------

  const performMovieIndexing = (currentFps: number): Promise<FrameFingerprint[]> => {
    return new Promise((resolve, reject) => {
      setIsIndexing(true);
      setIndexProgress(0);
      
      const tempCanvas = document.createElement('canvas');
      const database: FrameFingerprint[] = [];

      if (sourceType === 'demo') {
        tempCanvas.width = 160;
        tempCanvas.height = 90;
        const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
        if (!tempCtx) {
          setIsIndexing(false);
          reject(new Error("Could not create canvas 2D context"));
          return;
        }

        const totalFrames = DEMO_MOVIE_DURATION * currentFps;
        
        const chunkScan = (startFrame: number) => {
          const maxChunk = 50;
          const endFrame = Math.min(startFrame + maxChunk, totalFrames);

          for (let f = startFrame; f < endFrame; f++) {
            const t = f / currentFps;
            const sceneId = getMovieSceneAtTime(t);
            drawProceduralFrame(tempCtx, tempCanvas.width, tempCanvas.height, t, sceneId, movieGrade);
            const fingerprint = computeFrameFingerprint(tempCtx, f, t);
            database.push(fingerprint);
          }

          const progress = Math.floor((endFrame / totalFrames) * 100);
          setIndexProgress(progress);
          setPipelineProgress(Math.floor(progress * 0.5)); // 0% to 50% of the overall progress

          if (endFrame < totalFrames) {
            requestAnimationFrame(() => chunkScan(endFrame));
          } else {
            setIsIndexing(false);
            resolve(database);
          }
        };

        chunkScan(0);
      } else {
        // Try WebCodecs first for ultra-fast in-memory extraction
        const video = movieVideoRef.current;
        if (!video || !movieFile) {
          setIsIndexing(false);
          reject(new Error("Movie reference video is not loaded"));
          return;
        }

        video.pause();
        const aspect = video.videoWidth / video.videoHeight || 1.777;
        tempCanvas.width = 160;
        tempCanvas.height = Math.round(160 / aspect);
        const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
        if (!tempCtx) {
          setIsIndexing(false);
          reject(new Error("Could not create canvas 2D context"));
          return;
        }

        const totalDuration = video.duration || 10;
        const totalFrames = Math.floor(totalDuration * currentFps);
        const movieDatabase: FrameFingerprint[] = [];

        const fallbackToSeek = () => {
          let processedCount = 0;
          const seekAndFingerprint = (frameIdx: number) => {
            if (frameIdx >= totalFrames) {
              setIsIndexing(false);
              const cleanDb = movieDatabase.filter(Boolean);
              resolve(cleanDb);
              return;
            }

            if (movieCacheRef.current.has(frameIdx)) {
               movieDatabase[frameIdx] = movieCacheRef.current.get(frameIdx)!;
               processedCount++;
               const progress = Math.floor((processedCount / totalFrames) * 100);
               setIndexProgress(progress);
               setPipelineProgress(Math.floor(progress * 0.5));
               
               if (processedCount % 50 === 0) {
                   const channel = new MessageChannel();
                   channel.port1.onmessage = () => seekAndFingerprint(frameIdx + 1);
                   channel.port2.postMessage(null);
               } else {
                   seekAndFingerprint(frameIdx + 1);
               }
               return;
            }

            const t = frameIdx / currentFps;
            video.currentTime = t;

            const onSeeked = () => {
              video.removeEventListener('seeked', onSeeked);

              try {
                // 1. Draw video frame to our offscreen canvas immediately on seeked (Zero rVFC/rAF latency!)
                tempCtx.drawImage(video, 0, 0, tempCanvas.width, tempCanvas.height);
              } catch (err) {
                // Ignore canvas decoding glitches
              }

              // 2. Schedule the next seek IMMEDIATELY using MessageChannel to bypass browser-nested 4ms setTimeout limit!
              const nextFrameIdx = frameIdx + 1;
              if (nextFrameIdx < totalFrames) {
                const channel = new MessageChannel();
                channel.port1.onmessage = () => seekAndFingerprint(nextFrameIdx);
                channel.port2.postMessage(null);
              }

              // 3. Compute fingerprinting hash on the captured frame in parallel with the seek
              try {
                const fingerprint = computeFrameFingerprint(tempCtx, frameIdx, t);
                movieCacheRef.current.set(frameIdx, fingerprint);
                movieDatabase[frameIdx] = fingerprint;
              } catch (err) {
                // Ignore
              }

              processedCount++;
              const progress = Math.floor((processedCount / totalFrames) * 100);
              setIndexProgress(progress);
              setPipelineProgress(Math.floor(progress * 0.5));

              // 4. Resolve if this was the final frame
              if (nextFrameIdx >= totalFrames) {
                setIsIndexing(false);
                const cleanDb = movieDatabase.filter(Boolean);
                resolve(cleanDb);
              }
            };

            video.addEventListener('seeked', onSeeked);
          };

          seekAndFingerprint(0);
        };

        console.log("[WebCodecs] Starting WebCodecs path for Movie Reference indexing...");
        const t0Movie = performance.now();
        let movieFramesDecoded = 0;
        const moviePool = useParallelization ? new FingerprintWorkerPool() : null;
        const movieWorkerPromises: Promise<any>[] = [];

        // Offscreen canvas for main-thread rendering if parallelization is disabled
        const webcodecsCanvas = document.createElement('canvas');
        webcodecsCanvas.width = 160;
        webcodecsCanvas.height = 90;
        const webcodecsCtx = webcodecsCanvas.getContext('2d', { willReadFrequently: true });

        extractFramesLinearWebCodecs(
          movieFileRef.current || movieFile,
          currentFps,
          (frame, t, frameIdx) => {
             movieFramesDecoded++;
             if (moviePool) {
               const promise = moviePool.computeFingerprint(frame, frameIdx, t)
                 .then((fingerprint) => {
                    movieCacheRef.current.set(frameIdx, fingerprint);
                    movieDatabase[frameIdx] = fingerprint; // Keep in order
                 })
                 .catch(err => {
                    console.error(`[WorkerPool] Error in movie worker frame ${frameIdx}:`, err);
                 });
               movieWorkerPromises.push(promise);
             } else {
               // Single-threaded fallback
               if (webcodecsCtx) {
                 webcodecsCtx.drawImage(frame, 0, 0, webcodecsCanvas.width, webcodecsCanvas.height);
                 try {
                   const fingerprint = computeFrameFingerprint(webcodecsCtx, frameIdx, t);
                   movieCacheRef.current.set(frameIdx, fingerprint);
                   movieDatabase[frameIdx] = fingerprint; // Keep in order
                 } catch (err) {
                   console.error(`[SingleThread] Error indexing frame ${frameIdx}:`, err);
                 }
               }
               // Close the ImageBitmap to prevent GPU/memory leaks on main thread
               frame.close();
             }
          },
          (progress) => {
             setIndexProgress(progress);
             setPipelineProgress(Math.floor(progress * 0.5));
          }
        ).then(async () => {
           console.log("[WebCodecs] Movie reference decoding complete. Waiting for workers to finish...");
           if (moviePool) {
             await Promise.all(movieWorkerPromises);
             moviePool.terminate();
           }
           const t1Movie = performance.now();
           console.log(`[TIMING] Reference Movie decode: ${((t1Movie - t0Movie) / 1000).toFixed(2)}s for ${movieFramesDecoded} frames`);
           console.log("[WebCodecs] WebCodecs linear decoding complete for Movie reference video!");
           const cleanDb = movieDatabase.filter(Boolean);
           setIsIndexing(false);
           resolve(cleanDb);
        }).catch(err => {
           if (moviePool) moviePool.terminate();
           console.error("[WebCodecs] Fallback to seek-based method triggered because WebCodecs failed for movie indexing:", err);
           fallbackToSeek();
        });
      }
    });
  };

  const performShortScanning = (movieDatabase: FrameFingerprint[], currentFps: number): Promise<FrameFingerprint[]> => {
    return new Promise((resolve, reject) => {
      setIsScanning(true);
      setScanProgress(0);

      const tempCanvas = document.createElement('canvas');
      const shortDatabase: FrameFingerprint[] = [];

      if (sourceType === 'demo') {
        tempCanvas.width = 160;
        tempCanvas.height = 90;
        const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
        if (!tempCtx) {
          setIsScanning(false);
          reject(new Error("Could not create canvas 2D context"));
          return;
        }

        const totalFrames = DEMO_SHORT_DURATION * currentFps;

        const chunkScanShort = (startFrame: number) => {
          const maxChunk = 30;
          const endFrame = Math.min(startFrame + maxChunk, totalFrames);

          for (let f = startFrame; f < endFrame; f++) {
            if (shortCacheRef.current.has(f)) {
              shortDatabase.push(shortCacheRef.current.get(f)!);
            } else {
              const t = f / currentFps;
              const sceneInfo = getShortVideoSceneAtTime(t);
              drawProceduralFrame(tempCtx, tempCanvas.width, tempCanvas.height, t, sceneInfo.sceneId, shortGrade);
              const fingerprint = computeFrameFingerprint(tempCtx, f, t);
              shortCacheRef.current.set(f, fingerprint);
              shortDatabase.push(fingerprint);
            }
          }

          const progress = Math.floor((endFrame / totalFrames) * 100);
          setScanProgress(progress);
          setPipelineProgress(50 + Math.floor(progress * 0.5)); // 50% to 100% of the overall progress

          if (endFrame < totalFrames) {
            requestAnimationFrame(() => chunkScanShort(endFrame));
          } else {
            setIsScanning(false);
            resolve(shortDatabase);
          }
        };

        chunkScanShort(0);
      } else {
        // Custom Uploaded Short Remix video Seek & Hash loop (using WebCodecs VideoDecoder!)
        const video = shortVideoRef.current;
        if (!video || !shortFile) {
          setIsScanning(false);
          reject(new Error("Short mashup video is not loaded"));
          return;
        }

        video.pause();
        const aspect = video.videoWidth / video.videoHeight || 1.777;
        tempCanvas.width = 160;
        tempCanvas.height = Math.round(160 / aspect);
        const tempCtx = tempCanvas.getContext('2d', { willReadFrequently: true });
        if (!tempCtx) {
          setIsScanning(false);
          reject(new Error("Could not create canvas 2D context"));
          return;
        }

        const totalDuration = video.duration || 4;
        const totalFrames = Math.floor(totalDuration * currentFps);
        
        const fallbackToSeek = () => {
          let processedCount = 0;
          const seekAndFingerprintShort = (frameIdx: number) => {
            if (frameIdx >= totalFrames) {
              setIsScanning(false);
              resolve(shortDatabase);
              return;
            }

            if (shortCacheRef.current.has(frameIdx)) {
               shortDatabase.push(shortCacheRef.current.get(frameIdx)!);
               processedCount++;
               const progress = Math.floor((processedCount / totalFrames) * 100);
               setScanProgress(progress);
               setPipelineProgress(50 + Math.floor(progress * 0.5));
               
               if (processedCount % 50 === 0) {
                   const channel = new MessageChannel();
                   channel.port1.onmessage = () => seekAndFingerprintShort(frameIdx + 1);
                   channel.port2.postMessage(null);
               } else {
                   seekAndFingerprintShort(frameIdx + 1);
               }
               return;
            }

            const t = frameIdx / currentFps;
            video.currentTime = t;

            const onSeeked = () => {
              video.removeEventListener('seeked', onSeeked);

              try {
                // 1. Draw video frame to our offscreen canvas immediately on seeked (Zero rVFC/rAF latency!)
                tempCtx.drawImage(video, 0, 0, tempCanvas.width, tempCanvas.height);
              } catch (err) {
                // Ignore canvas decoding glitches
              }

              // 2. Schedule the next seek IMMEDIATELY using MessageChannel to bypass browser-nested 4ms setTimeout limit!
              const nextFrameIdx = frameIdx + 1;
              if (nextFrameIdx < totalFrames) {
                const channel = new MessageChannel();
                channel.port1.onmessage = () => seekAndFingerprintShort(nextFrameIdx);
                channel.port2.postMessage(null);
              }

              // 3. Compute fingerprinting hash on the captured frame in parallel with the seek
              try {
                const fingerprint = computeFrameFingerprint(tempCtx, frameIdx, t);
                shortCacheRef.current.set(frameIdx, fingerprint);
                shortDatabase.push(fingerprint);
              } catch (err) {
                // Ignore
              }

              processedCount++;
              const progress = Math.floor((processedCount / totalFrames) * 100);
              setScanProgress(progress);
              setPipelineProgress(50 + Math.floor(progress * 0.5));

              // 4. Resolve if this was the final frame
              if (nextFrameIdx >= totalFrames) {
                setIsScanning(false);
                resolve(shortDatabase);
              }
            };

            video.addEventListener('seeked', onSeeked);
          };

          seekAndFingerprintShort(0);
        };

        // Try WebCodecs first
        console.log("[WebCodecs] Starting WebCodecs path for Short video...");
        const t0Short = performance.now();
        let shortFramesDecoded = 0;
        const shortPool = useParallelization ? new FingerprintWorkerPool() : null;
        const shortWorkerPromises: Promise<any>[] = [];

        // Offscreen canvas for main-thread rendering if parallelization is disabled
        const tempCanvasShort = document.createElement('canvas');
        tempCanvasShort.width = 160;
        tempCanvasShort.height = 90;
        const tempCtxShort = tempCanvasShort.getContext('2d', { willReadFrequently: true });

        extractFramesLinearWebCodecs(
          shortFileRef.current || shortFile,
          currentFps,
          (frame, t, frameIdx) => {
             shortFramesDecoded++;
             if (shortPool) {
               const promise = shortPool.computeFingerprint(frame, frameIdx, t)
                 .then((fingerprint) => {
                    shortCacheRef.current.set(frameIdx, fingerprint);
                    shortDatabase[frameIdx] = fingerprint; // Keep in order
                 })
                 .catch(err => {
                    console.error(`[WorkerPool] Error in short worker frame ${frameIdx}:`, err);
                 });
               shortWorkerPromises.push(promise);
             } else {
               // Single-threaded fallback
               if (tempCtxShort) {
                 tempCtxShort.drawImage(frame, 0, 0, tempCanvasShort.width, tempCanvasShort.height);
                 try {
                   const fingerprint = computeFrameFingerprint(tempCtxShort, frameIdx, t);
                   shortCacheRef.current.set(frameIdx, fingerprint);
                   shortDatabase[frameIdx] = fingerprint; // Keep in order
                 } catch (err) {
                   console.error(`[SingleThread] Error scanning frame ${frameIdx}:`, err);
                 }
               }
               // Close the ImageBitmap to prevent GPU/memory leaks on main thread
               frame.close();
             }
          },
          (progress) => {
             setScanProgress(progress);
             setPipelineProgress(50 + Math.floor(progress * 0.5));
          }
        ).then(async () => {
           console.log("[WebCodecs] Short video decoding complete. Waiting for workers to finish...");
           if (shortPool) {
             await Promise.all(shortWorkerPromises);
             shortPool.terminate();
           }
           const t1Short = performance.now();
           console.log(`[TIMING] Short video decode: ${((t1Short - t0Short) / 1000).toFixed(2)}s for ${shortFramesDecoded} frames`);
           console.log("[WebCodecs] WebCodecs linear decoding complete for Short video!");
           // We might have missing trailing frames due to duration mismatches, pad them if needed
           const cleanDb = shortDatabase.filter(Boolean);
           setIsScanning(false);
           resolve(cleanDb);
        }).catch(err => {
           if (shortPool) shortPool.terminate();
           console.error("[WebCodecs] Fallback to seek-based method triggered because WebCodecs failed for short:", err);
           fallbackToSeek();
        });
      }
    });
  };

  // ---------------------------------------------------------------------------
  // SINGLE-CLICK UNIFIED TEMPORAL ALIGNMENT PIPELINE
  // ---------------------------------------------------------------------------
  const startUnifiedPipeline = async () => {
    if (isPipelineRunning || isIndexing || isScanning) return;
    
    setIsPipelineRunning(true);
    setPipelineProgress(0);
    setPipelineStage('preparing');
    setMatches([]);
    setActiveMatchIndex(-1);
    setLiveSimilarity(0);

    addLog("--- INITIALIZING UNIFIED TEMPORAL ALIGNMENT PIPELINE ---");

    try {
      const currentFps = fps;

      if (sourceType === 'demo') {
        // --- DEMO MODE (Fast Procedural Flow) ---
        // Stage 1: Index Reference Movie
        setPipelineStage('indexing');
        addLog(`[Stage 1/2] Generating structural fingerprints for Movie Reference at ${currentFps} FPS...`);
        const indexedDb = await performMovieIndexing(currentFps);
        setMovieDb(indexedDb);
        addLog(`[Stage 1/2] Compiled ${indexedDb.length} Reference frame structures.`);

        // Stage 2: Scan Short Remix
        setPipelineStage('scanning');
        addLog(`[Stage 2/2] Generating structural fingerprints for Short Remix at ${currentFps} FPS...`);
        const scannedDb = await performShortScanning(indexedDb, currentFps);
        setShortFingerprints(scannedDb);
        addLog(`[Stage 2/2] Compiled ${scannedDb.length} Remix frame structures.`);

        // Stage 3: Align Temporal Segments
        setPipelineStage('aligning');
        addLog("Applying sequence alignment matchers to match timelines...");
        
        const grounded = groundMatchedSegments(
          scannedDb,
          indexedDb,
          similarityThreshold,
          minSegmentDuration,
          frameTolerance
        );

        setMatches(grounded);
        setPipelineStage('complete');
        setPipelineProgress(100);
        addLog(`Temporal matching completed! Identified ${grounded.length} continuous matches.`);
        
        grounded.forEach((seg, i) => {
          addLog(`Match #${i+1}: Remix [${seg.shortStart}s - ${seg.shortEnd}s] maps to Movie [${seg.movieStart}s - ${seg.movieEnd}s] Confidence: ${seg.confidence}%`);
        });

        if (grounded.length === 0) {
          addLog("No matches found. Try lowering the Hash Match Tolerance or lowering the Min Scene Duration.");
        }
      } else {
        // --- CUSTOM UPLOAD MODE (Ultra-Fast Smart Dynamic Search Flow) ---
        if (!movieFile || !shortFile) {
          addLog("Error: Missing files. Please upload both Channel A and Channel B videos first.");
          setIsPipelineRunning(false);
          setPipelineStage('idle');
          return;
        }

        // Sanity check file readability right before starting
        const isMovieOk = await checkFileAccess(movieFileRef.current, "Channel A (Movie)");
        if (!isMovieOk) {
          addLog("CRITICAL: Reference Movie file access has expired! Please click Channel A input and re-select the file.");
          throw new Error("File access expired for Reference Movie (Channel A). Please re-select the file.");
        }
        const isShortOk = await checkFileAccess(shortFileRef.current, "Channel B (Short)");
        if (!isShortOk) {
          addLog("CRITICAL: Remix Clip file access has expired! Please click Channel B input and re-select the file.");
          throw new Error("File access expired for Remix Clip (Channel B). Please re-select the file.");
        }

        addLog("Loading video metadata and verifying format codecs...");
        const movieVid = movieVideoRef.current;
        const shortVid = shortVideoRef.current;
        if (!movieVid || !shortVid) {
          setIsPipelineRunning(false);
          setPipelineStage('idle');
          return;
        }

        await ensureVideoLoaded(movieVid);
        await ensureVideoLoaded(shortVid);

        addLog(`Reference movie initialized: ${movieVid.duration.toFixed(2)}s. Remix clip initialized: ${shortVid.duration.toFixed(2)}s.`);

        // Stage 1: Index Reference Movie (0% to 50% progress)
        setPipelineStage('indexing');
        addLog(`[Stage 1/2] Generating structural fingerprints for Movie Reference at ${currentFps} FPS...`);
        const indexedDb = await performMovieIndexing(currentFps);
        setMovieDb(indexedDb);
        addLog(`[Stage 1/2] Compiled ${indexedDb.length} Reference frame structures.`);

        // Stage 2: Scan Short Remix (50% to 100% progress)
        setPipelineStage('scanning');
        addLog(`[Stage 2/2] Generating structural fingerprints for Short Remix at ${currentFps} FPS...`);

        // Check Short file freshness again after movie indexing completes to prevent silent failures
        const isShortStillOk = await checkFileAccess(shortFileRef.current, "Channel B (Short)");
        if (!isShortStillOk) {
          addLog("CRITICAL: Remix Clip file access expired during Reference Movie indexing! Please click Channel B input and re-select the file to continue.");
          throw new Error("File access expired for Remix Clip (Channel B) due to browser memory protection. Please re-select the file and run the pipeline again.");
        }

        const scannedDb = await performShortScanning(indexedDb, currentFps);
        setShortFingerprints(scannedDb);
        addLog(`[Stage 2/2] Compiled ${scannedDb.length} Remix frame structures.`);

        // Stage 3: Align Temporal Segments in memory
        setPipelineStage('aligning');
        addLog("Applying sequence alignment matchers to match timelines in memory...");
        
        const grounded = groundMatchedSegments(
          scannedDb,
          indexedDb,
          similarityThreshold,
          minSegmentDuration,
          frameTolerance
        );

        setMatches(grounded);
        setPipelineStage('complete');
        setPipelineProgress(100);
        addLog(`Temporal matching completed! Identified ${grounded.length} continuous matches.`);
        
        grounded.forEach((seg, i) => {
          addLog(`Match #${i+1}: Remix [${seg.shortStart}s - ${seg.shortEnd}s] maps to Movie [${seg.movieStart}s - ${seg.movieEnd}s] Confidence: ${seg.confidence}%`);
        });

        if (grounded.length === 0) {
          addLog("No matches found. Try lowering the Hash Match Tolerance or lowering the Min Scene Duration.");
        }
      }

    } catch (error: any) {
      addLog(`Pipeline Error: ${error.message || error}`);
      setPipelineStage('idle');
    } finally {
      setIsPipelineRunning(false);
    }
  };

  // ---------------------------------------------------------------------------
  // CUT LIST FAST MATCH PIPELINE (TARGETED FRAME LOOKUP - MAXIMUM SPEED)
  // ---------------------------------------------------------------------------
  // Instead of scanning EVERY frame of the short video, the user supplies a
  // pre-computed cut list. For each cut we only need to:
  //   1. Grab the cut's START frame from the short video (start_frame_time)
  //   2. Search the full movie for that single frame (coarse -> fine)
  //   3. DOUBLE-CHECK with a second verification frame (start + offset)
  //   4. Map the given frame count forward: movieEnd = movieStart + frames/fps
  // The last_frame_time in the cut list is intentionally IGNORED (per spec).
  const startCutListPipeline = async () => {
    if (isPipelineRunning || isIndexing || isScanning) return;

    const parsed = parseCutList(cutListInput, fps);
    parsed.errors.forEach(err => addLog(`Cut List Warning: ${err}`));

    if (parsed.cuts.length === 0) {
      addLog("Cut List Error: No valid cuts parsed. Please check the JSON format (see example format).");
      return;
    }

    setIsPipelineRunning(true);
    setPipelineProgress(0);
    setPipelineStage('preparing');
    setMatches([]);
    setActiveMatchIndex(-1);
    setLiveSimilarity(0);

    const currentFps = parsed.fps;
    addLog(`--- CUT LIST FAST MATCH PIPELINE INITIALIZED (${parsed.cuts.length} cuts @ ${currentFps} FPS) ---`);

    try {
      // -----------------------------------------------------------------------
      // SETUP CAPTURE HELPERS (branch: demo procedural vs uploaded videos)
      // -----------------------------------------------------------------------
      const shortCanvas = document.createElement('canvas');
      const movieCanvas = document.createElement('canvas');
      let shortCtx: CanvasRenderingContext2D | null = null;
      let movieCtx: CanvasRenderingContext2D | null = null;

      let totalMovieDuration = DEMO_MOVIE_DURATION;
      let shortDuration = DEMO_SHORT_DURATION;

      const movieVid = movieVideoRef.current;
      const shortVid = shortVideoRef.current;

      if (sourceType === 'upload') {
        if (!movieFile || !shortFile || !movieVid || !shortVid) {
          addLog("Error: Missing files. Please upload both Channel A and Channel B videos first.");
          setIsPipelineRunning(false);
          setPipelineStage('idle');
          return;
        }

        // Sanity check file readability right before starting
        const isMovieOk = await checkFileAccess(movieFileRef.current, "Channel A (Movie)");
        if (!isMovieOk) {
          addLog("CRITICAL: Reference Movie file access has expired! Please click Channel A input and re-select the file.");
          throw new Error("File access expired for Reference Movie (Channel A). Please re-select the file.");
        }
        const isShortOk = await checkFileAccess(shortFileRef.current, "Channel B (Short)");
        if (!isShortOk) {
          addLog("CRITICAL: Remix Clip file access has expired! Please click Channel B input and re-select the file.");
          throw new Error("File access expired for Remix Clip (Channel B). Please re-select the file.");
        }

        await ensureVideoLoaded(movieVid);
        await ensureVideoLoaded(shortVid);
        movieVid.pause();
        shortVid.pause();

        totalMovieDuration = movieVid.duration || 45;
        shortDuration = shortVid.duration || 10;

        const sAspect = shortVid.videoWidth / shortVid.videoHeight || 1.777;
        shortCanvas.width = 160;
        shortCanvas.height = Math.round(160 / sAspect);

        const mAspect = movieVid.videoWidth / movieVid.videoHeight || 1.777;
        movieCanvas.width = 160;
        movieCanvas.height = Math.round(160 / mAspect);
      } else {
        shortCanvas.width = 160;
        shortCanvas.height = 90;
        movieCanvas.width = 160;
        movieCanvas.height = 90;
      }

      shortCtx = shortCanvas.getContext('2d', { willReadFrequently: true });
      movieCtx = movieCanvas.getContext('2d', { willReadFrequently: true });
      if (!shortCtx || !movieCtx) {
        throw new Error("Could not create canvas 2D contexts");
      }

      // Capture a single SHORT video frame fingerprint at an exact timestamp
      const captureShortFrameAt = (t: number): Promise<FrameFingerprint> => {
        return new Promise((resolveCapture, rejectCapture) => {
          const clamped = Math.max(0, Math.min(t, shortDuration - 0.001));
          const frameIdx = Math.round(clamped * currentFps);
          
          if (shortCacheRef.current.has(frameIdx)) {
            resolveCapture(shortCacheRef.current.get(frameIdx)!);
            return;
          }

          if (sourceType === 'demo') {
            const sceneInfo = getShortVideoSceneAtTime(clamped);
            drawProceduralFrame(shortCtx!, shortCanvas.width, shortCanvas.height, clamped, sceneInfo.sceneId, shortGrade);
            const fp = computeFrameFingerprint(shortCtx!, frameIdx, clamped);
            shortCacheRef.current.set(frameIdx, fp);
            resolveCapture(fp);
          } else {
            const video = shortVid!;
            video.currentTime = clamped;
            const onSeeked = () => {
              video.removeEventListener('seeked', onSeeked);
              try {
                shortCtx!.drawImage(video, 0, 0, shortCanvas.width, shortCanvas.height);
                const fp = computeFrameFingerprint(shortCtx!, frameIdx, clamped);
                shortCacheRef.current.set(frameIdx, fp);
                resolveCapture(fp);
              } catch (err: any) {
                rejectCapture(err);
              }
            };
            video.addEventListener('seeked', onSeeked);
          }
        });
      };

      // Capture a single MOVIE frame fingerprint by frame index (cached)
      const totalMovieFrames = Math.floor(totalMovieDuration * currentFps);
      const movieCache: (FrameFingerprint | null)[] = new Array(totalMovieFrames).fill(null);

      const captureMovieFrame = (frameIdx: number): Promise<FrameFingerprint> => {
        return new Promise((resolveCapture, rejectCapture) => {
          const clampedIdx = Math.max(0, Math.min(frameIdx, totalMovieFrames - 1));
          if (movieCache[clampedIdx]) {
            resolveCapture(movieCache[clampedIdx]!);
            return;
          }
          if (movieCacheRef.current.has(clampedIdx)) {
            const cached = movieCacheRef.current.get(clampedIdx)!;
            movieCache[clampedIdx] = cached;
            resolveCapture(cached);
            return;
          }

          const t = clampedIdx / currentFps;
          if (sourceType === 'demo') {
            const sceneId = getMovieSceneAtTime(t);
            drawProceduralFrame(movieCtx!, movieCanvas.width, movieCanvas.height, t, sceneId, movieGrade);
            const fp = computeFrameFingerprint(movieCtx!, clampedIdx, t);
            movieCache[clampedIdx] = fp;
            movieCacheRef.current.set(clampedIdx, fp);
            resolveCapture(fp);
          } else {
            const video = movieVid!;
            video.currentTime = t;
            const onSeeked = () => {
              video.removeEventListener('seeked', onSeeked);
              try {
                movieCtx!.drawImage(video, 0, 0, movieCanvas.width, movieCanvas.height);
                const fp = computeFrameFingerprint(movieCtx!, clampedIdx, t);
                movieCache[clampedIdx] = fp;
                movieCacheRef.current.set(clampedIdx, fp);
                resolveCapture(fp);
              } catch (err: any) {
                rejectCapture(err);
              }
            };
            video.addEventListener('seeked', onSeeked);
          }
        });
      };

      // -----------------------------------------------------------------------
      // STAGE 1: EXTRACT ONLY THE NEEDED SHORT FRAMES (start + verify per cut)
      // -----------------------------------------------------------------------
      setPipelineStage('scanning');
      addLog(`[Stage 1/2] Extracting ${parsed.cuts.length * 2} targeted frames from Short (start + verification per cut)...`);

      interface CutProbe {
        cut: CutEntry;
        startFp: FrameFingerprint;
        verifyFp: FrameFingerprint;
        verifyOffsetFrames: number;
        matchedConfidently?: boolean;
        bestApprox?: { movieIdx: number; startSim: number; verifySim: number };
      }

      const probes: CutProbe[] = [];
      for (let i = 0; i < parsed.cuts.length; i++) {
        const cut = parsed.cuts[i];
        // Verification frame: a few frames after the start, but always inside the cut
        const verifyOffsetFrames = Math.max(1, Math.min(5, cut.frames - 1));
        const startFp = await captureShortFrameAt(cut.startTimeSeconds);
        const verifyFp = await captureShortFrameAt(cut.startTimeSeconds + verifyOffsetFrames / currentFps);
        probes.push({ cut, startFp, verifyFp, verifyOffsetFrames });

        const progress = Math.floor(((i + 1) / parsed.cuts.length) * 100);
        setScanProgress(progress);
        setPipelineProgress(Math.floor(progress * 0.15)); // 0% - 15%
      }
      addLog(`[Stage 1/2] Done. Only ${probes.length * 2} short frames needed (vs full scan of ${Math.floor(shortDuration * currentFps)} frames).`);

      // -----------------------------------------------------------------------
      // STAGE 2: SIMULTANEOUS COARSE SCAN & ON-THE-FLY ALIGNMENT
      // -----------------------------------------------------------------------
      setPipelineStage('scanning');
      addLog(`[Stage 2/2] Scanning movie to locate ${probes.length} cuts simultaneously...`);

      if (sourceType === 'upload' && movieFile) {
        addLog("Attempting ultra-fast WebCodecs linear decoding for Movie...");
        console.log("[WebCodecs] Starting WebCodecs path for Movie video...");
        const t0Movie = performance.now();
        let movieFramesDecoded = 0;
        const movieStagePool = useParallelization ? new FingerprintWorkerPool() : null;
        const movieStagePromises: Promise<any>[] = [];

        // Offscreen canvas for main-thread rendering if parallelization is disabled
        const tempCanvasStage2 = document.createElement('canvas');
        tempCanvasStage2.width = 160;
        tempCanvasStage2.height = 90;
        const tempCtxStage2 = tempCanvasStage2.getContext('2d', { willReadFrequently: true });

        try {
          await extractFramesLinearWebCodecs(
            movieFileRef.current || movieFile,
            currentFps,
            (frame, t, frameIdx) => {
               movieFramesDecoded++;
               if (movieStagePool) {
                 const promise = movieStagePool.computeFingerprint(frame, frameIdx, t)
                   .then((fingerprint) => {
                      movieCacheRef.current.set(frameIdx, fingerprint);
                   })
                   .catch(err => {
                      console.error(`[WorkerPool] Error in movie stage 2 worker frame ${frameIdx}:`, err);
                   });
                 movieStagePromises.push(promise);
               } else {
                 // Single-threaded fallback
                 if (tempCtxStage2) {
                   tempCtxStage2.drawImage(frame, 0, 0, tempCanvasStage2.width, tempCanvasStage2.height);
                   try {
                     const fingerprint = computeFrameFingerprint(tempCtxStage2, frameIdx, t);
                     movieCacheRef.current.set(frameIdx, fingerprint);
                   } catch (err) {
                     console.error(`[SingleThread] Error stage 2 frame ${frameIdx}:`, err);
                   }
                 }
                 // Close the ImageBitmap to prevent GPU/memory leaks on main thread
                 frame.close();
               }
            },
            (progress) => {
               setIndexProgress(progress);
               setPipelineProgress(15 + Math.floor(progress * 0.2)); // 15% - 35%
            }
          );
          console.log("[WebCodecs] Movie Stage 2 decoding complete. Waiting for workers to finish...");
          if (movieStagePool) {
            await Promise.all(movieStagePromises);
            movieStagePool.terminate();
          }
          const t1Movie = performance.now();
          console.log(`[TIMING] Movie decode: ${((t1Movie - t0Movie) / 1000).toFixed(2)}s for ${movieFramesDecoded} frames`);
          addLog("WebCodecs linear decoding complete! All movie frames cached instantly.");
          console.log("[WebCodecs] WebCodecs linear decoding complete for Movie video!");
        } catch(err) {
          if (movieStagePool) movieStagePool.terminate();
          console.error("[WebCodecs] Fallback to seek-based method triggered because WebCodecs failed for movie:", err);
          addLog(`WebCodecs fallback: using seeked approach. (${(err as any).message})`);
        }
      }

      const COARSE_STEP = 12; // 0.5s step for a good balance of speed/accuracy
      let matchedCount = 0;

      const t0Align = performance.now();
      for (let f = 0; f < totalMovieFrames; f += COARSE_STEP) {
        if (matchedCount === probes.length) {
          addLog("All cuts confidently matched! Aborting remaining scan early to save time.");
          break;
        }

        const progress = Math.floor((f / totalMovieFrames) * 100);
        setIndexProgress(progress);
        setPipelineProgress(15 + Math.floor(progress * 0.85));

        const mf = await captureMovieFrame(f);

        for (const probe of probes) {
          if (probe.matchedConfidently) continue;

          const sim = getFrameSimilarity(probe.startFp, mf);
          
          if (sim >= 40.0) { // Coarse candidate found!
            // Do fine search around this neighborhood
            const searchStart = Math.max(0, f - COARSE_STEP);
            const searchEnd = Math.min(totalMovieFrames - 1, f + COARSE_STEP);
            
            let bestExactIdx = -1;
            let highestExactSim = 0;

            for (let fineF = searchStart; fineF <= searchEnd; fineF++) {
              const fineMf = await captureMovieFrame(fineF);
              const fineSim = getFrameSimilarity(probe.startFp, fineMf);
              if (fineSim > highestExactSim) {
                highestExactSim = fineSim;
                bestExactIdx = fineF;
              }
            }

            if (bestExactIdx !== -1) {
              // Double check verification
              let verifySim = 0;
              const verifyIdx = Math.min(totalMovieFrames - 1, bestExactIdx + probe.verifyOffsetFrames);
              const verifyMf = await captureMovieFrame(verifyIdx);
              verifySim = getFrameSimilarity(probe.verifyFp, verifyMf);

              // Track best approx in case we never find a confident match
              const comboScore = highestExactSim + verifySim;
              if (!probe.bestApprox || comboScore > probe.bestApprox.startSim + probe.bestApprox.verifySim) {
                probe.bestApprox = { movieIdx: bestExactIdx, startSim: highestExactSim, verifySim };
              }

              // Confident match early accept (Stricter than fallback to ensure accuracy)
              if (highestExactSim >= similarityThreshold + 2 && verifySim >= similarityThreshold - 3) {
                probe.matchedConfidently = true;
                matchedCount++;
                addLog(`Cut #${probe.cut.cut}: PERFECT MATCH ✓ Start ${highestExactSim.toFixed(1)}% + 2nd ${verifySim.toFixed(1)}% at Movie [${(bestExactIdx / currentFps).toFixed(2)}s].`);
              }
            }
          }
        }
      }

      setPipelineStage('aligning');
      const cutMatches: MatchedSegment[] = [];

      // Finalize matches (Confident or best fallback)
      for (const probe of probes) {
        if (probe.bestApprox && probe.bestApprox.startSim >= 40.0) {
          const movieStartTime = probe.bestApprox.movieIdx / currentFps;
          const mappedDuration = (probe.cut.frames - 1) / currentFps;
          
          cutMatches.push({
            id: `cutmatch_${Math.random().toString(36).substring(2, 9)}`,
            shortStart: Number(probe.cut.startTimeSeconds.toFixed(3)),
            shortEnd: Number((probe.cut.startTimeSeconds + mappedDuration).toFixed(3)),
            movieStart: Number(movieStartTime.toFixed(3)),
            movieEnd: Number((movieStartTime + mappedDuration).toFixed(3)),
            confidence: Number(((probe.bestApprox.startSim + probe.bestApprox.verifySim) / 2).toFixed(1)),
            frameCount: probe.cut.frames,
            isApproximate: !probe.matchedConfidently,
            matchSequence: [
              { shortTime: probe.cut.startTimeSeconds, movieTime: movieStartTime, similarity: probe.bestApprox.startSim },
              { shortTime: probe.cut.startTimeSeconds + probe.verifyOffsetFrames / currentFps, movieTime: movieStartTime + probe.verifyOffsetFrames / currentFps, similarity: probe.bestApprox.verifySim }
            ]
          });
          
          if (!probe.matchedConfidently) {
            addLog(`Cut #${probe.cut.cut}: APPROXIMATE ~ Best candidate ${probe.bestApprox.startSim.toFixed(1)}% / verify ${probe.bestApprox.verifySim.toFixed(1)}% at Movie [${movieStartTime.toFixed(2)}s].`);
          }
        } else {
           addLog(`Cut #${probe.cut.cut}: NO MATCH FOUND for start frame at Short [${probe.cut.startTimeSeconds.toFixed(2)}s].`);
        }
      }

      // Sort matches by time
      cutMatches.sort((a, b) => a.shortStart - b.shortStart);

      const t1Align = performance.now();
      console.log(`[TIMING] Matching/alignment: ${((t1Align - t0Align) / 1000).toFixed(2)}s`);

      // Publish results (JSON output auto-generates from `matches` state)
      const validMovieDb = movieCache.map((item, idx) => {
        if (item) return item;
        return {
          frameIndex: idx,
          timestamp: idx / currentFps,
          hash: '0'.repeat(256),
          hashCenter916: '0'.repeat(256)
        };
      });

      setMovieDb(validMovieDb);
      setMatches(cutMatches);
      setPipelineStage('complete');
      setPipelineProgress(100);

      const verifiedCount = cutMatches.filter(m => !m.isApproximate).length;
      addLog(`Cut List Fast Match completed! ${verifiedCount}/${parsed.cuts.length} cuts double-verified, ${cutMatches.length - verifiedCount} approximate. JSON output ready.`);
    } catch (error: any) {
      addLog(`Cut List Pipeline Error: ${error.message || error}`);
      setPipelineStage('idle');
    } finally {
      setIsPipelineRunning(false);
    }
  };

  // ---------------------------------------------------------------------------
  // GENERATE MATCHED SEGMENTS JSON STRUCTURE
  // ---------------------------------------------------------------------------
  useEffect(() => {
    const jsonFormatted = matches.map((seg, i) => ({
      short_video_clip: `Scene_${(i + 1).toString().padStart(2, '0')}`,
      short_duration: {
        start: formatTimestamp(seg.shortStart),
        end: formatTimestamp(seg.shortEnd),
        duration_seconds: Number((seg.shortEnd - seg.shortStart).toFixed(2))
      },
      matched_in_movie: {
        movie_name: sourceType === 'demo' ? "Hollywood_SciFi_Master.mp4" : (movieFile?.name || "Uploaded_Movie.mp4"),
        start_timestamp: formatTimestamp(seg.movieStart),
        end_timestamp: formatTimestamp(seg.movieEnd),
        confidence: `${seg.confidence}%`,
        fps_match: fps,
        total_matching_frames: seg.frameCount,
        metadata_validation: "Verified sequence pattern match at 24fps"
      }
    }));

    setJsonView(JSON.stringify(jsonFormatted, null, 2));
  }, [matches, sourceType, movieFile, fps]);

  // Convert seconds to hh:mm:ss:ff or mm:ss.ff for elegant visual timestamp mapping
  const formatTimestamp = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    const wholeSecs = Math.floor(remainingSecs);
    const frames = Math.floor((remainingSecs - wholeSecs) * fps);
    
    return `${mins.toString().padStart(2, '0')}:${wholeSecs.toString().padStart(2, '0')}:${frames.toString().padStart(2, '0')}`;
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(jsonView);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    addLog("System logs exported to clipboard.");
  };

  // ---------------------------------------------------------------------------
  // INTERACTIVE CLIPS PLAYBACK CONTROLLER
  // ---------------------------------------------------------------------------
  const playMatchedSegment = (index: number) => {
    if (index < 0 || index >= matches.length) return;
    
    setIsPlaying(false);
    setActiveMatchIndex(index);
    const seg = matches[index];
    
    addLog(`Verifying Segment #${index + 1}: Sync playing Short [${seg.shortStart}s] and Movie [${seg.movieStart}s] side-by-side.`);
    
    setCurrentTime(seg.shortStart);
    setSyncMovieTime(seg.movieStart);

    // Instant HTML5 cueing for upload mode to prevent lag
    if (sourceType === 'upload') {
      const shortVid = shortVideoRef.current;
      const movieVid = movieVideoRef.current;
      if (shortVid && movieVid) {
        shortVid.currentTime = seg.shortStart;
        movieVid.currentTime = seg.movieStart;

        // Synchronize rates based on timescale ratio
        let ratio = 1.0;
        const shortDur = seg.shortEnd - seg.shortStart;
        if (shortDur > 0) {
          ratio = (seg.movieEnd - seg.movieStart) / shortDur;
        }
        shortVid.playbackRate = playbackSpeed;
        movieVid.playbackRate = playbackSpeed * ratio;
      }
    }
    
    renderFrames(seg.shortStart);
    
    // Auto initiate play loop
    setTimeout(() => {
      setIsPlaying(true);
    }, 150);
  };

  // ---------------------------------------------------------------------------
  // FILE HANDLERS FOR UPLOAD MODE
  // ---------------------------------------------------------------------------
  const handleMovieUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMovieFile(file);
      setMovieUrl(URL.createObjectURL(file));
      setMovieDb([]);
      setMatches([]);
      addLog(`Movie File uploaded: ${file.name} (${(file.size / (1024 * 1024)).toFixed(1)} MB)`);
    }
  };

  const handleShortUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setShortFile(file);
      setShortUrl(URL.createObjectURL(file));
      setShortFingerprints([]);
      setMatches([]);
      addLog(`Short Remix Video uploaded: ${file.name} (${(file.size / (1024 * 1024)).toFixed(1)} MB)`);
    }
  };

  // ===========================================================================
  // RENDER UI JSX
  // ===========================================================================
  return (
    <div className="min-h-screen bg-tech-bg text-tech-dark font-sans antialiased selection:bg-tech-dark/10 selection:text-tech-dark p-4 lg:p-6" id="app_root">
      {/* HEADER SECTION */}
      <header className="mb-6 max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4 border border-tech-dark bg-tech-accent p-4 md:p-5" id="app_header">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 bg-tech-dark text-tech-bg rounded-none border border-tech-dark">
              <Layers className="w-5 h-5" />
            </span>
            <h1 className="text-xl lg:text-2xl font-bold tracking-tight text-tech-dark font-display uppercase">
              Copyright Visual Match Tool
            </h1>
            <div className="px-2 py-0.5 bg-tech-dark text-tech-bg border border-tech-dark text-[10px] uppercase font-mono font-bold tracking-wider rounded-none">
              24 FPS Engine
            </div>
          </div>
          <p className="text-xs text-tech-dark/80 max-w-2xl">
            Grayscale Perceptual Hashing (aHash) & Temporal grounding scanner. Identifies same scenes in mashup short videos by comparing frame structures, immune to cinematic color grading filters.
          </p>
        </div>

        {/* Demo Mode vs Upload Selectors */}
        <div className="flex items-center gap-2 self-start md:self-center" id="mode_select">
          <button
            onClick={() => setSourceType('demo')}
            className={`px-3 py-1.5 rounded-none text-xs font-mono font-bold transition-all ${
              sourceType === 'demo'
                ? 'bg-tech-dark text-tech-bg border border-tech-dark'
                : 'bg-transparent border border-tech-dark/40 text-tech-dark hover:bg-tech-accent/50'
            }`}
            id="btn_demo_mode"
          >
            Procedural Demo (Instant)
          </button>
          <button
            onClick={() => setSourceType('upload')}
            className={`px-3 py-1.5 rounded-none text-xs font-mono font-bold transition-all ${
              sourceType === 'upload'
                ? 'bg-tech-dark text-tech-bg border border-tech-dark'
                : 'bg-transparent border border-tech-dark/40 text-tech-dark hover:bg-tech-accent/50'
            }`}
            id="btn_upload_mode"
          >
            Custom File Upload
          </button>
        </div>
      </header>

      {/* MAIN LAYOUT CONTAINER */}
      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-5" id="main_content">
        
        {/* LEFT COLUMN: CONTROL ROOM & ADVANCED HYPERPARAMETERS */}
        <section className="lg:col-span-3 space-y-5" id="left_panel">
          
          {/* VIDEO INPUT MODULES */}
          <div className="bg-tech-accent/40 border border-tech-muted rounded-none p-4 space-y-4 shadow-none" id="card_video_inputs">
            <h2 className="text-xs uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-2 border-b border-tech-dark/30 pb-2">
              <Video className="w-3.5 h-3.5 text-tech-dark" />
              Video Channel Sources
            </h2>

            {sourceType === 'demo' ? (
              <div className="space-y-3.5" id="demo_channel_configs">
                <div className="p-2.5 bg-tech-accent/60 rounded-none border border-tech-muted">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-mono text-tech-dark font-semibold">Channel A: Full Movie</span>
                    <span className="text-[10px] font-mono text-tech-dark bg-tech-dark/10 px-1.5 py-0.5 rounded-none border border-tech-dark/20 font-bold">45 Secs</span>
                  </div>
                  <p className="text-[10px] text-tech-dark/70 mb-2">Procedural cinematic movie scenes at 24fps.</p>
                  <label className="block text-[9px] font-mono text-tech-dark/80 mb-1">Robustness Test (Color Grade):</label>
                  <select
                    value={movieGrade}
                    onChange={(e) => setMovieGrade(e.target.value as ColorGrade)}
                    className="w-full bg-tech-bg border border-tech-dark rounded-none px-2 py-1 text-[11px] font-mono text-tech-dark focus:outline-none focus:ring-1 focus:ring-tech-dark"
                    id="select_movie_grade"
                  >
                    <option value="Standard">Standard Cinematic</option>
                    <option value="Snyder">Snyder Cut (Desaturated, Blue-Cool)</option>
                    <option value="RetroSepia">Retro Warm Sepia (Vintage)</option>
                    <option value="Cyberpunk">Cyberpunk Neon Swap (Hot Purple/Pink)</option>
                  </select>
                </div>

                <div className="p-2.5 bg-tech-accent/60 rounded-none border border-tech-muted">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-mono text-tech-dark font-semibold">Channel B: Short Remix</span>
                    <span className="text-[10px] font-mono text-tech-dark bg-tech-dark/10 px-1.5 py-0.5 rounded-none border border-tech-dark/20 font-bold">10 Secs</span>
                  </div>
                  <p className="text-[10px] text-tech-dark/70 mb-2">Composed of randomized movie scenes cut together.</p>
                  <label className="block text-[9px] font-mono text-tech-dark/80 mb-1">Robustness Test (Color Grade):</label>
                  <select
                    value={shortGrade}
                    onChange={(e) => setShortGrade(e.target.value as ColorGrade)}
                    className="w-full bg-tech-bg border border-tech-dark rounded-none px-2 py-1 text-[11px] font-mono text-tech-dark focus:outline-none focus:ring-1 focus:ring-tech-dark"
                    id="select_short_grade"
                  >
                    <option value="Standard">Standard Cinematic</option>
                    <option value="Snyder">Snyder Cut (Desaturated, Blue-Cool)</option>
                    <option value="RetroSepia">Retro Warm Sepia (Vintage)</option>
                    <option value="Cyberpunk">Cyberpunk Neon Swap (Hot Purple/Pink)</option>
                  </select>
                </div>
              </div>
            ) : (
              <div className="space-y-4" id="upload_file_inputs">
                {/* Full Movie upload */}
                <div className="space-y-2">
                  <label className="block text-[11px] font-mono text-tech-dark font-bold">Channel A: Full Movie (Reference)</label>
                  <div className="relative group border border-dashed border-tech-dark/50 hover:border-tech-dark bg-tech-accent/20 rounded-none p-3 transition-all">
                    <input
                      type="file"
                      accept="video/*"
                      onChange={handleMovieUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      id="input_movie_file"
                    />
                    <div className="flex flex-col items-center justify-center text-center">
                      {movieFile ? (
                        <>
                          <FileVideo className="w-6 h-6 text-tech-dark mb-1" />
                          <p className="text-[10px] font-mono text-tech-dark truncate max-w-full px-2 font-bold">{movieFile.name}</p>
                          <p className="text-[9px] text-tech-dark/70">{(movieFile.size / (1024*1024)).toFixed(1)} MB - Ready</p>
                        </>
                      ) : (
                        <>
                          <UploadCloud className="w-6 h-6 text-tech-dark/50 group-hover:text-tech-dark mb-1 transition-colors" />
                          <p className="text-[10px] text-tech-dark font-medium">Click / Drag to upload Movie</p>
                          <p className="text-[9px] text-tech-dark/60">MP4, WebM up to 50MB</p>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Short video upload */}
                <div className="space-y-2">
                  <label className="block text-[11px] font-mono text-tech-dark font-bold">Channel B: Short Remix (Mashup)</label>
                  <div className="relative group border border-dashed border-tech-dark/50 hover:border-tech-dark bg-tech-accent/20 rounded-none p-3 transition-all">
                    <input
                      type="file"
                      accept="video/*"
                      onChange={handleShortUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      id="input_short_file"
                    />
                    <div className="flex flex-col items-center justify-center text-center">
                      {shortFile ? (
                        <>
                          <FileVideo className="w-6 h-6 text-tech-dark mb-1" />
                          <p className="text-[10px] font-mono text-tech-dark truncate max-w-full px-2 font-bold">{shortFile.name}</p>
                          <p className="text-[9px] text-tech-dark/70">{(shortFile.size / (1024*1024)).toFixed(1)} MB - Ready</p>
                        </>
                      ) : (
                        <>
                          <UploadCloud className="w-6 h-6 text-tech-dark/50 group-hover:text-tech-dark mb-1 transition-colors" />
                          <p className="text-[10px] text-tech-dark font-medium">Click / Drag to upload Short Video</p>
                          <p className="text-[9px] text-tech-dark/60">MP4, WebM up to 15MB</p>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="pt-2.5 border-t border-tech-dark/20 mt-4 space-y-1">
                  <button
                    type="button"
                    onClick={loadSampleVideos}
                    disabled={isGeneratingSamples || isPipelineRunning}
                    className="w-full py-2 bg-tech-dark hover:bg-tech-dark/90 text-tech-bg text-[10px] font-mono font-bold uppercase transition-all flex items-center justify-center gap-1.5"
                    id="btn_load_samples"
                  >
                    {isGeneratingSamples ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Generating Video Samples...
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5 fill-current text-yellow-400" />
                        Load Browser Sample Videos
                      </>
                    )}
                  </button>
                  <p className="text-[9px] text-tech-dark/60 text-center leading-normal">
                    Don't have files? Click above to programmatically draw and compile test WebM clips in your browser memory!
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* PARAMETERS CONFIGURATOR */}
          <div className="bg-tech-accent/40 border border-tech-muted rounded-none p-4 space-y-4 shadow-none" id="card_parameters">
            <h2 className="text-xs uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-2 border-b border-tech-dark/30 pb-2">
              <Sliders className="w-3.5 h-3.5 text-tech-dark" />
              Engine Parameters
            </h2>

            <div className="space-y-4" id="sliders_container">
              {/* FPS selector */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-tech-dark/80">FPS Mapping Rate:</span>
                  <span className="text-tech-dark font-extrabold">{fps} frames/s</span>
                </div>
                <input
                  type="range"
                  min="12"
                  max="30"
                  step="1"
                  value={fps}
                  onChange={(e) => setFps(parseInt(e.target.value))}
                  disabled={isIndexing || isScanning}
                  className="w-full h-1.5 bg-tech-bg border border-tech-dark/30 rounded-none appearance-none cursor-pointer accent-tech-dark"
                  id="range_fps"
                />
                <p className="text-[9px] text-tech-dark/60">Standard cinematic 24 FPS match requirement.</p>
              </div>

              {/* Similarity Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-tech-dark/80">Hash Match Tolerance:</span>
                  <span className="text-tech-dark font-extrabold">≥ {similarityThreshold}%</span>
                </div>
                <input
                  type="range"
                  min="70"
                  max="95"
                  step="1"
                  value={similarityThreshold}
                  onChange={(e) => setSimilarityThreshold(parseInt(e.target.value))}
                  disabled={isIndexing || isScanning}
                  className="w-full h-1.5 bg-tech-bg border border-tech-dark/30 rounded-none appearance-none cursor-pointer accent-tech-dark"
                  id="range_similarity"
                />
                <p className="text-[9px] text-tech-dark/60">Min % similarity of grayscale structural grid to trigger frame match.</p>
              </div>

              {/* Minimum Duration Slider */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-tech-dark/80">Min Scene Duration:</span>
                  <span className="text-tech-dark font-extrabold">{minSegmentDuration}s</span>
                </div>
                <input
                  type="range"
                  min="0.3"
                  max="2.5"
                  step="0.1"
                  value={minSegmentDuration}
                  onChange={(e) => setMinSegmentDuration(parseFloat(e.target.value))}
                  disabled={isIndexing || isScanning}
                  className="w-full h-1.5 bg-tech-bg border border-tech-dark/30 rounded-none appearance-none cursor-pointer accent-tech-dark"
                  id="range_min_duration"
                />
                <p className="text-[9px] text-tech-dark/60">Filters random single-frame blips. Match sequences must span this duration.</p>
              </div>

              {/* Frame Jitter Tolerance */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-tech-dark/80">Sequence Frame Drift:</span>
                  <span className="text-tech-dark font-extrabold">± {frameTolerance} frames</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="6"
                  step="1"
                  value={frameTolerance}
                  onChange={(e) => setFrameTolerance(parseInt(e.target.value))}
                  disabled={isIndexing || isScanning}
                  className="w-full h-1.5 bg-tech-bg border border-tech-dark/30 rounded-none appearance-none cursor-pointer accent-tech-dark"
                  id="range_tolerance"
                />
                <p className="text-[9px] text-tech-dark/60">Allows matching clips with minor frame drops or speed drift.</p>
              </div>
            </div>
          </div>

          {/* ACTION BUTTON CONTROLS */}
          <div className="bg-tech-accent/40 border border-tech-muted rounded-none p-4 space-y-4 shadow-none" id="card_actions">
            <h2 className="text-xs uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-2 border-b border-tech-dark/30 pb-2">
              <Activity className="w-3.5 h-3.5 text-tech-dark" />
              Scan Control Center
            </h2>

            {isPipelineRunning ? (
              <div className="space-y-4 font-mono" id="pipeline_hud">
                {/* Pipeline Progress Header */}
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-tech-dark flex items-center gap-1.5 animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-red-600 inline-block animate-ping"></span>
                    STAGE: {pipelineStage.toUpperCase()}
                  </span>
                  <span className="text-tech-dark">{pipelineProgress}%</span>
                </div>

                {/* Main Progress Bar */}
                <div className="w-full bg-tech-bg border border-tech-dark/30 h-3 rounded-none overflow-hidden relative">
                  <div 
                    className="bg-tech-dark h-full transition-all duration-200" 
                    style={{ width: `${pipelineProgress}%` }} 
                  />
                </div>

                {/* Subtasks Progress Info */}
                <div className="text-[10px] space-y-2 border-t border-tech-dark/10 pt-2 text-tech-dark/80">
                  <div className="flex justify-between items-center">
                    <span>1. Indexing Reference Movie:</span>
                    <span className={pipelineStage === 'indexing' ? 'text-red-600 font-bold animate-pulse' : pipelineStage !== 'preparing' && pipelineStage !== 'indexing' ? 'text-emerald-600 font-bold' : ''}>
                      {pipelineStage === 'preparing' || pipelineStage === 'indexing' ? `${indexProgress}%` : 'Done ✓'}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>2. Scanning Short Mashup:</span>
                    <span className={pipelineStage === 'scanning' ? 'text-red-600 font-bold animate-pulse' : pipelineStage === 'complete' || pipelineStage === 'aligning' ? 'text-emerald-600 font-bold' : ''}>
                      {pipelineStage === 'scanning' ? `${scanProgress}%` : (pipelineStage === 'complete' || pipelineStage === 'aligning' ? 'Done ✓' : 'Pending')}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>3. Timeline Alignment:</span>
                    <span className={pipelineStage === 'aligning' ? 'text-red-600 font-bold animate-pulse' : pipelineStage === 'complete' ? 'text-emerald-600 font-bold' : ''}>
                      {pipelineStage === 'aligning' ? 'Running...' : pipelineStage === 'complete' ? 'Done ✓' : 'Pending'}
                    </span>
                  </div>
                </div>

                <div className="text-[9px] bg-black text-emerald-400 p-2 font-mono border border-tech-dark leading-snug">
                  {pipelineStage === 'preparing' && "Preparing workspace and decoders..."}
                  {pipelineStage === 'indexing' && `Seeking full movie reference... [${indexProgress}%]`}
                  {pipelineStage === 'scanning' && `Analyzing remix clips... [${scanProgress}%]`}
                  {pipelineStage === 'aligning' && "Cross-referencing fingerprint sequence tables..."}
                </div>
              </div>
            ) : (
              <div className="space-y-3" id="pipeline_idle">
                <button
                  onClick={startUnifiedPipeline}
                  disabled={sourceType === 'upload' && (!movieFile || !shortFile)}
                  className={`w-full py-3 rounded-none font-mono text-xs flex items-center justify-center gap-2 border transition-all ${
                    sourceType === 'upload' && (!movieFile || !shortFile)
                      ? 'bg-tech-accent/30 border-tech-muted text-tech-dark/45 cursor-not-allowed'
                      : 'bg-tech-dark text-tech-bg font-extrabold border-tech-dark hover:bg-tech-dark/95 hover:shadow-sm active:translate-y-[1px]'
                  }`}
                  id="btn_start_pipeline"
                >
                  <Zap className="w-3.5 h-3.5 fill-current text-yellow-400" />
                  Start Analysis Pipeline
                </button>

                {sourceType === 'upload' && (!movieFile || !shortFile) ? (
                  <p className="text-[9px] text-red-600 font-mono text-center">
                    Please load or generate video files above before running the scan.
                  </p>
                ) : (
                  <p className="text-[9px] text-tech-dark/70 font-mono text-center">
                    Press to automatically compile, scan, and align timelines.
                  </p>
                )}

                {/* CUT LIST FAST MATCH MODE */}
                <div className="border-t border-tech-dark/30 pt-3 space-y-2" id="cut_list_panel">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-1.5">
                      <FileJson className="w-3 h-3" />
                      Cut List Fast Match
                    </span>
                    <button
                      onClick={() => setCutListInput(EXAMPLE_CUT_LIST)}
                      className="text-[9px] font-mono underline text-tech-dark/70 hover:text-tech-dark"
                      id="btn_load_example_cutlist"
                    >
                      Load Example Format
                    </button>
                  </div>
                  <textarea
                    value={cutListInput}
                    onChange={(e) => setCutListInput(e.target.value)}
                    placeholder={'Paste cut list JSON here...\n{ "fps": 24, "cuts": [ { "cut": 1, "start_frame_time": "00:00:00:00", "last_frame_time": "00:00:02:11", "frames": 60 } ] }'}
                    rows={5}
                    spellCheck={false}
                    className="w-full bg-black text-emerald-400 text-[9px] font-mono p-2 border border-tech-dark rounded-none resize-y placeholder:text-emerald-400/40 focus:outline-none focus:ring-1 focus:ring-tech-dark"
                    id="textarea_cutlist"
                    aria-label="Cut list JSON input"
                  />
                  <button
                    onClick={startCutListPipeline}
                    disabled={cutListInput.trim().length === 0 || (sourceType === 'upload' && (!movieFile || !shortFile))}
                    className={`w-full py-2.5 rounded-none font-mono text-xs flex items-center justify-center gap-2 border transition-all ${
                      cutListInput.trim().length === 0 || (sourceType === 'upload' && (!movieFile || !shortFile))
                        ? 'bg-tech-accent/30 border-tech-muted text-tech-dark/45 cursor-not-allowed'
                        : 'bg-emerald-700 text-white font-extrabold border-tech-dark hover:bg-emerald-800 hover:shadow-sm active:translate-y-[1px]'
                    }`}
                    id="btn_start_cutlist_pipeline"
                  >
                    <Zap className="w-3.5 h-3.5 fill-current text-yellow-300" />
                    Start Cut List Fast Match
                  </button>
                  <p className="text-[9px] text-tech-dark/70 font-mono leading-snug">
                    Only the start frame of each cut is searched in the full movie, double-verified with a 2nd frame, then the given frame count is mapped forward. The last_frame_time is ignored.
                  </p>
                </div>

                {/* Reset button */}
                <button
                  onClick={handleReset}
                  className="w-full py-1.5 border border-tech-dark text-tech-dark hover:bg-tech-accent/50 bg-transparent rounded-none text-xs font-mono flex items-center justify-center gap-1.5 transition-all"
                  id="btn_reset_all"
                >
                  <RotateCcw className="w-3 h-3" />
                  Reset Engine
                </button>

                {/* Parallelization Toggle */}
                <div className="border-t border-tech-dark/20 pt-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-1.5">
                      <Cpu className="w-3 h-3 text-tech-dark" />
                      Web Worker Parallelization
                    </span>
                    <button
                      onClick={() => setUseParallelization(!useParallelization)}
                      className={`px-2.5 py-1 text-[9px] font-mono rounded-none border transition-all ${
                        useParallelization
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-400 font-extrabold'
                          : 'bg-tech-bg text-tech-dark/65 border-tech-dark/30 hover:bg-tech-accent/40'
                      }`}
                      id="btn_toggle_parallel"
                    >
                      {useParallelization ? 'ENABLED (MAX SPEED)' : 'DISABLED (FALLBACK)'}
                    </button>
                  </div>
                  <p className="text-[9px] text-tech-dark/65 font-mono leading-snug">
                    When enabled, decodes are farmed out across up to 8 threads. Disable to fall back entirely to single-threaded main-thread processing.
                  </p>
                </div>

                {/* Worker Accuracy Calibration Panel */}
                <div className="border-t border-tech-dark/20 pt-3 space-y-3" id="worker_calibration_panel">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-1.5">
                      <CheckSquare className="w-3.5 h-3.5 text-tech-dark" />
                      Worker Accuracy Calibration
                    </span>
                    <button
                      onClick={runWorkerDiagnostic}
                      disabled={diagnosticResults?.status === 'running'}
                      className="px-2.5 py-1 bg-tech-dark text-tech-bg border border-tech-dark rounded-none text-[9px] font-mono hover:bg-tech-dark/90 active:translate-y-[px] disabled:opacity-50"
                      id="btn_run_diagnostic"
                    >
                      {diagnosticResults?.status === 'running' ? 'Running Calibration...' : 'Run Sanity Test'}
                    </button>
                  </div>

                  <p className="text-[9px] text-tech-dark/65 font-mono leading-snug">
                    Executes side-by-side processing of 10 complex test frames on the Main Thread vs. Web Worker to guarantee 100% hash value integrity.
                  </p>

                  {diagnosticResults && (
                    <div className="bg-black/95 text-[9px] font-mono border border-tech-dark p-3 space-y-2">
                      <div className="flex items-center justify-between text-[10px] border-b border-tech-dark/30 pb-1.5">
                        <span className="text-gray-400">Available CPU Cores: <strong className="text-emerald-400">{diagnosticResults.cores}</strong></span>
                        <span>
                          Status: {diagnosticResults.status === 'running' && <span className="text-yellow-400 animate-pulse">Computing...</span>}
                          {diagnosticResults.status === 'success' && <span className="text-emerald-400 font-extrabold">✓ 100% IDENTICAL</span>}
                          {diagnosticResults.status === 'failed' && <span className="text-red-400 font-extrabold">✗ MISMATCH!</span>}
                        </span>
                      </div>

                      {diagnosticResults.error && (
                        <p className="text-red-400 font-mono text-[9px] bg-red-950/40 p-1 border border-red-900">{diagnosticResults.error}</p>
                      )}

                      {diagnosticResults.mismatches.length > 0 && (
                        <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1 divide-y divide-tech-dark/20">
                          {diagnosticResults.mismatches.map((item) => (
                            <div key={item.frameIdx} className="pt-1.5 first:pt-0">
                              <div className="flex justify-between items-center text-[10px]">
                                <span className="text-emerald-400 font-bold">Frame #{item.frameIdx}</span>
                                <span className={item.matches ? "text-emerald-400" : "text-red-400 font-bold"}>
                                  {item.matches ? "✓ IDENTICAL" : "✗ MISMATCH"}
                                </span>
                              </div>
                              <div className="grid grid-cols-2 gap-2 text-[8px] text-gray-400 mt-1">
                                <div className="truncate">
                                  <span className="text-gray-500">Main:</span> <span className="font-mono text-gray-300">{item.singleHash.slice(0, 12)}...{item.singleHash.slice(-12)}</span>
                                </div>
                                <div className="truncate">
                                  <span className="text-gray-500">Worker:</span> <span className="font-mono text-gray-300">{item.workerHash.slice(0, 12)}...{item.workerHash.slice(-12)}</span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

        </section>

        {/* MIDDLE COLUMN: ACTIVE DUAL VIDEO DECK & REAL-TIME HASH LAB */}
        <section className="lg:col-span-6 space-y-5" id="middle_panel">
          
          {/* HIGH-FIDELITY MATCH VERIFICATION DESK */}
          <div className="bg-tech-accent/45 border-2 border-tech-dark p-5 space-y-4" id="match_verification_desk">
            
            <div className="flex flex-wrap items-center justify-between border-b border-tech-dark/30 pb-3 gap-2">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-tech-dark" />
                <h2 className="text-xs uppercase font-mono font-bold tracking-wider text-tech-dark">
                  Side-by-Side Sync Verification Desk
                </h2>
              </div>
              
              {/* Sync Lock HUD Badge */}
              {activeMatchIndex >= 0 && activeMatchIndex < matches.length ? (
                <div className={`flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-mono font-bold border animate-pulse ${
                  matches[activeMatchIndex].isApproximate
                    ? 'bg-amber-50 border-amber-400 text-amber-800'
                    : 'bg-emerald-50 border-emerald-400 text-emerald-800'
                }`}>
                  <span className={`w-2 h-2 rounded-full inline-block ${matches[activeMatchIndex].isApproximate ? 'bg-amber-500' : 'bg-emerald-500'}`} />
                  LOCKED ON SCENE #{activeMatchIndex + 1} {matches[activeMatchIndex].isApproximate ? '(APPROXIMATE)' : '(HIGH CONFIDENCE)'}
                </div>
              ) : (
                <div className="flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-mono font-bold bg-slate-100 border border-slate-300 text-slate-700">
                  <span className="w-2 h-2 rounded-full bg-slate-400 inline-block" />
                  FREE SCRUB SCENE COMPARE
                </div>
              )}
            </div>

            {/* THE DUAL CANVASES SCREEN DESK */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Full Movie Reference Screen */}
              <div className="space-y-2">
                <div className="flex items-center justify-between bg-tech-dark/5 p-1.5 border border-tech-muted">
                  <span className="text-[11px] font-mono font-bold text-tech-dark flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-500" />
                    MOVIE TARGET DECK
                  </span>
                  <span className="text-[11px] font-mono text-cyan-700 font-extrabold bg-cyan-50 px-1.5 border border-cyan-200">
                    {formatTimestamp(syncMovieTime)}
                  </span>
                </div>
                
                <div className={`relative aspect-video bg-black rounded-none overflow-hidden border-2 transition-colors flex items-center justify-center ${
                  activeMatchIndex >= 0
                    ? matches[activeMatchIndex].isApproximate
                      ? 'border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                      : 'border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                    : 'border-tech-dark'
                }`}>
                  <canvas
                    ref={movieCanvasRef}
                    width={320}
                    height={180}
                    className="w-full h-full object-cover animate-fade-in"
                    id="canvas_movie_frame"
                  />
                  
                  {/* Simulated Overlay HUD */}
                  <div className="absolute inset-x-0 top-0 p-1.5 flex justify-between bg-gradient-to-b from-black/85 to-transparent">
                    <span className="text-[8px] font-mono text-white bg-black/60 px-1 py-0.5 rounded-none border border-white/10">
                      M_CH: {sourceType === 'demo' ? 'DEMO_STREAM' : 'MP4_DECODED'}
                    </span>
                    <span className="text-[8px] font-mono text-white bg-black/60 px-1 py-0.5 rounded-none border border-white/10">
                      FPS: 24.0
                    </span>
                  </div>

                  {isIndexing && (
                    <div className="absolute inset-0 bg-black/90 backdrop-blur-xs flex flex-col items-center justify-center p-3 text-center">
                      <RefreshCw className="w-6 h-6 text-cyan-400 animate-spin mb-1.5" />
                      <span className="text-[10px] font-mono font-semibold text-white tracking-wider">INDEXING MOVIE</span>
                      <span className="text-[9px] font-mono text-white/70 mt-0.5">Hashing full frame sequences...</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Short Remix Video Screen */}
              <div className="space-y-2">
                <div className="flex items-center justify-between bg-tech-dark/5 p-1.5 border border-tech-muted">
                  <span className="text-[11px] font-mono font-bold text-tech-dark flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    SHORT REMIX DECK
                  </span>
                  <span className="text-[11px] font-mono text-emerald-700 font-extrabold bg-emerald-50 px-1.5 border border-emerald-200">
                    {formatTimestamp(currentTime)}
                  </span>
                </div>
                
                <div className={`relative aspect-video bg-black rounded-none overflow-hidden border-2 transition-colors flex items-center justify-center ${
                  activeMatchIndex >= 0
                    ? matches[activeMatchIndex].isApproximate
                      ? 'border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                      : 'border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.2)]'
                    : 'border-tech-dark'
                }`}>
                  <canvas
                    ref={shortCanvasRef}
                    width={320}
                    height={180}
                    className="w-full h-full object-cover animate-fade-in"
                    id="canvas_short_frame"
                  />

                  {/* Simulated Overlay HUD */}
                  <div className="absolute inset-x-0 top-0 p-1.5 flex justify-between bg-gradient-to-b from-black/85 to-transparent">
                    <span className="text-[8px] font-mono text-white bg-black/60 px-1 py-0.5 rounded-none border border-white/10">
                      R_CH: MASHUP_MIX
                    </span>
                    <span className="text-[8px] font-mono text-white bg-black/60 px-1 py-0.5 rounded-none border border-white/10">
                      TIME: {currentTime.toFixed(2)}s
                    </span>
                  </div>

                  {isScanning && (
                    <div className="absolute inset-0 bg-black/90 backdrop-blur-xs flex flex-col items-center justify-center p-3 text-center">
                      <RefreshCw className="w-6 h-6 text-emerald-400 animate-spin mb-1.5" />
                      <span className="text-[10px] font-mono font-semibold text-white tracking-wider">SCANNING REMIX</span>
                      <span className="text-[9px] font-mono text-white/70 mt-0.5">Matching hashes against reference...</span>
                    </div>
                  )}
                </div>
              </div>

            </div>

            {/* DEDICATED DUAL SYNC CONTROLLER PANEL */}
            <div className="bg-tech-bg border border-tech-dark/20 p-3.5 space-y-3.5 rounded-none">
              
              <div className="flex flex-wrap items-center justify-between gap-4">
                
                {/* 1. Core Play / Pause & Free Scrub */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className={`px-4 py-2 border font-mono text-[11px] font-black uppercase flex items-center gap-1.5 transition-all shadow-none ${
                      isPlaying
                        ? 'bg-amber-500 text-black border-amber-600 hover:bg-amber-600'
                        : 'bg-emerald-650 text-white border-emerald-700 hover:bg-emerald-700'
                    }`}
                    title={isPlaying ? "Pause sync play" : "Start sync play"}
                    id="deck_btn_play_pause"
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="w-3.5 h-3.5 fill-current" />
                        Pause Sync
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current animate-pulse" />
                        Play Sync
                      </>
                    )}
                  </button>

                  {activeMatchIndex >= 0 && (
                    <button
                      onClick={() => {
                        setActiveMatchIndex(-1);
                        setIsPlaying(false);
                        addLog("Exited Lock-On sync segment. Free scrub mode enabled.");
                      }}
                      className="px-2.5 py-2 border border-tech-dark/30 hover:bg-tech-accent/40 text-tech-dark font-mono text-[11px]"
                      title="Clear scene lock-on"
                      id="deck_btn_clear_lock"
                    >
                      Exit Lock-On Sync
                    </button>
                  )}
                </div>

                {/* 2. Micro Frame-by-Frame Scrubbing Controls */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => {
                      setIsPlaying(false);
                      const step = 1.0;
                      const next = Math.max(0, currentTime - step);
                      setCurrentTime(next);
                      renderFrames(next);
                    }}
                    className="px-2 py-1 bg-tech-dark/5 hover:bg-tech-dark/15 border border-tech-dark/20 font-mono text-[10px] text-tech-dark font-bold"
                    title="Seek -1.0 second on both playheads"
                    id="seek_back_1s"
                  >
                    -1.0s
                  </button>
                  <button
                    onClick={() => {
                      setIsPlaying(false);
                      const step = 0.04; // 1 frame at ~24fps
                      const next = Math.max(0, currentTime - step);
                      setCurrentTime(next);
                      renderFrames(next);
                    }}
                    className="px-2 py-1 bg-tech-dark/5 hover:bg-tech-dark/15 border border-tech-dark/20 font-mono text-[10px] text-tech-dark font-bold"
                    title="Seek -1 Frame (0.04s)"
                    id="seek_back_1f"
                  >
                    -1 Fr
                  </button>
                  <span className="text-[10px] font-mono text-tech-dark/60 px-1 font-bold">FRAME-LOCK</span>
                  <button
                    onClick={() => {
                      setIsPlaying(false);
                      const step = 0.04; // 1 frame at ~24fps
                      const next = Math.min(duration, currentTime + step);
                      setCurrentTime(next);
                      renderFrames(next);
                    }}
                    className="px-2 py-1 bg-tech-dark/5 hover:bg-tech-dark/15 border border-tech-dark/20 font-mono text-[10px] text-tech-dark font-bold"
                    title="Seek +1 Frame (0.04s)"
                    id="seek_fwd_1f"
                  >
                    +1 Fr
                  </button>
                  <button
                    onClick={() => {
                      setIsPlaying(false);
                      const step = 1.0;
                      const next = Math.min(duration, currentTime + step);
                      setCurrentTime(next);
                      renderFrames(next);
                    }}
                    className="px-2 py-1 bg-tech-dark/5 hover:bg-tech-dark/15 border border-tech-dark/20 font-mono text-[10px] text-tech-dark font-bold"
                    title="Seek +1.0 second on both playheads"
                    id="seek_fwd_1s"
                  >
                    +1.0s
                  </button>
                </div>

              </div>

              {/* Looping / Pause Options & Custom Speeds row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2.5 border-t border-tech-dark/10">
                
                {/* Looping options */}
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-mono text-tech-dark/70 font-semibold uppercase">
                    On Segment End:
                  </span>
                  
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => setLoopSegment(true)}
                      className={`px-2 py-1 text-[10px] font-mono font-bold transition-all ${
                        loopSegment 
                          ? 'bg-emerald-600 text-white border border-emerald-700' 
                          : 'bg-tech-accent/40 text-tech-dark border border-tech-muted hover:bg-tech-accent/70'
                      }`}
                      id="btn_loop_on"
                    >
                      Loop Segment
                    </button>
                    <button
                      onClick={() => setLoopSegment(false)}
                      className={`px-2 py-1 text-[10px] font-mono font-bold transition-all ${
                        !loopSegment 
                          ? 'bg-tech-dark text-tech-bg border border-tech-dark' 
                          : 'bg-tech-accent/40 text-tech-dark border border-tech-muted hover:bg-tech-accent/70'
                      }`}
                      id="btn_loop_off"
                    >
                      Pause & Reset
                    </button>
                  </div>
                </div>

                {/* Custom playback speed rates */}
                <div className="flex items-center md:justify-end gap-3">
                  <span className="text-[10px] font-mono text-tech-dark/70 font-semibold uppercase">
                    Compare Speed:
                  </span>
                  
                  <div className="flex gap-1">
                    {[0.25, 0.5, 1.0].map((speed) => (
                      <button
                        key={speed}
                        onClick={() => {
                          setPlaybackSpeed(speed);
                          addLog(`Comparison playback speed updated to ${speed}x.`);
                        }}
                        className={`px-2.5 py-1 text-[10px] font-mono font-black border transition-all ${
                          playbackSpeed === speed
                            ? 'bg-tech-dark text-tech-bg border-tech-dark font-extrabold'
                            : 'bg-tech-accent/40 text-tech-dark border-tech-muted hover:bg-tech-accent/70'
                        }`}
                        id={`btn_speed_${speed}`}
                      >
                        {speed === 1.0 ? '1x Realtime' : `${speed}x Slow`}
                      </button>
                    ))}
                  </div>
                </div>

              </div>

              {/* Lock Calibration HUD */}
              {activeMatchIndex >= 0 && activeMatchIndex < matches.length && (
                <div className="bg-tech-accent/40 p-2.5 text-[9.5px] font-mono text-tech-dark/80 grid grid-cols-1 sm:grid-cols-3 gap-2.5 border border-tech-muted">
                  <div>
                    <span className="text-tech-dark/65 font-bold block uppercase">Short Duration:</span>
                    <span>{(matches[activeMatchIndex].shortEnd - matches[activeMatchIndex].shortStart).toFixed(2)}s ({matches[activeMatchIndex].shortStart.toFixed(1)}s - {matches[activeMatchIndex].shortEnd.toFixed(1)}s)</span>
                  </div>
                  <div>
                    <span className="text-tech-dark/65 font-bold block uppercase">Movie Duration:</span>
                    <span>{(matches[activeMatchIndex].movieEnd - matches[activeMatchIndex].movieStart).toFixed(2)}s ({matches[activeMatchIndex].movieStart.toFixed(1)}s - {matches[activeMatchIndex].movieEnd.toFixed(1)}s)</span>
                  </div>
                  <div>
                    <span className="text-tech-dark/65 font-bold block uppercase">Speed Calibration Ratio:</span>
                    <span className="font-extrabold text-tech-dark bg-tech-accent/90 px-1 border border-tech-muted">
                      {((matches[activeMatchIndex].movieEnd - matches[activeMatchIndex].movieStart) / (matches[activeMatchIndex].shortEnd - matches[activeMatchIndex].shortStart || 1)).toFixed(3)}x reference velocity
                    </span>
                  </div>
                </div>
              )}

            </div>

          </div>

          {/* ACTIVE REAL-TIME FINGERPRINT SPECTROMETER */}
          <div className="bg-tech-accent/40 border border-tech-muted rounded-none p-4 space-y-4" id="fingerprint_spectrometer">
            <h2 className="text-xs uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-2 border-b border-tech-dark/30 pb-2">
              <Activity className="w-3.5 h-3.5 text-tech-dark" />
              Live Perceptual Fingerprint (16x16 / 256-bit Hex Map)
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
              
              {/* Left Hash Visualizer */}
              <div className="md:col-span-5 flex flex-row justify-around items-center bg-tech-bg p-3 rounded-none border border-tech-muted gap-3">
                <div className="flex flex-col items-center">
                  <span className="text-[9px] font-mono text-tech-dark font-bold mb-1">MOVIE HASH</span>
                  <canvas ref={hashCanvasMovieRef} width={80} height={80} className="w-20 h-20 bg-black border border-tech-dark rounded-none" />
                </div>
                <div className="text-tech-dark/50 font-mono text-xs font-extrabold">VS</div>
                <div className="flex flex-col items-center">
                  <span className="text-[9px] font-mono text-tech-dark font-bold mb-1">SHORT HASH</span>
                  <canvas ref={hashCanvasShortRef} width={80} height={80} className="w-20 h-20 bg-black border border-tech-dark rounded-none" />
                </div>
              </div>

              {/* Center Match Stats */}
              <div className="md:col-span-7 space-y-3 p-3 bg-tech-accent/60 rounded-none border border-tech-muted">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-tech-dark/80">Match Integrity Similarity:</span>
                  <span className={`text-sm font-mono font-bold px-2 py-0.5 rounded-none border ${
                    liveSimilarity >= similarityThreshold
                      ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      : 'bg-rose-100 text-rose-800 border-rose-300'
                  }`}>
                    {liveSimilarity}%
                  </span>
                </div>

                <div className="space-y-1">
                  <div className="w-full bg-tech-bg border border-tech-dark/30 h-2.5 rounded-none overflow-hidden">
                    <div
                      className={`h-full transition-all duration-100 ${
                        liveSimilarity >= similarityThreshold ? 'bg-emerald-600' : 'bg-rose-500'
                      }`}
                      style={{ width: `${liveSimilarity}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[8px] font-mono text-tech-dark/60 font-semibold">
                    <span>Low Match</span>
                    <span style={{ marginLeft: `${similarityThreshold}%` }} className="text-tech-dark font-extrabold">Threshold ({similarityThreshold}%)</span>
                    <span>Exact Match</span>
                  </div>
                </div>

                {/* Active Matched Region overlay badge */}
                <div className="flex items-center justify-between text-[11px] font-mono border-t border-tech-dark/10 pt-2 text-tech-dark/80">
                  <span>Matched Crop Region:</span>
                  <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-none border ${
                    activeRegion !== 'Full Frame'
                      ? 'bg-cyan-100 text-cyan-800 border-cyan-300 animate-pulse'
                      : 'bg-tech-dark/10 text-tech-dark/85 border-tech-dark/20'
                  }`}>
                    {activeRegion || 'Full Frame'}
                  </span>
                </div>

                {/* Advanced Double-Check Parameters Grid */}
                <div className="border-t border-tech-dark/10 pt-2.5 space-y-2">
                  <div className="flex items-center justify-between text-[10px] font-mono font-bold text-tech-dark/90 uppercase tracking-wider">
                    <span>Double-Check Verification Checklist:</span>
                    <span className="text-[9px] bg-tech-dark text-white px-1.5 py-0.5 rounded-none font-normal">Active Frame-by-Frame</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                    {/* 1. Structural Match */}
                    <div className="bg-tech-bg/50 p-1.5 border border-tech-dark/10 flex flex-col justify-between">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-tech-dark/70">1. Structure (84%):</span>
                        <span className="font-bold text-tech-dark">{liveStructSimilarity}%</span>
                      </div>
                      <div className="w-full bg-tech-accent h-1 rounded-none overflow-hidden">
                        <div className="bg-cyan-500 h-full" style={{ width: `${liveStructSimilarity}%` }} />
                      </div>
                    </div>

                    {/* 2. Color Profile Match */}
                    <div className="bg-tech-bg/50 p-1.5 border border-tech-dark/10 flex flex-col justify-between">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-tech-dark/70">2. Colors & Background:</span>
                        <span className="font-bold text-tech-dark">{liveColorSimilarity}%</span>
                      </div>
                      <div className="w-full bg-tech-accent h-1 rounded-none overflow-hidden">
                        <div className="bg-indigo-500 h-full" style={{ width: `${liveColorSimilarity}%` }} />
                      </div>
                    </div>

                    {/* 3. Skin & Face/Hand Presence Match */}
                    <div className="bg-tech-bg/50 p-1.5 border border-tech-dark/10 flex flex-col justify-between col-span-1">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-tech-dark/70">3. Human / Character:</span>
                        <span className="font-bold text-tech-dark">{liveSkinSimilarity}%</span>
                      </div>
                      <div className="w-full bg-tech-accent h-1 rounded-none overflow-hidden">
                        <div className="bg-amber-500 h-full" style={{ width: `${liveSkinSimilarity}%` }} />
                      </div>
                    </div>

                    {/* 4. Fine Detail & Layout Contrast */}
                    <div className="bg-tech-bg/50 p-1.5 border border-tech-dark/10 flex flex-col justify-between col-span-1">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-tech-dark/70">4. Edges / Details:</span>
                        <span className="font-bold text-tech-dark">{liveDetailSimilarity}%</span>
                      </div>
                      <div className="w-full bg-tech-accent h-1 rounded-none overflow-hidden">
                        <div className="bg-emerald-500 h-full" style={{ width: `${liveDetailSimilarity}%` }} />
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-[8.5px] text-tech-dark/60 leading-tight font-sans italic">
                    * The system prioritizes structural fingerprints (84% weight) to remain robust under style changes, while cross-checking ambient colors, characters (hands/heads), and background detail ratios (16% weight) for extreme frame alignment precision.
                  </p>
                </div>

                {/* Live Bitstream segment */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[9px] font-mono text-tech-dark/80">
                    <span>Movie Fingerprint Bitstream (Prefix 48-bit):</span>
                  </div>
                  <div className="font-mono text-[9.5px] bg-tech-bg p-1.5 rounded-none text-tech-dark border border-tech-muted truncate font-bold">
                    {activeMovieHash.slice(0, 48)}...
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[9px] font-mono text-tech-dark/80">
                    <span>Short Fingerprint Bitstream (Prefix 48-bit):</span>
                  </div>
                  <div className="font-mono text-[9.5px] bg-tech-bg p-1.5 rounded-none text-tech-dark border border-tech-muted truncate font-bold">
                    {activeShortHash.slice(0, 48)}...
                  </div>
                </div>

              </div>

            </div>

          </div>

          {/* SCRUBBER TIMELINE PANEL */}
          <div className="bg-tech-accent/40 border border-tech-muted rounded-none p-4 space-y-4" id="timeline_panel">
            
            {/* Play controls */}
            <div className="flex items-center justify-between gap-3 bg-tech-bg p-2 rounded-none border border-tech-dark/20">
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  disabled={isIndexing || isScanning}
                  className={`p-2.5 rounded-none text-tech-bg border border-tech-dark transition-all ${
                    isPlaying
                      ? 'bg-tech-dark hover:bg-tech-dark/90 text-amber-500'
                      : 'bg-tech-dark hover:bg-tech-dark/90 text-emerald-400'
                  }`}
                  id="btn_play_pause"
                  title={isPlaying ? "Pause Stream" : "Play Stream"}
                >
                  {isPlaying ? <Pause className="w-4 h-4 fill-current text-amber-500" /> : <Play className="w-4 h-4 fill-current text-emerald-400" />}
                </button>
                <span className="text-[11px] font-mono text-tech-dark/80 ml-1.5">
                  Remix Clip Playhead: <span className="text-tech-dark font-extrabold">{currentTime.toFixed(3)}s</span>
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-tech-dark/80 bg-tech-accent/50 px-2 py-1 border border-tech-muted rounded-none">
                  Movie Synced Head: <span className="text-tech-dark font-extrabold">{syncMovieTime.toFixed(3)}s</span>
                </span>
              </div>
            </div>

            {/* Custom Interactive SVG timeline with overlay matches */}
            <div className="space-y-2">
              <div className="relative pt-2 pb-6">
                
                {/* SVG Matched Regions Overlay */}
                <div className="absolute inset-x-0 h-5 bg-tech-bg border border-tech-dark/40 rounded-none overflow-hidden" style={{ top: '8px' }}>
                  
                  {/* Default Background Lines */}
                  <div className="absolute inset-0 bg-tech-bg" />

                   {/* Draw Matched Highlight Overlays */}
                  {matches.map((seg, i) => {
                    const leftPercent = (seg.shortStart / duration) * 100;
                    const widthPercent = ((seg.shortEnd - seg.shortStart) / duration) * 100;
                    const isActive = activeMatchIndex === i;
                    const isApprox = seg.isApproximate;

                    let highlightClass = "";
                    if (isActive) {
                      highlightClass = isApprox 
                        ? 'bg-amber-500/55 border-amber-600 shadow-[0_0_8px_rgba(245,158,11,0.5)]' 
                        : 'bg-emerald-500/55 border-emerald-600 shadow-[0_0_8px_rgba(16,185,129,0.5)]';
                    } else {
                      highlightClass = isApprox
                        ? 'bg-amber-500/20 hover:bg-amber-500/35 border-amber-500/30'
                        : 'bg-emerald-500/20 hover:bg-emerald-500/35 border-emerald-500/30';
                    }

                    return (
                      <div
                        key={seg.id}
                        onClick={() => playMatchedSegment(i)}
                        className={`absolute h-full cursor-pointer transition-all border-x ${highlightClass}`}
                        style={{
                          left: `${leftPercent}%`,
                          width: `${widthPercent}%`,
                        }}
                        title={`${isApprox ? 'Closest/Approximate Match' : 'Scene Match'} #${i+1} (${seg.confidence}%)`}
                      />
                    );
                  })}
                  
                  {/* Floating active marker pin inside timeline */}
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-tech-dark z-10"
                    style={{ left: `${(currentTime / duration) * 100}%` }}
                  />
                </div>

                {/* Continuous Slider input overlay for scrubbing */}
                <input
                  type="range"
                  min="0"
                  max={duration}
                  step="0.01"
                  value={currentTime}
                  onChange={handleTimelineScrub}
                  disabled={isIndexing || isScanning}
                  className="absolute inset-x-0 h-4 opacity-0 cursor-pointer z-20"
                  style={{ top: '8px' }}
                  id="range_scrubber"
                />

                {/* Timeline Grid Tickers (0s to Duration) */}
                <div className="flex justify-between text-[9px] font-mono text-tech-dark/60 mt-2 px-1 font-semibold">
                  <span>0.00s</span>
                  <span>{(duration * 0.25).toFixed(1)}s</span>
                  <span>{(duration * 0.5).toFixed(1)}s</span>
                  <span>{(duration * 0.75).toFixed(1)}s</span>
                  <span>{duration.toFixed(1)}s</span>
                </div>

              </div>

              {matches.length > 0 && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-300 rounded-none text-[10.5px] text-emerald-800 flex items-center gap-2 font-mono">
                  <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0 text-emerald-600" />
                  <span>Timeline grounded successfully. Green intervals highlight exactly where the matching movie scenes are found in the short remix. Click on segments to auto-sync.</span>
                </div>
              )}
            </div>

          </div>

          {/* HIDDEN HTML5 VIDEO PLAYERS FOR CUSTOM UPLOADS */}
          {sourceType === 'upload' && (
            <div className="hidden" id="hidden_players">
              {movieUrl && (
                <video
                  ref={movieVideoRef}
                  src={movieUrl}
                  crossOrigin="anonymous"
                  preload="auto"
                  muted
                  playsInline
                />
              )}
              {shortUrl && (
                <video
                  ref={shortVideoRef}
                  src={shortUrl}
                  crossOrigin="anonymous"
                  preload="auto"
                  muted
                  playsInline
                />
              )}
            </div>
          )}

        </section>

        {/* RIGHT COLUMN: GROUNDING REPORT, VERIFIED INTEGRITY & EXPORT JSON */}
        <section className="lg:col-span-3 space-y-5" id="right_panel">
          
          {/* GROUNDING REPORT SCENE MATCH CARDS */}
          <div className="bg-tech-accent/40 border border-tech-muted rounded-none p-4 space-y-4" id="grounding_report">
            <h2 className="text-xs uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-2 border-b border-tech-dark/30 pb-2">
              <Layers className="w-3.5 h-3.5 text-tech-dark" />
              Temporal Grounding List
            </h2>

            {matches.length === 0 ? (
              <div className="py-12 flex flex-col items-center justify-center text-center p-3 text-tech-dark/60 bg-tech-bg border border-tech-muted rounded-none">
                <AlertCircle className="w-7 h-7 text-tech-dark/40 mb-2" />
                <p className="text-xs font-mono font-bold">No matches detected yet</p>
                <p className="text-[10px] text-tech-dark/60 mt-1 max-w-[200px]">
                  Index the Movie, then Scan the Remix video to generate the visual alignment map.
                </p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1" id="matches_scroller">
                {matches.map((seg, i) => {
                  const isActive = activeMatchIndex === i;
                  const isApprox = seg.isApproximate;

                  return (
                    <div
                      key={seg.id}
                      onClick={() => playMatchedSegment(i)}
                      className={`p-3 rounded-none border transition-all cursor-pointer ${
                        isActive
                          ? isApprox
                            ? 'bg-amber-700 text-amber-50 border-amber-600 shadow-sm'
                            : 'bg-emerald-900 text-emerald-50 border-emerald-800 shadow-sm'
                          : 'bg-tech-bg border-tech-muted text-tech-dark hover:border-tech-dark/50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-[11px] font-mono font-extrabold px-1.5 py-0.5 rounded-none border ${
                            isActive
                              ? 'bg-tech-bg text-tech-dark border-tech-bg'
                              : isApprox
                                ? 'bg-amber-50 text-amber-800 border-amber-200'
                                : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          }`}>
                            SCENE {String(i + 1).padStart(2, '0')}
                          </span>
                          {isApprox && (
                            <span className="text-[8px] font-mono font-black bg-amber-500 text-black px-1 rounded-sm uppercase tracking-wide">
                              Approx
                            </span>
                          )}
                        </div>
                        <span className={`text-[10px] font-mono font-bold ${isActive ? 'text-white/90' : 'text-tech-dark/80'}`}>
                          {seg.confidence}% Conf.
                        </span>
                      </div>

                      <div className="space-y-1.5 text-[10px] font-mono">
                        <div className="flex justify-between">
                          <span className={isActive ? 'text-white/70' : 'text-tech-dark/60'}>Short Clip:</span>
                          <span className={isActive ? 'text-white font-bold' : 'text-tech-dark font-semibold'}>
                            {seg.shortStart.toFixed(1)}s - {seg.shortEnd.toFixed(1)}s
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className={isActive ? 'text-white/70' : 'text-tech-dark/60'}>Movie Target:</span>
                          <span className={isActive ? 'text-white font-bold' : 'text-tech-dark font-semibold'}>
                            {seg.movieStart.toFixed(1)}s - {seg.movieEnd.toFixed(1)}s
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className={isActive ? 'text-white/70' : 'text-tech-dark/60'}>Frames Matched:</span>
                          <span className={isActive ? 'text-white/90' : 'text-tech-dark/90'}>
                            {seg.frameCount} frames {isApprox ? '(Closest)' : ''}
                          </span>
                        </div>
                      </div>

                      <div className={`mt-2.5 pt-2 border-t flex items-center justify-between text-[9px] font-mono ${
                        isActive
                          ? 'border-white/20 text-white font-bold hover:underline'
                          : 'border-tech-muted text-tech-dark hover:underline'
                      }`}>
                        <span>Double-check Sync play</span>
                        <Play className={`w-2.5 h-2.5 ${isActive ? 'fill-white text-white' : 'fill-tech-dark text-tech-dark'}`} />
                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* EXPORT MAP JSON OUT */}
          <div className="bg-tech-accent/40 border border-tech-muted rounded-none p-4 space-y-4" id="json_exporter">
            <div className="flex items-center justify-between border-b border-tech-dark/30 pb-2">
              <h2 className="text-xs uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-2">
                <FileJson className="w-3.5 h-3.5 text-tech-dark" />
                Copyright Map JSON
              </h2>

              {matches.length > 0 && (
                <button
                  onClick={copyToClipboard}
                  className="p-1 text-tech-dark hover:bg-tech-accent/60 bg-tech-bg border border-tech-muted rounded-none"
                  title="Copy JSON to clipboard"
                  id="btn_copy_json"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-600 font-bold" /> : <Copy className="w-3 h-3" />}
                </button>
              )}
            </div>

            <div className="relative">
              <pre className="text-[10px] font-mono bg-black p-3 rounded-none overflow-x-auto border border-tech-dark max-h-[220px] text-emerald-400 leading-relaxed scrollbar-thin select-all">
                <code>{jsonView}</code>
              </pre>
            </div>
            
            {matches.length > 0 && (
              <a
                href={`data:text/json;charset=utf-8,${encodeURIComponent(jsonView)}`}
                download="copyright_temporal_grounding.json"
                className="w-full py-1.5 bg-tech-dark hover:bg-tech-dark/90 border border-tech-dark rounded-none text-[11px] font-mono text-tech-bg font-bold flex items-center justify-center gap-1.5 transition-colors"
                id="btn_download_json"
              >
                <Download className="w-3 h-3" />
                Download copyright_grounding.json
              </a>
            )}
          </div>

          {/* TELEMETRY DIAGNOSTIC SYSTEM LOGS */}
          <div className="bg-tech-accent/40 border border-tech-muted rounded-none p-4 space-y-3" id="telemetry_logs">
            <h2 className="text-xs uppercase font-mono font-bold tracking-wider text-tech-dark flex items-center gap-2 border-b border-tech-dark/30 pb-2">
              <Sliders className="w-3.5 h-3.5 text-tech-dark" />
              Engine Diagnostics
            </h2>

            <div className="bg-black p-2.5 rounded-none border border-tech-dark max-h-[140px] overflow-y-auto space-y-1.5 font-mono text-[9px] text-emerald-500/90" id="logs_container">
              {logs.length === 0 ? (
                <div className="text-tech-dark/40 italic">No logs recorded yet.</div>
              ) : (
                logs.map((log, idx) => (
                  <div key={idx} className="leading-normal break-all">
                    {log}
                  </div>
                ))
              )}
            </div>
          </div>

        </section>

      </main>

      {/* FOOTER */}
      <footer className="mt-8 border-t border-tech-dark/30 pt-4 text-center text-tech-dark/70 text-[10px] font-mono max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        <span>© 2026 Copyright Match Tool. Built using React, Canvas, and Perceptual Hashing (aHash).</span>
        <span className="flex items-center gap-1">
          Immune to cinematic color grading profiles
          <CheckCircle2 className="w-3 h-3 text-tech-dark" />
        </span>
      </footer>
    </div>
  );
}
