const fs = require('fs');

let content = fs.readFileSync('src/utils/fingerprint.ts', 'utf8');

const replacement = `export function groundMatchedSegments(
  shortFingerprints: FrameFingerprint[],
  movieFingerprints: FrameFingerprint[],
  minSimilarity: number = 82,
  minDuration: number = 0.5,
  frameTolerance: number = 3
): MatchedSegment[] {
  if (shortFingerprints.length === 0 || movieFingerprints.length === 0) {
    return [];
  }

  console.time("[TIMING] Matching/alignment Data Prep");
  
  function popcount32(x) {
    x = x - ((x >>> 1) & 0x55555555);
    x = (x & 0x33333333) + ((x >>> 2) & 0x33333333);
    x = (x + (x >>> 4)) & 0x0f0f0f0f;
    x = x + (x >>> 8);
    x = x + (x >>> 16);
    return x & 0x3f;
  }

  function stringToUint32Array(str) {
    if (!str || str.length !== 256) return null;
    const arr = new Uint32Array(8);
    for (let i = 0; i < 8; i++) {
      let val = 0;
      for (let j = 0; j < 32; j++) {
        val = (val << 1) | (str[i * 32 + j] === '1' ? 1 : 0);
      }
      arr[i] = val >>> 0;
    }
    return arr;
  }

  function parseFingerprint(f) {
    return {
      fp: f,
      hashes: [
        stringToUint32Array(f.hash),
        stringToUint32Array(f.hashCenter916),
        stringToUint32Array(f.hashLeft916),
        stringToUint32Array(f.hashCenterLeft916),
        stringToUint32Array(f.hashCenterRight916),
        stringToUint32Array(f.hashRight916),
        stringToUint32Array(f.hashZoom125Center),
        stringToUint32Array(f.hashZoom125Left),
        stringToUint32Array(f.hashZoom125Right),
        stringToUint32Array(f.hashZoom15),
        stringToUint32Array(f.hashZoom15Left),
        stringToUint32Array(f.hashZoom15Right),
        stringToUint32Array(f.hashZoom20)
      ]
    };
  }

  const sfFast = shortFingerprints.map(parseFingerprint);
  const mfFast = movieFingerprints.map(parseFingerprint);

  function getFastSim(f1, f2) {
    let maxSim = 0;
    for (let k = 0; k < 13; k++) {
      const arr1 = f1.hashes[k];
      const arr2 = f2.hashes[k];
      if (!arr1 || !arr2) continue;
      
      let diff = 0;
      diff += popcount32(arr1[0] ^ arr2[0]);
      diff += popcount32(arr1[1] ^ arr2[1]);
      diff += popcount32(arr1[2] ^ arr2[2]);
      diff += popcount32(arr1[3] ^ arr2[3]);
      diff += popcount32(arr1[4] ^ arr2[4]);
      diff += popcount32(arr1[5] ^ arr2[5]);
      diff += popcount32(arr1[6] ^ arr2[6]);
      diff += popcount32(arr1[7] ^ arr2[7]);
      
      const sim = ((256 - diff) / 256) * 100;
      if (sim > maxSim) maxSim = sim;
    }
    return maxSim;
  }

  console.timeEnd("[TIMING] Matching/alignment Data Prep");

  const segments: MatchedSegment[] = [];

  // --- PASS 1: HIGH CONFIDENCE MATCHES (similarity >= minSimilarity) ---
  console.time("[TIMING] Matching/alignment Pass 1");
  let i = 0;
  while (i < sfFast.length) {
    const sf = sfFast[i];
    
    let bestMovieIdx = -1;
    let highestSim = 0;

    // Full brute-force scan, but extremely fast
    for (let j = 0; j < mfFast.length; j++) {
      const sim = getFastSim(sf, mfFast[j]);
      if (sim >= minSimilarity && sim > highestSim) {
        highestSim = sim;
        bestMovieIdx = j;
      }
    }

    if (bestMovieIdx !== -1) {
      const candidateShort = [sf];
      const candidateMovie = [mfFast[bestMovieIdx]];
      const candidateSims = [highestSim];

      let nextShortIdx = i + 1;
      let nextMovieIdx = bestMovieIdx + 1;

      while (nextShortIdx < sfFast.length && nextMovieIdx < mfFast.length) {
        const nextSf = sfFast[nextShortIdx];
        const nextMf = mfFast[nextMovieIdx];

        const directSim = getFastSim(nextSf, nextMf);
        if (directSim >= minSimilarity) {
          candidateShort.push(nextSf);
          candidateMovie.push(nextMf);
          candidateSims.push(directSim);
          nextShortIdx++;
          nextMovieIdx++;
        } else {
          let foundLookAhead = false;
          let bestLookAheadShortIdx = -1;
          let bestLookAheadMovieIdx = -1;
          let bestLookAheadSim = 0;

          for (let d = 1; d <= 20; d++) {
            if (foundLookAhead) break;
            for (let offsetShort = 0; offsetShort <= Math.min(10, d); offsetShort++) {
              const offsetMovie = d - offsetShort;
              if (offsetMovie > 10 || offsetMovie < 0) continue;

              const sIdx = nextShortIdx + offsetShort;
              const mIdx = nextMovieIdx + offsetMovie;

              if (sIdx < sfFast.length && mIdx < mfFast.length) {
                const sim = getFastSim(sfFast[sIdx], mfFast[mIdx]);
                if (sim >= minSimilarity) {
                  if (sim > bestLookAheadSim) {
                    bestLookAheadSim = sim;
                    bestLookAheadShortIdx = sIdx;
                    bestLookAheadMovieIdx = mIdx;
                    foundLookAhead = true;
                  }
                }
              }
            }
          }

          if (foundLookAhead && bestLookAheadShortIdx !== -1 && bestLookAheadMovieIdx !== -1) {
            candidateShort.push(sfFast[bestLookAheadShortIdx]);
            candidateMovie.push(mfFast[bestLookAheadMovieIdx]);
            candidateSims.push(bestLookAheadSim);
            nextShortIdx = bestLookAheadShortIdx + 1;
            nextMovieIdx = bestLookAheadMovieIdx + 1;
          } else {
            break;
          }
        }
      }

      if (candidateShort.length >= 9) {
        const startShort = candidateShort[0].fp;
        const endShort = candidateShort[candidateShort.length - 1].fp;
        const startMovie = candidateMovie[0].fp;
        const endMovie = candidateMovie[candidateMovie.length - 1].fp;

        const avgConfidence = candidateSims.reduce((a, b) => a + b, 0) / candidateSims.length;

        const matchSequence = candidateShort.map((f, idx) => ({
          shortTime: f.fp.timestamp,
          movieTime: candidateMovie[idx].fp.timestamp,
          similarity: candidateSims[idx]
        }));

        segments.push({
          id: \`match_\${Math.random().toString(36).substring(2, 9)}\`,
          shortStart: Number(startShort.timestamp.toFixed(3)),
          shortEnd: Number(endShort.timestamp.toFixed(3)),
          movieStart: Number(startMovie.timestamp.toFixed(3)),
          movieEnd: Number(endMovie.timestamp.toFixed(3)),
          confidence: Number(avgConfidence.toFixed(1)),
          frameCount: candidateShort.length,
          matchSequence
        });

        i = nextShortIdx;
      } else {
        i++;
      }
    } else {
      i++;
    }
  }

  console.timeEnd("[TIMING] Matching/alignment Pass 1");

  // --- PASS 2: APPROXIMATE / LOW CONFIDENCE MATCHES (similarity >= 40.0%) ---
  console.time("[TIMING] Matching/alignment Pass 2");
  
  const fallbackSegments: MatchedSegment[] = [];
  i = 0;
  while (i < sfFast.length) {
    const sf = sfFast[i];

    const isCovered = segments.some(seg => sf.fp.timestamp >= seg.shortStart && sf.fp.timestamp <= seg.shortEnd);
    if (isCovered) {
      i++;
      continue;
    }

    let bestMovieIdx = -1;
    let highestSim = 0;

    for (let j = 0; j < mfFast.length; j++) {
      const mf = mfFast[j];
      const isMovieFrameCovered = segments.some(seg => mf.fp.timestamp >= seg.movieStart && mf.fp.timestamp <= seg.movieEnd);
      
      if (!isMovieFrameCovered) {
        const sim = getFastSim(sf, mf);
        if (sim >= 40.0 && sim < minSimilarity && sim > highestSim) {
          highestSim = sim;
          bestMovieIdx = j;
        }
      }
    }

    if (bestMovieIdx !== -1) {
      const candidateShort = [sf];
      const candidateMovie = [mfFast[bestMovieIdx]];
      const candidateSims = [highestSim];

      let nextShortIdx = i + 1;
      let nextMovieIdx = bestMovieIdx + 1;

      while (nextShortIdx < sfFast.length && nextMovieIdx < mfFast.length) {
        const nextSf = sfFast[nextShortIdx];
        
        const isNextSfCovered = segments.some(seg => nextSf.fp.timestamp >= seg.shortStart && nextSf.fp.timestamp <= seg.shortEnd);
        if (isNextSfCovered) {
          break;
        }

        const nextMf = mfFast[nextMovieIdx];
        const directSim = getFastSim(nextSf, nextMf);

        if (directSim >= 40.0) {
          candidateShort.push(nextSf);
          candidateMovie.push(nextMf);
          candidateSims.push(directSim);
          nextShortIdx++;
          nextMovieIdx++;
        } else {
          let foundLookAhead = false;
          let bestLookAheadShortIdx = -1;
          let bestLookAheadMovieIdx = -1;
          let bestLookAheadSim = 0;

          for (let d = 1; d <= 20; d++) {
            if (foundLookAhead) break;
            for (let offsetShort = 0; offsetShort <= Math.min(10, d); offsetShort++) {
              const offsetMovie = d - offsetShort;
              if (offsetMovie > 10 || offsetMovie < 0) continue;

              const sIdx = nextShortIdx + offsetShort;
              const mIdx = nextMovieIdx + offsetMovie;

              if (sIdx < sfFast.length && mIdx < mfFast.length) {
                const testMf = mfFast[mIdx];
                const isMovieCovered = segments.some(seg => testMf.fp.timestamp >= seg.movieStart && testMf.fp.timestamp <= seg.movieEnd);
                
                if (!isMovieCovered) {
                  const sim = getFastSim(sfFast[sIdx], testMf);
                  if (sim >= 40.0) {
                    if (sim > bestLookAheadSim) {
                      bestLookAheadSim = sim;
                      bestLookAheadShortIdx = sIdx;
                      bestLookAheadMovieIdx = mIdx;
                      foundLookAhead = true;
                    }
                  }
                }
              }
            }
          }

          if (foundLookAhead && bestLookAheadShortIdx !== -1 && bestLookAheadMovieIdx !== -1) {
            candidateShort.push(sfFast[bestLookAheadShortIdx]);
            candidateMovie.push(mfFast[bestLookAheadMovieIdx]);
            candidateSims.push(bestLookAheadSim);
            nextShortIdx = bestLookAheadShortIdx + 1;
            nextMovieIdx = bestLookAheadMovieIdx + 1;
          } else {
            break;
          }
        }
      }

      if (candidateShort.length >= 9) {
        const startShort = candidateShort[0].fp;
        const endShort = candidateShort[candidateShort.length - 1].fp;
        const startMovie = candidateMovie[0].fp;
        const endMovie = candidateMovie[candidateMovie.length - 1].fp;

        const avgConfidence = candidateSims.reduce((a, b) => a + b, 0) / candidateSims.length;

        const matchSequence = candidateShort.map((f, idx) => ({
          shortTime: f.fp.timestamp,
          movieTime: candidateMovie[idx].fp.timestamp,
          similarity: candidateSims[idx]
        }));

        const durationOffset = startShort.timestamp === endShort.timestamp ? 0.041 : 0;

        fallbackSegments.push({
          id: \`approx_\${Math.random().toString(36).substring(2, 9)}\`,
          shortStart: Number(startShort.timestamp.toFixed(3)),
          shortEnd: Number((endShort.timestamp + durationOffset).toFixed(3)),
          movieStart: Number(startMovie.timestamp.toFixed(3)),
          movieEnd: Number((endMovie.timestamp + durationOffset).toFixed(3)),
          confidence: Number(avgConfidence.toFixed(1)),
          frameCount: candidateShort.length,
          matchSequence,
          isApproximate: true
        });

        i = nextShortIdx;
      } else {
        i++;
      }
    } else {
      i++;
    }
  }

  console.timeEnd("[TIMING] Matching/alignment Pass 2");

  // Combine both high-confidence and approximate segments`;

const startIdx = content.indexOf('export function groundMatchedSegments(');
const endIdx = content.indexOf('  // Combine both high-confidence and approximate segments');

if (startIdx !== -1 && endIdx !== -1) {
  content = content.substring(0, startIdx) + replacement + content.substring(endIdx + 56);
  fs.writeFileSync('src/utils/fingerprint.ts', content, 'utf8');
  console.log("Successfully replaced groundMatchedSegments");
} else {
  console.log("Failed to find boundaries");
}
