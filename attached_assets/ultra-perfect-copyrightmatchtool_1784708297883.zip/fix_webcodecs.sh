sed -i -e '/while (isReadying) {/a\
          await new Promise(r => setTimeout(r, 50));\
        }' src/webcodecs_utils.ts
