sed -i 's/export function groundMatchedSegments(/export function groundMatchedSegments(\n  console.time("[TIMING] LSH Index Build");/g' src/utils/fingerprint.ts
